/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;

/* This single TILE is to avoid constantly allocating and deallocating
 * arrays of polygon vertex coordinates when drawing a scene;
 * with some convenience methods. */
public class TILE 
{
  public static int [] xs = new int [4], ys = new int [4];
  
  public static void set (PointInt p0, PointInt p1, PointInt p2, PointInt p3)
  {
    xs [0] = p0.x; ys [0] = p0.y;
    xs [1] = p1.x; ys [1] = p1.y;
    xs [2] = p2.x; ys [2] = p2.y;
    xs [3] = p3.x; ys [3] = p3.y;
  } // set
  
  public static void draw (Graphics2D g2, Color fill, Color stroke)
  {
    g2.setPaint (fill);
    g2.fillPolygon (xs, ys, 4);
    g2.setPaint (stroke);
    g2.drawPolygon (xs, ys, 4);
  } // draw
 
  // fill or stroke may be null to avoid filling or stroking
  public static void setAndDraw (PointInt p0, PointInt p1, PointInt p2, PointInt p3,
          Graphics2D g2, Color fill, Color stroke)
  {
    xs [0] = p0.x; ys [0] = p0.y;
    xs [1] = p1.x; ys [1] = p1.y;
    xs [2] = p2.x; ys [2] = p2.y;
    xs [3] = p3.x; ys [3] = p3.y;
    
    if (null != fill)
    {
      g2.setPaint (fill);
      g2.fillPolygon (xs, ys, 4);
    }
    
    if (null != stroke)
    {
      g2.setPaint (stroke);
      g2.drawPolygon (xs, ys, 4);
    }
  } // setAndDraw (1)

  // fill or stroke may be null to avoid filling or stroking
  public static void setAndDraw (int x0, int y0, int x1, int y1, int x2, int y2, int x3, int y3,
          Graphics2D g2, Color fill, Color stroke)
  {
    xs [0] = x0; ys [0] = y0;
    xs [1] = x1; ys [1] = y1;
    xs [2] = x2; ys [2] = y2;
    xs [3] = x3; ys [3] = y3;
    
    if (null != fill)
    {
      g2.setPaint (fill);
      g2.fillPolygon (xs, ys, 4);
    }
    
    if (null != stroke)
    {
      g2.setPaint (stroke);
      g2.drawPolygon (xs, ys, 4);
    }
  } // setAndDraw (2)

  /* Paint already set - used in Scene.draw() */
  public static void fillTriangle (Graphics2D g2, PointInt p0, PointInt p1, PointInt p2)
  {
    xs [0] = p0.x; ys [0] = p0.y;
    xs [1] = p1.x; ys [1] = p1.y;
    xs [2] = p2.x; ys [2] = p2.y;
    g2.fillPolygon (xs, ys, 3);
  } // fillTriangle
  
} // TILE
