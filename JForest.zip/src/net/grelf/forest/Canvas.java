/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.util.ArrayList;
import static net.grelf.forest.VIEWS.INTERIOR;
import static net.grelf.forest.VIEWS.MAP;
import static net.grelf.forest.VIEWS.MINE;
import static net.grelf.forest.VIEWS.MINEMAP;
import static net.grelf.forest.VIEWS.SCENE;

public class Canvas extends javax.swing.JComponent
{
  protected int width, height;
  private final Forest FOREST;
  private ArrayList<Target> targets = new ArrayList<> ();
  
  public Canvas (int width, int height)
  {
    FOREST = Forest.getInstance ();
    this.width = width;
    this.height = height;
    setPreferredSize (new Dimension (width, height));
    addMouseListener (new MouseAdapter ()
    {
      @Override
      public void mouseClicked (MouseEvent ev)
      {
        java.awt.Point pt = ev.getPoint ();

        for (Target t : targets)
        {
          if (t.isIn (pt))
          {
            t.response (pt);
            return;
          }
        }

        BufferedImage im = null;

        switch (FOREST.view)
        {
          case MAP:
          case MINEMAP:
          case INTERIOR: return;

          case SCENE:
            im = FOREST.scene.getImage ();
            break;

          case MINE:
            im = FOREST.mine.getImage ();
            break;
        }

        if (null != im)
        {
          Raster rr = im.getRaster ();
          int [] px = new int [4];
          rr.getPixel (pt.x, pt.y, px);
          FOREST.rgbMeter.set (px [0], px [1], px [2]);
          FOREST.redraw ();
        }
      }
    }); // addMouseListener
  } // Canvas
  
  public void addTarget (Target t) { targets.add (t); }
  public void clearTargets () { targets.clear (); }

  @Override
  public void paint (Graphics g)
	{ 
    Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    
    switch (FOREST.view)
    {
      case MAP:
        g2.drawImage (FOREST.map.getImage (), 0, 0, null);
        break;
        
      case SCENE:
        g2.drawImage (FOREST.scene.getImage (), 0, 0, null);
        break;
        
      case MINE:
        g2.drawImage (FOREST.mine.getImage (), 0, 0, null);
        break;
        
      case MINEMAP:
        g2.drawImage (FOREST.minemap.getImage (), 0, 0, null);
        break;
        
      case INTERIOR:
        g2.drawImage (FOREST.inside.getImage (), 0, 0, null);
        break;
    }

    FOREST.drawing = false;
	} // paint
  
} // Canvas
