/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.*;
import static net.grelf.forest.VIEWS.MINE;

public class Canvas extends javax.swing.JComponent
{
  protected int width, height;
  private final Forest FOREST;
  
  public Canvas (int width, int height)
  {
    this.FOREST = Forest.getInstance ();
    this.width = width;
    this.height = height;
    setPreferredSize (new Dimension (width, height));
  }

  @Override
  public void paint (Graphics g)
	{ 
    Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    
    switch (FOREST.view)
    {
      case MAP:
        g2.drawImage (FOREST.map.getImage (), 0, 0, null);
        break;
        
      case SCENE:
        g2.drawImage (FOREST.scene.getImage (), 0, 0, null);
        break;
        
      case MINE:
        g2.drawImage (FOREST.mine.getImage (), 0, 0, null);
        break;
        
      case MINEMAP:
        g2.drawImage (FOREST.minemap.getImage (), 0, 0, null);
        break;
        
      case INTERIOR: // to do
    }

    FOREST.drawing = false;
	} // paint
  
} // Canvas
