/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import static java.awt.event.KeyEvent.VK_DOWN;
import static java.awt.event.KeyEvent.VK_ENTER;
import static java.awt.event.KeyEvent.VK_EQUALS;
import static java.awt.event.KeyEvent.VK_ESCAPE;
import static java.awt.event.KeyEvent.VK_LEFT;
import static java.awt.event.KeyEvent.VK_MINUS;
import static java.awt.event.KeyEvent.VK_PAGE_DOWN;
import static java.awt.event.KeyEvent.VK_PAGE_UP;
import static java.awt.event.KeyEvent.VK_PLUS;
import static java.awt.event.KeyEvent.VK_RIGHT;
import static java.awt.event.KeyEvent.VK_UP;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.UIManager;
import net.grelf.Util;

/** Singleton containing the program entry point */
public class Forest extends JFrame
{
  private String TITLE = " The Forest v23.7.19 ";
  protected Canvas canvas;
  protected Around around;
  protected Terrain terrain;
  protected Observer observer;
  protected Scene scene;
  protected Map map;
  protected Mine mine;
  protected MineMap minemap;
  protected Settings settings;
  protected Help help;
  protected VIEWS view;
  protected boolean drawing = false;
  protected boolean uiLocked = false;
  
	private static Forest instance = null; // Singleton

  /** Main program */
  public static void main (String... args)
  {
		try
		{
			UIManager.setLookAndFeel (UIManager.getSystemLookAndFeelClassName ());

			EventQueue.invokeLater
			(
				new Runnable ()
				{
					@Override
					public void run ()
					{
						Forest forest = Forest.getInstance ();
            forest.setLocation (0, 0);
            forest.canvas = new Canvas (800, 600);
            forest.getContentPane ().add (forest.canvas);
            forest.pack ();
            forest.setVisible (true);

            forest.terrain = new Terrain ();
            forest.around = new Around ();
            forest.observer = new Observer (new Point (15321, 6068), 170);
            forest.scene = new Scene ();
            forest.map = new Map (1, 100);
            forest.mine = new Mine ();
            forest.minemap = new MineMap ();
            forest.settings = new Settings ();
            forest.help = new Help ();
            forest.terrain.place (15125, 6576, FEATURES.ROCKET);
            Road.loadFixedRoads ();
            forest.requestFocus ();
            forest.view = VIEWS.MAP;
            forest.map.draw (new Point (forest.observer.x, forest.observer.y));

            forest.addKeyListener
            (
              new KeyAdapter ()
              {
                @Override
                public void keyPressed (KeyEvent ev)
                {
                  Forest forest = (Forest) ev.getSource ();
                  
                  if (forest.uiLocked) return; // During animations
                  
                  if (forest.drawing) return; // Absorb repeating keys while drawing 
                  
                  switch (forest.view)
                  {
                    case MAP:
                      switch (ev.getKeyCode ())
                      {
                        case 'S':
                        case 's':
                        case VK_DOWN: forest.map.down (); break;
                        case 'A':
                        case 'a':
                        case VK_LEFT: forest.map.left (); break;
                        case 'D':
                        case 'd':
                        case VK_RIGHT: forest.map.right (); break;
                        case 'W':
                        case 'w':
                        case VK_UP: forest.map.up (); break;
                        case VK_PLUS:
                        case VK_EQUALS: forest.map.plus (); break;
                        case VK_MINUS: forest.map.minus (); break;
                        case 'C':
                        case 'c':
                        {
                          Point pt = new Point (forest.observer.x, forest.observer.y);
                          forest.map.draw (pt);
                        }
                        break;
                        case 'G':
                        case 'g': forest.toScene (); break;
                        case 'J':
                        case 'j': forest.observer.jump (); break;
                      }
                      break;
                    
                    case SCENE:
                      switch (ev.getKeyCode ())
                      {
                        case 'S':
                        case 's':
                        case VK_DOWN: forest.observer.turnRound (); break;
                        case 'A':
                        case 'a':
                        case VK_LEFT: forest.observer.turnLeft (); break;
                        case 'D':
                        case 'd':
                        case VK_RIGHT: forest.observer.turnRight (); break;
                        case 'W':
                        case 'w':
                        case VK_UP: forest.observer.forward (); break;
                        case VK_PLUS:
                        case VK_EQUALS: forest.scene.lookUp (); break;
                        case '0': forest.scene.lookLevel (); break;
                        case VK_MINUS: forest.scene.lookDown (); break;
                        case VK_ENTER: forest.observer.enter (); break;
                        case VK_PAGE_UP: forest.observer.up (); break;
                        case VK_PAGE_DOWN: forest.observer.down (); break;
                        case VK_ESCAPE: forest.observer.exit (); break;
                        case 'G':
                        case 'g': forest.toMap (); break;                       
                      }
                      break;
                      
                    case MINE:
                      switch (ev.getKeyCode ())
                      {
                        case 'S':
                        case 's':
                        case VK_DOWN: forest.observer.turnRound (); break;
                        case 'A':
                        case 'a':
                        case VK_LEFT: forest.observer.turnLeft (); break;
                        case 'D':
                        case 'd':
                        case VK_RIGHT: forest.observer.turnRight (); break;
                        case 'W':
                        case 'w':
                        case VK_UP: forest.mine.forward (); break;
                        case VK_PLUS:
                        case VK_EQUALS: forest.mine.lookUp (); break;
                        case '0': forest.mine.lookLevel (); break;
                        case VK_MINUS: forest.mine.lookDown (); break;
                        case 'G':
                        case 'g': forest.toMap (); break;                       
                      }
                      break;
                      
                    case MINEMAP:
                      switch (ev.getKeyCode ())
                      {
                        case 'S':
                        case 's':
                        case VK_DOWN: forest.minemap.down (); break;
                        case 'A':
                        case 'a':
                        case VK_LEFT: forest.minemap.left (); break;
                        case 'C':
                        case 'c': forest.minemap.recentre (); break;
                        case 'D':
                        case 'd':
                        case VK_RIGHT: forest.minemap.right (); break;
                        case 'W':
                        case 'w':
                        case VK_UP: forest.minemap.up (); break;
                        case 'G':
                        case 'g': forest.toScene (); break;
                      }
                      break;
                      
                    case INTERIOR: // to do
                  }
                }
              }
            );
					} // run
				}
			); // invokeLater
		}
		catch (ClassNotFoundException | InstantiationException |
           IllegalAccessException |
           javax.swing.UnsupportedLookAndFeelException ex)
		{
			Util.warning ("Error", ex.toString ());
		}
  } // main

  /** Redraw whatever is currently displayed in the canvas */
  public void redraw ()
  {
    switch (view)
    {
      case MAP: map.draw (map.centre); break;
      case SCENE: scene.draw (); break;
      case MINE: mine.draw (); break;
      case MINEMAP: minemap.draw (minemap.centre);
      case INTERIOR: // to do
    }
    
    requestFocus ();
  } // redraw
  
  private static ImageIcon icon;
	public static ImageIcon getIcon () { return icon; }

	/** Returns a javax.swing.ImageIcon, or null if the path was invalid. */
	protected static ImageIcon createImageIcon (String path)
	{
		URL imgURL = Forest.class.getResource (path);

		if (null != imgURL)
		{
			return new ImageIcon (imgURL);
		}
		else
		{
			Util.warning ("Couldn''t find file: {0}", path);
			return null;
		}
	} // createImageIcon

	/** Get a reference to the application object itself (singleton). */
	public static synchronized Forest getInstance ()
	{
		if (null == instance)
		{
			instance = new Forest ();
      icon = createImageIcon ("foresticon_128x128.png");

      if (null != icon)
      {
        instance.setIconImage (icon.getImage ());
      	Util.setOwningApp (instance, icon);
      }
      else System.out.println ("Null icon");
	  }
		return instance;
	} // getInstance

	private Forest () // Singleton - no-one else can construct
	{
		super ();
    setTitle (TITLE);
		java.util.logging.Logger.getLogger ("net.grelf").setLevel (
            java.util.logging.Level.ALL);

		try
		{
			java.util.logging.Logger.getLogger ("net.grelf").addHandler (
              new java.util.logging.FileHandler ("forest.log", 0, 3));
			java.util.logging.Logger.getLogger ("net.grelf").info ("Started");
		}
		catch (IOException ex)
		{
			java.util.logging.Logger.getLogger ("net.grelf").log (
              java.util.logging.Level.SEVERE,
              "Cannot create log file handler", ex);
		}

    setDefaultCloseOperation (JFrame.DO_NOTHING_ON_CLOSE);

    addWindowListener
		(
			new WindowAdapter ()
			{
				@Override
				public void windowClosing (WindowEvent ev)
				{
					((Forest) ev.getSource ()).exit ();
				}
			}
		);
	} // Forest

	protected void exit ()
	{
		if (Util.confirm (this, "End program", "Really close The Forest?"))
		{
			java.util.logging.Logger.getLogger ("net.grelf").info ("Exit");
			System.exit (0);
		}
	} // exit
  
  /** Switch the display to a map, either above or below ground depending 
    * where the observer is. */
  public void toMap ()
  {
    if (this.view == VIEWS.MINE)
    {
      this.view = VIEWS.MINEMAP;
      this.minemap.draw (this.minemap.centre);
    }
    else
    {
      this.view = VIEWS.MAP;
      this.map.draw (this.map.centre);
    }
  } // toMap

  /** Switch the display from map to scene, either above or below ground depending 
    * where the observer is. */
  public void toScene () 
  {
    if (this.view == VIEWS.MINEMAP)
    {
      this.view = VIEWS.MINE;
      this.mine.draw ();
    }
    else
    {
      this.view = VIEWS.SCENE;
      this.scene.draw ();
    }
  } // toScene
            
} // Forest