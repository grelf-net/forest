/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public class PointInt 
{
  public int x, y;

  public PointInt (int x, int y)
  {
    this.x = x;
    this.y = y;
  } // PointInt

  @Override
  public String toString ()
  {
    return "(" + this.x + ", " + this.y + ")";
  } // toString
  
  /* Simpler than a full overridden equals() */
  public boolean differs (PointInt other)
  {
    return x != other.x || y != other.y;
  } // differs

  public double distance (PointInt otherPt)
  {
    int dx = this.x - otherPt.x;
    int dy = this.y - otherPt.y;
    return Math.sqrt (dx * dx + dy * dy);
  } // distance

  /* Zoom from canvas centre */
  public PointInt zoom (Canvas canvas, double scale)
  { int wd2 = canvas.width / 2;
    int ht2 = canvas.height / 2;
    return new PointInt ((int) Math.round ((this.x - wd2) * scale) + wd2,
                         (int) Math.round ((this.y - ht2) * scale) + ht2);
  } // zoom

} // PointInt
