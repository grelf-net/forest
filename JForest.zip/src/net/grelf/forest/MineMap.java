/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.Date;

public class MineMap 
{
  private static final Forest FOREST = Forest.getInstance ();
  private static final Observer ME = FOREST.observer;
  private final int WD, WD2, HT, HT2, GRID, GRID2;
  private final BufferedImage IM;
  public BufferedImage getImage () { return IM; }
  private final Graphics2D g2;
  public PointInt centre;
  
  public MineMap ()
  {
    this.centre = FOREST.mine.getGridXY (ME.x, ME.y);
    this.WD = FOREST.canvas.width;
    this.WD2 = this.WD / 2;
    this.HT = FOREST.canvas.height;
    this.HT2 = this.HT / 2;
    this.GRID = Mine.GRID;
    this.GRID2 = Mine.GRID2;
    this.IM = new BufferedImage (this.WD, this.HT,BufferedImage.TYPE_INT_RGB);
    this.g2 = this.IM.createGraphics ();
		this.g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//		this.g2.setRenderingHint (RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//		this.g2.setRenderingHint (RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
  } // MineMap

  public void draw (PointInt centre) 
  {
    FOREST.drawing = true;
    long t0 = new Date ().getTime (); // ms
    this.centre = centre;
    g2.setPaint (Color.BLACK);
    g2.fillRect (0, 0, WD, HT);
    int nx = WD2 / GRID, ny = HT2 / GRID;
    
    for (int iy = GRID2, yg = centre.y - ny * GRID;
         yg <= centre.y + ny * GRID; iy += GRID, yg += GRID)
    {
      for (int ix = GRID2, xg = centre.x - nx * GRID;
           xg <= centre.x + nx * GRID; ix += GRID, xg += GRID)
      {
        if (FOREST.mine.isOpen (xg, yg))
        {
          g2.setPaint (FOREST.mine.isOpenAbove (xg, yg) ? Color.CYAN : Color.WHITE);
          g2.fillRect (ix - GRID2, HT - iy - GRID2, GRID, GRID);
          g2.setPaint (Color.LIGHT_GRAY);
          g2.drawRect (ix - GRID2, HT - iy - GRID2, GRID, GRID);
        }
      }
    }
    
    UTIL.plotObserver (g2, WD2 + (int)Math.round (ME.x) - centre.x + GRID2,   // ???
                           HT2 - ((int)Math.round (ME.y) - centre.y), ME.b);
    FOREST.canvas.repaint ();
    long dt = new Date ().getTime () - t0; // ms
    System.out.println (ME.toString () + " Mine map drawn in " + dt + "ms");
  } // draw

  public void up ()
  {
    centre.y += Mine.GRID * 8;
    draw (centre);
  } // up

  public void right () 
  {
    centre.x += Mine.GRID * 8;
    draw (centre);
  } // right

  public void left () 
  {
    centre.x -= Mine.GRID * 8;
    draw (centre);
  } // left

  public void down () 
  {
    centre.y -= Mine.GRID * 8;
    draw (centre);
  } // down

  public void recentre ()
  {
    this.centre = FOREST.mine.getGridXY (ME.x, ME.y);
    draw (centre);
  } // recentre
  
} // MineMap
