/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.util.ArrayList;
import java.util.Date;

/** The contour map above ground, drawn to orienteering standards. */
public class Map
{
  private static final double CI = 40; // Contour interval
  private static final double CI2 = CI / 2;
  private static final double CI5 = CI * 2.5f;
  private static final double STZ = 8;
  private static final double STZ2 = 2 * STZ;
  private static final double SQS3 = STZ * Math.sqrt (3);
  private static final double CONTROL_RADIUS = 15;
  private static final float [] DASH = {16F, 16F};
  private static final BasicStroke STROKE_DASH = 
          new BasicStroke (1.0F, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 1, DASH, 0);
  private static final int LEGEND_WIDTH = 250, LEGEND_HEIGHT = 200;  
  private BufferedImage im, legend;
  public BufferedImage getImage () { return im; }
  public BufferedImage getLegend () { return legend; }
  private Graphics2D g2;
  
  private final Forest FOREST;
  private final Observer ME;
  private String kind;
  public Point centre;
  private double scale, bDegs;
  private long x0, y0;
  private int wd, wd2, ht, ht2, step;
  private boolean orienting, showRoute, showCones;
  private ArrayList <PointInt> mines;
  private int nMines;
  private ArrayList <PointInt> boulders = null;
  private int nBoulders;
  private ArrayList <PointInt> roots = null;
  private int nRoots;
  private ArrayList <PointInt> waterholes = null;
  private int nWaterholes;
  private ArrayList <PointInt> knolls = null;
  private int nKnolls;
  private ArrayList <PointInt> Xs = null;
  private int nXs;
  private ArrayList <PointInt> buildings = null;
  private int nBuildings;
  private ArrayList <PointInt> cones = null;
  private int nCones;
  private final Terra [][] GROUND;

  public Map (double scale, int stepSize)
  { 
    this.FOREST = Forest.getInstance ();
    Canvas screen = FOREST.canvas;
    this.ME = FOREST.observer;
    this.centre = new Point (ME.x, ME.y);
    this.bDegs = ME.b; // degrees
    this.scale = scale;
    this.step = stepSize;
    this.kind = "combined";
    this.wd = screen.width;
    this.wd2 = this.wd / 2;
    this.ht = screen.height;
    this.ht2 = this.ht / 2;
    this.orienting = false;
    this.showRoute = false;
    this.clearFeatures ();
    this.GROUND = new Terra [this.wd][this.ht];
    drawLegend ();
  } // Map

  /** From ground coordinates to map position */
  public Point mapPt (Point pt) 
  {
    return new Point (pt.x - this.x0, this.y0 - pt.y); 
  }

  /** From ground coordinates to map position */
  public PointInt mapPt (PointInt pt) 
  {
    return new PointInt (pt.x - (int) Math.round (this.x0), (int) Math.round (this.y0 - pt.y)); 
  }

  private void clearFeatures ()
  {
    this.mines = new ArrayList<> (); this.nMines = 0;
    this.boulders = new ArrayList<> (); this.nBoulders = 0;
    this.roots = new ArrayList<> (); this.nRoots = 0;
    this.waterholes = new ArrayList<> (); this.nWaterholes = 0;
    this.knolls = new ArrayList<> (); this.nKnolls = 0;
    this.Xs = new ArrayList<> (); this.nXs = 0;
    this.buildings = new ArrayList<> (); this.nBuildings = 0;
    this.showCones = false;
    this.cones = new ArrayList<> (); this.nCones = 0;
  }
  
  // Key actions
  public void down () { this.centre.y -= this.step; this.draw (this.centre); }
  public void left () { this.centre.x -= this.step; this.draw (this.centre); }
  public void right () { this.centre.x += this.step; this.draw (this.centre); }
  public void up () { this.centre.y += this.step; this.draw (this.centre); }
  public void plus () { if (this.step < 400) this.step *= 2; }
  public void minus () { if (this.step > 25) this.step /= 2; }

  /** Draw the map */  
  public void draw (Point centre)
  {
    FOREST.drawing = true;
    long t0 = new Date ().getTime (); // ms
    this.centre = centre;
    this.x0 = Math.round (this.centre.x) - this.wd2;
    this.y0 = Math.round (this.centre.y) + this.ht2;
    this.FOREST.terrain.mapMode = true;
//    moveStuff ();
    
    switch (this.kind)
    {
      case "contour": this.theMap (false, true, true); break;
      case "grid": this.theMap (false, true, false); break;
      case "terrain": this.theMap (true, false, true); break;
      default: this.theMap (true, true, true);
    }

    this.g2.setStroke (UTIL.STROKE1);
/*
    this.isScore = false; // Until course.draw
    this.course = me.course; // May be null unless isScore
    if ((me.role === ROLES.ORIENTEER || me.role === ROLES.PLANNER)
     && (null !== this.course)) this.isScore = this.course.draw ();
    else
    { drawRoads (this.g2);
*/
      this.plotRange (FOREST.scene.getRange ());
/*
    }
*/
    if (ME.role != ROLES.ORIENTEER || ME.novice) this.plotObserver ();
/*
    if (this.kind === "grid") { this.plotGrid (); this.plot300mSq (forest.observer, this.cssRED); }
    if (this.showRoute && me.role === ROLES.ORIENTEER && me.route.length > 0) this.plotRoute (me);
*/
    this.FOREST.terrain.mapMode = false;
/*
    if (this.orienting) this.orient ((me.b + this.b) % 360);
    else if (0 !== this.b) this.orient (this.b);
    else */ this.display ();

    long dt = new Date ().getTime () - t0; // ms
    System.out.println ("Map centre: x = " + Math.round (this.centre.x) + 
            ", y = " + Math.round (this.centre.y) + " Drawn in " + dt + "ms");
  } // draw

  private void plotRange (int range)
  {
    PointInt sxy = this.getScreenXY ((int) Math.round (ME.x), (int) Math.round (ME.y));
    this.g2.setPaint (Color.RED);
    this.g2.setStroke (STROKE_DASH);
    int r2 = range * 2;
    this.g2.drawOval (sxy.x - range, sxy.y - range, r2, r2);
    this.g2.setStroke (UTIL.STROKE1);
  } // plotRange
  
  /* Plot current position on the map */
  private void plotObserver ()
  {
    PointInt sxy = getScreenXY ((int) Math.round (ME.x),
                                (int) Math.round (ME.y));
    UTIL.plotObserver (g2, sxy.x, sxy.y, ME.b);
  }

  private void theMap (boolean showVeg, boolean showCont, boolean showFeat)
  {
    this.clearFeatures();
    Terrain ft = this.FOREST.terrain;
    this.im = new BufferedImage (this.wd, this.ht,BufferedImage.TYPE_INT_RGB);
    WritableRaster wr = this.im.getRaster ();
    this.g2 = this.im.createGraphics ();
		this.g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//		this.g2.setRenderingHint (RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//		this.g2.setRenderingHint (RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    int [] px;
    Terra gnd;
    long x, y;
    int plotX, plotY;
    
    for (y = this.y0, plotY = 0; y > this.y0 - this.ht; y--, plotY++)
    {
      for (x = this.x0, plotX = 0; x < this.x0 + this.wd; x++, plotX++)
      {
        gnd = ft.terra (x, y);
        this.GROUND [plotX][plotY] = gnd;

        if (showVeg) px = gnd.terrain.getPxColour ();
        else if (gnd.terrain == TERRAINS.LAKE) px = COLOURS.pxBLUE;
        else px = COLOURS.pxWHITE;
  
        wr.setPixel (plotX, plotY, px);
        
        if (showFeat) this.noteAnyFeature (gnd.feature, plotX, plotY);

        if (gnd.terrain == TERRAINS.TOWN && null != gnd.building)
        {
          this.buildings.add (new PointInt (plotX, plotY));
          this.nBuildings++;
        }
      }
    }
  
    if (showCont)
    { // Contours:
      final int SZ = 1; // Size of mesh
      final int SZ1 = SZ / 4;
      final int SZ2 = SZ / 2;
      final int SZ3 = SZ1 + SZ2;
      double gTL, hTL, gTR, hTR, gBL, hBL, gBR, hBR, hM;
      double gM, gM5;
      // T = Top, B = Bottom, L = left, R = right, M = Middle
      int ix1, ix2, ix3, ix4, iy1, iy2, iy3, iy4; // Quarters

      this.g2.setPaint (COLOURS.BROWN);
      this.g2.setStroke (UTIL.STROKE1);
      
      for (int iy = 0; iy < this.ht - SZ; iy += SZ)
      {
        iy1 = iy + SZ1;
        iy2 = iy + SZ2;
        iy3 = iy + SZ3;
        iy4 = iy + SZ;

        for (int ix = 0; ix < this.wd - SZ; ix += SZ)
        {
          ix1 = ix + SZ1;
          ix2 = ix + SZ2;
          ix3 = ix + SZ3;
          ix4 = ix + SZ;
          gTL = this.GROUND [ix][iy].height;
          hTL = this.aboveOrBelow (gTL);
          gTR = Math.max (ft.lakeHt, this.GROUND [ix4][iy].height);
          hTR = this.aboveOrBelow (gTR);
          gBR = Math.max (ft.lakeHt, this.GROUND [ix4][iy4].height);
          hBR = this.aboveOrBelow (gBR);
          gBL = Math.max (ft.lakeHt, this.GROUND [ix][iy4].height);
          hBL = this.aboveOrBelow (gBL);
          gM = (gTL + gTR + gBR + gBL) / 4;
          hM = this.aboveOrBelow (gM);
          gM5 = gM % Map.CI5;

          if (gM5 < 10 || gM5 > Map.CI5 - 10) this.g2.setStroke (UTIL.STROKE2);
          else this.g2.setStroke (UTIL.STROKE1);

          // Top triangle:
          if (!(hTL == hTR && hTR == hM)) // Not all the same
          {
            if (hTL > 0)
            {
              if (hTR > 0 && hM < 0) this.g2.drawLine (ix1, iy1, ix3, iy1);
              else if (hTR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix2, iy, ix3, iy1);
                else if (hM < 0) this.g2.drawLine (ix2, iy, ix1, iy1);
                else this.g2.drawLine (ix2, iy, ix2, iy2); // hM == 0
              }
              else // hTR == 0
              {
                if (hM < 0) this.g2.drawLine (ix1, iy1, ix4, iy);
                else if (hM == 0) this.g2.drawLine (ix4, iy, ix2, iy2);
              }
            }
            else if (hTL < 0)
            {
              if (hTR > 0)
              {
                if (hM > 0) this.g2.drawLine (ix2, iy, ix1, iy1);
                else if (hM < 0) this.g2.drawLine (ix2, iy, ix3, iy1);
                else this.g2.drawLine (ix2, iy, ix2, iy2); // hM == 0
              }
              else if (hTR < 0 && hM > 0) this.g2.drawLine (ix1, iy1, ix3, iy1);
              else // hTR == 0
              {
                if (hM > 0) this.g2.drawLine (ix1, iy1, ix4, iy);
                else if (hM == 0) this.g2.drawLine (ix4, iy, ix2, iy2);
              }
            }
            else // hTL == 0
            { if (hTR > 0)
              {
                if (hM < 0) this.g2.drawLine (ix, iy, ix3, iy1);
                else if (hM == 0) this.g2.drawLine (ix, iy, ix2, iy2);
              }
              else if (hTR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix, iy, ix3, iy1);
                else if (hM == 0) this.g2.drawLine (ix, iy, ix2, iy2);
              }
              else this.g2.drawLine (ix, iy, ix4, iy); // hTR == 0
            }
          }
          // Left triangle:
          if (!(hTL == hBL && hTL == hM))
          {
            if (hTL < 0)
            {
              if (hBL < 0 && hM > 0) this.g2.drawLine (ix1, iy1, ix1, iy3);
              else if (hBL > 0)
              { 
                if (hM < 0) this.g2.drawLine (ix, iy2, ix1, iy3);
                else if (hM > 0) this.g2.drawLine (ix, iy2, ix1, iy1);
                else this.g2.drawLine (ix, iy2, ix2, iy2); // hM == 0
              }
              else // hBL == 0
              {
                if (hM > 0) this.g2.drawLine (ix, iy4, ix1, iy1);
                else if (hM == 0) this.g2.drawLine (ix, iy4, ix2, iy2);
              }
            }
            else if (hTL > 0)
            {
              if (hBL > 0 && hM < 0) this.g2.drawLine (ix1, iy1, ix1, iy3);
              else if (hBL < 0)
              {
                if (hM > 0) this.g2.drawLine (ix, iy2, ix1, iy3);
                else if (hM < 0) this.g2.drawLine (ix, iy2, ix1, iy1);
                else this.g2.drawLine (ix, iy2, ix2, iy2); // hM == 0
              }
              else // hBL == 0
              {
                if (hM < 0) this.g2.drawLine (ix, iy4, ix1, iy1);
                else if (hM == 0) this.g2.drawLine (ix, iy4, ix2, iy2);
              }
            }
            else // hTL == 0
            {
              if (hBL > 0)
              { if (hM < 0) this.g2.drawLine (ix, iy, ix1, iy3);
                else if (hM == 0) this.g2.drawLine (ix, iy, ix2, iy2);
              }
              else if (hBL < 0)
              {
                if (hM > 0) this.g2.drawLine (ix, iy, ix1, iy3);
                else if (hM == 0) this.g2.drawLine (ix, iy, ix2, iy2);
              }
              else this.g2.drawLine (ix, iy, ix, iy4); // hBL == 0
            }
          }
          // Bottom triangle:
          if (!(hBL == hBR && hBL == hM))
          { if (hBL > 0)
            {
              if (hBR > 0 && hM < 0) this.g2.drawLine (ix1, iy3, ix3, iy3);
              else if (hBR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix2, iy4, ix3, iy3);
                else if (hM < 0) this.g2.drawLine (ix1, iy3, ix2, iy4);
                else this.g2.drawLine (ix2, iy2, ix2, iy4); // hM == 0
              }
              else // hBR == 0
              {
                if (hM < 0) this.g2.drawLine (ix1, iy3, ix4, iy4);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy4);
              }
            }
            else if (hBL < 0)
            { if (hBR > 0)
              {
                if (hM > 0) this.g2.drawLine (ix1, iy3, ix2, iy4);
                else if (hM < 0) this.g2.drawLine (ix2, iy4, ix3, iy3);
                else this.g2.drawLine (ix2, iy2, ix2, iy4); // hM == 0
              }
              else if (hBR < 0 && hM > 0) this.g2.drawLine (ix1, iy3, ix3, iy3);
              else // hBR == 0
              {
                if (hM > 0) this.g2.drawLine (ix1, iy3, ix4, iy4);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy4);
              }
            }
            else // hBL == 0
            {
              if (hBR > 0)
              { if (hM < 0) this.g2.drawLine (ix, iy4, ix3, iy3);
                else if (hM == 0) this.g2.drawLine (ix, iy4, ix2, iy2);
              }
              else if (hBR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix, iy4, ix3, iy3);
                else if (hM == 0) this.g2.drawLine (ix, iy4, ix2, iy2);
              }
              else this.g2.drawLine (ix, iy4, ix4, iy4); // hBR == 0
            }
          }
          // Right triangle:
          if (!(hTR == hBR && hTR == hM))
          {
            if (hTR > 0)
            {
              if (hBR > 0 && hM < 0) this.g2.drawLine (ix3, iy1, ix3, iy3);
              else if (hBR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix4, iy2, ix3, iy3);
                else if (hM < 0) this.g2.drawLine (ix3, iy1, ix4, iy2);
                else this.g2.drawLine (ix2, iy2, ix4, iy2); // hM == 0
              }
              else // hBR == 0
              {
                if (hM < 0) this.g2.drawLine (ix3, iy1, ix4, iy4);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy4);
              }
            }
            else if (hTR < 0)
            { if (hBR > 0)
              {
                if (hM > 0) this.g2.drawLine (ix3, iy1, ix4, iy2);
                else if (hM < 0) this.g2.drawLine (ix3, iy3, ix4, iy2);
                else this.g2.drawLine (ix2, iy2, ix4, iy2); // hM == 0
              }
              else if (hBR < 0 && hM > 0) this.g2.drawLine (ix3, iy1, ix3, iy3);
              else // hBR == 0
              {
                if (hM > 0) this.g2.drawLine (ix3, iy1, ix4, iy4);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy4);
              }
            }
            else //hTR == 0
            {
              if (hBR > 0)
              { if (hM < 0) this.g2.drawLine (ix4, iy, ix3, iy3);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy);
              }
              else if (hBR < 0)
              {
                if (hM > 0) this.g2.drawLine (ix4, iy, ix3, iy3);
                else if (hM == 0) this.g2.drawLine (ix2, iy2, ix4, iy);
              }
              else this.g2.drawLine (ix4, iy, ix4, iy4);// hBR == 0
    } } } } }

    this.plotNorthLines ();
    Road.drawRoads (g2);
    
    if (showFeat)
    { 
      Color c = FEATURES.MINE.getColour ();
      for (int i = 0; i < this.nMines; i++) 
        this.plotV (this.mines.get (i), c);
      
      c = FEATURES.ROOT.getColour ();
      for (int i = 0; i < this.nRoots; i++)
        this.plotCross (this.roots.get (i), c);
      
      c = FEATURES.BOULDER.getColour ();
      for (int i = 0; i < this.nBoulders; i++)
        this.plotDot (this.boulders.get (i), c);
      
      c = FEATURES.KNOLL.getColour ();
      for (int i = 0; i < this.nKnolls; i++)
        this.plotDot (this.knolls.get (i), c);
      
      c = FEATURES.WATERHOLE.getColour ();
      for (int i = 0; i < this.nWaterholes; i++)
      {
        PointInt pt = this.waterholes.get (i);
        this.plotV (pt, c);
        
        if (FOREST.terrain.withStreams)
        {
          new Stream ((int) Math.round (pt.x + this.x0),
                  (int) Math.round (this.y0 - pt.y)).drawOnMap (this.g2);
        }

      }
      
      c = FEATURES.X.getColour ();
      for (int i = 0; i < this.nXs; i++)
        this.plotCross (this.Xs.get (i), c);
      
      c = FEATURES.BUILDING.getColour ();
      for (int i = 0; i < this.nBuildings; i++)
        this.plotBuilding (this.buildings.get (i), c);

      if (this.showCones) 
      {
        c = FEATURES.CONE.getColour ();
        for (int i = 0; i < this.nCones; i++) 
          this.plotDot (this.cones.get (i), c);
      }
    }
  } // theMap
  
  private void noteAnyFeature (FEATURES f, int plotX, int plotY)
  {
    switch (f)
    {
case MINE:
      this.mines.add (new PointInt (plotX, plotY)); this.nMines++; break;
case BOULDER:
      this.boulders.add (new PointInt (plotX, plotY)); this.nBoulders++; break;
case ROOT:
      this.roots.add (new PointInt (plotX, plotY)); this.nRoots++; break;
case WATERHOLE:
      this.waterholes.add (new PointInt (plotX, plotY)); this.nWaterholes++; break;
case KNOLL:
      this.knolls.add (new PointInt (plotX, plotY)); this.nKnolls++; break;
case X:
      this.Xs.add (new PointInt (plotX, plotY)); this.nXs++; break;
case CONE: 
      if (this.showCones) 
      {
        this.cones.add (new PointInt (plotX, plotY)); this.nCones++;
      }
      break;
    }
  } // noteAnyFeature
  
  private int aboveOrBelow (double ht) 
  { // returns -1 (below), 0 (on), +1 (above) contour
    double htci = ht % Map.CI;
    
    if (htci > Map.CI2) return -1;
    
    if (htci > 0) return 1;
    
    return 0; // Unlikely
  } // aboveOrBelow

  /** Needed also by class Stream */
  protected void plotMarsh (int x, int y)
  {
    g2.setPaint (COLOURS.BLUE);
    g2.drawLine (x - 2, y - 6, x + 2, y - 6);
    g2.drawLine (x - 4, y - 3, x + 4, y - 3);
    g2.drawLine (x - 6, y, x + 6, y);
    g2.drawLine (x - 4, y + 3, x + 4, y + 3);
    g2.drawLine (x - 2, y + 6, x + 2, y + 6);
  }

  private void plotNorthLines ()
  {
    g2.setPaint (COLOURS.BLACK);
    g2.setStroke (UTIL.STROKE1);
    int ht1 = this.ht - 1;
    int [] ys = {0, 25, 25};
    
    for (int x = 100; x < this.wd; x += 300)
    { g2.drawLine (x, 0, x, ht1);
      int [] xs = {x, x - 10, x + 10};
      g2.fillPolygon (xs, ys, 3);
    }
  } // plotNorthLines
  
  private void plotDot (PointInt pt, Color colour)
  { 
    g2.setPaint (COLOURS.WHITE); // White around
    g2.fillArc (pt.x - 3, pt.y - 3, 7, 7, 0, 360);
    g2.setPaint (colour);
    g2.fillArc (pt.x - 2, pt.y - 2, 5, 5, 0, 360);
  } // plotDot

  private void plotCross (PointInt pt, Color colour)
  {
    g2.setPaint (COLOURS.WHITE); // White around
    g2.setStroke(new BasicStroke (3));
    g2.drawLine (pt.x - 3, pt.y - 3, pt.x + 3, pt.y + 3);
    g2.drawLine (pt.x - 3, pt.y + 3, pt.x + 3, pt.y - 3);
    g2.setPaint (colour);
    g2.setStroke(new BasicStroke (1));
    g2.drawLine (pt.x - 3, pt.y - 3, pt.x + 3, pt.y + 3);
    g2.drawLine (pt.x - 3, pt.y + 3, pt.x + 3, pt.y - 3);
  } // plotCross

  private void plotV (PointInt pt, Color colour)
  {
    int xTL = pt.x - 3;
    int yTL = pt.y - 3;
    int xB = pt.x;
    int yB = pt.y + 3;
    int xTR = pt.x + 3;
    int yTR = pt.y - 3;
    g2.setPaint (COLOURS.WHITE); // White around
    g2.setStroke(new BasicStroke (3));
    g2.drawLine (xTL, yTL, xB, yB);
    g2.drawLine (xB, yB, xTR, yTR);
    g2.setPaint (colour);
    g2.setStroke(new BasicStroke (1));
    g2.drawLine (xTL, yTL, xB, yB);
    g2.drawLine (xB, yB, xTR, yTR);
  } // plotV
  
  private void plotBuilding (PointInt pt, Color colour)
  {
    g2.setPaint (colour);
    g2.fillRect(pt.x - 5, pt.y - 5, 11, 11);
  } // plotBuilding
  
  private void display () 
  {
    FOREST.canvas.repaint ();
  } // display
  
  public void moveDown ()
  {
    centre.y -= step;
    draw (centre);
  }

  public void moveLeft ()
  { 
    centre.x -= step; 
    draw (centre);
  }

  public void moveRight ()
  { 
    centre.x += step;
    draw (centre);
  }

  public void moveUp ()
  { 
    centre.y += step; 
    draw (centre);
  }

  /** Given ground coordinates */
  public PointInt getScreenXY (double x, double y)
  { 
    return new PointInt ((int) Math.round (x - this.x0), (int) Math.round (this.y0 - y));
  }

  /** Given screen coordinates */
  public Point getGroundXY (int sx, int sy)
  { 
    return new Point (sx + this.x0, this.y0 - sy);
  }

  public void setStep (int i) { this.step = i; }
  public int getStep () { return this.step; }

  private void drawLegend ()
  {
    this.legend = new BufferedImage (LEGEND_WIDTH, LEGEND_HEIGHT, BufferedImage.TYPE_INT_RGB);
    g2 = legend.createGraphics ();
		g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2.setPaint (Color.WHITE);
    g2.fillRect (0, 0, LEGEND_WIDTH, LEGEND_HEIGHT);
    int xL = 8, xR = 64, yT = 8, yB = 28;
    PointInt [] pts = new PointInt [4];
    pts [0] = new PointInt (xL, yT);
    pts [1] = new PointInt (xR, yT);
    pts [2] = new PointInt (xR, yB);
    pts [3] = new PointInt (xL, yB);
    drawSwatchAndIncPts (pts, "grass", COLOURS.YELLOW, COLOURS.YELLOW, COLOURS.BLACK);
    drawSwatchAndIncPts (pts, "moor", COLOURS.OCHRE, COLOURS.OCHRE, COLOURS.BLACK);
    drawSwatchAndIncPts (pts, "wood", COLOURS.WHITE, COLOURS.GREY, COLOURS.BLACK);
    drawSwatchAndIncPts (pts, "thicket", COLOURS.GREEN, COLOURS.GREEN, COLOURS.WHITE);
    drawSwatchAndIncPts (pts, "lake", COLOURS.BLUE, COLOURS.BLUE, COLOURS.WHITE);
    drawSwatchAndIncPts (pts, "paved", COLOURS.GREY, COLOURS.GREY, COLOURS.WHITE);
    int xSym = 92, ySym = 12;
    PointInt ptSym = new PointInt (xSym, ySym);
    plotDot (ptSym, Color.BLACK);
    g2.drawString ("boulder", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotV (ptSym, Color.BLACK);
    g2.drawString ("mineshaft or cave", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotCross (ptSym, Color.BLACK);
    g2.drawString ("man-made object", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotBuilding (ptSym, Color.BLACK);
    g2.drawString ("building", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotDot (ptSym, COLOURS.BROWN);
    g2.setPaint (Color.BLACK);
    g2.drawString ("knoll", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotCross (ptSym, COLOURS.GREEN);
    g2.setPaint (Color.BLACK);
    g2.drawString ("rootstock", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotV (ptSym, COLOURS.BLUE);
    g2.setPaint (Color.BLACK);
    g2.drawString ("water hole", ptSym.x + 8, ptSym.y + 4);
    ptSym.y += 16;
    plotMarsh (ptSym.x, ptSym.y);
    g2.setPaint (Color.BLACK);
    g2.drawString ("marsh", ptSym.x + 12, ptSym.y + 4);
    ptSym.y += 16;
    g2.setPaint (COLOURS.BLUE);
    g2.setStroke (UTIL.STROKE2);
    g2.drawLine (ptSym.x - 4, ptSym.y, ptSym.x + 12, ptSym.y);
    g2.setStroke (UTIL.STROKE1);
    g2.setPaint (Color.BLACK);
    g2.drawString ("stream", ptSym.x + 20, ptSym.y + 4);
    ptSym.y += 16;
    g2.setStroke (Road.STROKE_DASH);
    g2.drawLine (ptSym.x - 12, ptSym.y, ptSym.x + 16, ptSym.y); 
    g2.drawString ("road", ptSym.x + 20, ptSym.y + 4);
    g2.setStroke (UTIL.STROKE1);
    ptSym.y += 16;
    UTIL.plotObserver (g2, ptSym.x, ptSym.y, 270);
    g2.setPaint (Color.BLACK);
    g2.drawString ("observer (facing west)", ptSym.x + 20, ptSym.y + 4);
  } // drawLegend
  
  private void drawSwatchAndIncPts (PointInt [] pts, String name,
                                    Color fill, Color stroke, Color text)
  {
    TILE.setAndDraw (pts [0], pts [1], pts [2], pts [3], g2, fill, stroke);
    g2.setPaint (text);
    g2.drawString (name, pts [0].x + 8, pts [0].y + 16);
    
    for (int i = 0; i < 4; i++)
    {
      pts [i].y += 24;
    }
  } // drawSwatchAndIncPts

} // Map

/*

Map.prototype.display = function ()
{ var g2 = forest.screen.g2, im = new Image ();
  im.onload = function () { g2.drawImage (im, 0, 0); forest.map.drawing = false; };
  im.src = this.canvas.toDataURL ('image/png');
};

Map.prototype.orient = function (b)
{ var g2 = forest.screen.g2;
  g2.fillStyle = '#fff';
  g2.fillRect (0, 0, this.wd, this.ht);
  g2.save ();
  g2.translate (this.wd2, this.ht2);
  g2.rotate (-b * DEG2RAD);
  g2.translate (-this.wd2, -this.ht2);
  var im = new Image ();
  im.onload = function () { g2.drawImage (im, 0, 0); g2.restore (); forest.map.drawing = false; };
  im.src = this.canvas.toDataURL ('image/png');
};

Map.prototype.perhapsPlotControl = function (p) // Only used if this.isScore
{ var gp = this.getGroundXY (p.x, p.y);
  var rand = Math.round (PI10000 * gp.x * gp.y); // As in scene.draw
  if (1 === (0x3 & rand)) // As in scene.perhapsShowMarker
    this.plotControl (gp.x, gp.y, "" + this.course.calcScore (gp), {x:20, y:0});
};

Map.prototype.changeScroll = function ()
{ var el = document.getElementById ("mapscroll");
  this.step = parseInt (el.options [el.selectedIndex].value);
  this.draw ();
  this.setButtons ();
};

Map.prototype.plotRoute = function (me)
{ this.g2.strokeStyle = this.cssRED;
  this.g2.lineWidth = 2;
  this.g2.beginPath ();
  var rt = me.route;
  var pt = rt [0];
  var sxy = this.getScreenXY (pt.x, pt.y);
  this.g2.moveTo (sxy.x, sxy.y);
  for (var i = 1; i < rt.length; i++)
  { pt = rt [i];
    sxy = this.getScreenXY (pt.x, pt.y);
    this.g2.lineTo (sxy.x, sxy.y);
  }
  this.g2.stroke ();
  this.g2.lineWidth = 1;
};

Map.prototype.plot300mSq = function (observer, cssColour)
{ var sxy = this.getScreenXY (observer.x, observer.y);
  this.g2.strokeStyle = cssColour;
  this.g2.beginPath ();
  this.g2.moveTo (sxy.x - 150, sxy.y - 150);
  this.g2.lineTo (sxy.x + 150, sxy.y - 150);
  this.g2.lineTo (sxy.x + 150, sxy.y + 150);
  this.g2.lineTo (sxy.x - 150, sxy.y + 150);
  this.g2.closePath ();
  this.g2.stroke ();
  this.g2.fillStyle = cssColour;
  this.g2.font = "bold 12px Verdana,sans-serif";
  this.g2.fillText ("3D PLOT AREA", sxy.x - 140, sxy.y + 140);
};

Map.prototype.plotGrid = function ()
{ this.g2.strokeStyle = this.cssGREY;
  this.g2.lineWidth = 1;
  var ht1 = this.ht - 1;
  var wd1 = this.wd - 1;
  for (var x = 0; x < this.wd; x += 25)
  { this.g2.beginPath ();
    this.g2.moveTo (x, 0);
    this.g2.lineTo (x, ht1);
    this.g2.stroke ();
  }
  for (var y = 0; y < this.ht; y += 25)
  { this.g2.beginPath ();
    this.g2.moveTo (0, y);
    this.g2.lineTo (wd1, y);
    this.g2.stroke ();
  }
};

Map.prototype.plotStart = function (x, y, bRad)
{ var sxy = this.getScreenXY (x, y);
  var dx = sxy.x;
  var dy = sxy.y;
  this.g2.strokeStyle = this.CSS_PURPLE;
  this.g2.lineWidth = 2;
  var bMap = bRad + this.b * DEG2RAD;
  var sinb = Math.sin (bMap);
  var cosb = Math.cos (bMap);
  var ax = dx + cosb * this.STZ2;
  var ay = dy + sinb * this.STZ2;
  var bx = dx - cosb * this.STZ - sinb * this.SQS3;
  var by = dy - sinb * this.STZ + cosb * this.SQS3;
  var cx = dx - cosb * this.STZ + sinb * this.SQS3;
  var cy = dy - sinb * this.STZ - cosb * this.SQS3;
  this.g2.beginPath ();
  this.g2.moveTo (ax, ay);
  this.g2.lineTo (bx, by);
  this.g2.lineTo (cx, cy);
  this.g2.closePath ();
  this.g2.stroke ();
  this.g2.lineWidth = 1;
};

Map.prototype.plotControl = function (x, y, label, offset)
{ var sxy = this.getScreenXY (x, y);
  var dx = sxy.x;
  var dy = sxy.y;
  this.g2.strokeStyle = this.CSS_PURPLE;
  this.g2.fillStyle = this.CSS_PURPLE;
  this.g2.lineWidth = 2;
  this.g2.beginPath ();
  this.g2.arc (dx, dy, this.CONTROL_RADIUS, 0, TWO_PI, true);
  this.g2.closePath ();
  this.g2.stroke ();
  this.g2.lineWidth = 1;
  this.g2.font = 'bold 18px Verdana, sans-serif';
  this.g2.fillText (label, dx + offset.x, dy + offset.y);
};

Map.prototype.plotCourseLine = function (x1, y1, x2, y2)
{ var sxy1 = this.getScreenXY (x1, y1);
  var dx1 = sxy1.x;
  var dy1 = sxy1.y;
  var sxy2 = this.getScreenXY (x2, y2);
  var dx2 = sxy2.x;
  var dy2 = sxy2.y;
  var ddx = dx2 - dx1;
  var ddy = dy2 - dy1;
  var b = Math.atan2 (ddy, ddx);
  var rsinb = this.CONTROL_RADIUS * Math.sin (b);
  var rcosb = this.CONTROL_RADIUS * Math.cos (b);
  dx1 += rcosb;
  dy1 += rsinb;
  dx2 -= rcosb;
  dy2 -= rsinb;
  this.g2.fillStyle = this.CSS_PURPLE;
  this.g2.lineWidth = 2;
  this.g2.beginPath ();
  this.g2.moveTo (dx1, dy1);
  this.g2.lineTo (dx2, dy2);
  this.g2.stroke ();
  this.g2.lineWidth = 1;
};

Map.prototype.plotFinish = function (x, y)
{ var sxy = this.getScreenXY (x, y);
  var dx = sxy.x;
  var dy = sxy.y;
  this.g2.fillStyle = this.CSS_PURPLE;
  this.g2.lineWidth = 2;
  this.g2.beginPath ();
  this.g2.arc (dx, dy, this.CONTROL_RADIUS, 0, TWO_PI, true);
  this.g2.closePath ();
  this.g2.stroke ();
  this.g2.beginPath ();
  this.g2.arc (dx, dy, this.CONTROL_RADIUS - 4, 0, TWO_PI, true);
  this.g2.closePath ();
  this.g2.stroke ();
  this.g2.lineWidth = 1;
};

Map.prototype.setButtons = function ()
{ showButtons (mapButtons);
  var el = document.getElementById ("mapSettings");
  if (forest.observer.role === ROLES.ORIENTEER)
  { el.innerHTML =
'<div>Map scroll/pan step size: ' +
'<select id="mapscroll" onchange="changeScroll()" tabindex="-1">' +
'<option value="25">25m</option>' +
'<option value="50">50m</option>' +
'<option value="100">100m</option>' +
'<option value="200">200m</option>' +
'<option value="400">400m</option>' +
'<option value="800">800m</option></select></div>';
  }
  else
  { el.innerHTML =
'<div>Map scroll/pan step size: ' +
'<select id="mapscroll" onchange="changeScroll()" tabindex="-1">' +
'<option value="25">25m</option>' +
'<option value="50">50m</option>' +
'<option value="100">100m</option>' +
'<option value="200">200m</option>' +
'<option value="400">400m</option>' +
'<option value="800">800m</option></select><br/><br/>Map kind: ' +
'<select id="mapkind" onchange="switchMapKind()">' +
'<option value="0">Normal</option>' +
'<option value="1">Contours only</option>' +
'<option value="2">3D plot grid</option>' +
'<option value="3">Terrain types</option></select></div>';
    el = document.getElementById ("mapkind");
    switch (this.kind)
    {
case "combined": el.selectedIndex = 0; break;
case "contour": el.selectedIndex = 1; break;
case "grid": el.selectedIndex = 2; break;
case "terrain": el.selectedIndex = 3; break;
  } }
  el = document.getElementById ("mapscroll");
  switch (this.step)
  {
case 25: el.selectedIndex = 0; break;
case 50: el.selectedIndex = 1; break;
case 100: el.selectedIndex = 2; break;
case 200: el.selectedIndex = 3; break;
case 400: el.selectedIndex = 4; break;
case 800: el.selectedIndex = 5; break;
  }
};

Map.prototype.switchKind = function ()
{ var el = document.getElementById ("mapkind");
  switch (el.selectedIndex)
  {
case 0: this.kind = "combined"; break;
case 1: this.kind = "contour"; break;
case 2: this.kind = "grid"; break;
case 3: this.kind = "terrain"; break;
  }
  this.draw ();
};

Map.prototype.changeOrient = function () 
{ this.orienting = document.getElementById ("orient").checked;
  if (this.orienting) this.b = 0;
  if (forest.showing === "map") this.draw (); 
};
          
Map.prototype.turn = function (degs) { this.b = (this.b - degs) % 360; this.draw (); };

*/