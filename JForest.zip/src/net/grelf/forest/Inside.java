/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Date;

public class Inside 
{
  private final Forest FOREST = Forest.getInstance ();
  private final Observer ME = FOREST.observer;
  private final BufferedImage im;
  public BufferedImage getImage () { return im; }
  private final Graphics2D g2;
  private final int WD, WD2, HT;
  private final int BWD = Building.WIDTH;
  private final double FF = FOREST.scene.FF;
  private final double YSCALE = FOREST.scene.YSCALE;
  private final double FSCALE = FOREST.scene.FSCALE;
  private int meHt;
  private double htBase;
  private Color wallColour;
  protected Building bldg;
  private ArrayList<BufferedImage> pics;
  private int iPic1, iPic2, iPic3, iPic4;
  
  public Inside (Building bg)
  {
    this.bldg = bg;
    WD = FOREST.canvas.getWidth ();
    WD2 = WD / 2;
    HT = FOREST.canvas.getHeight ();
    htBase = Math.floor (HT * 0.6);
    meHt = 0; // Height within building <= storey
    int pix = (int) Math.round (UTIL.PI10000 * (bldg.xCentre + bldg.yCentre));
    int piy = (int) Math.round (UTIL.PI10000 * (bldg.xCentre - bldg.yCentre));
    int pixy = (int) Math.round (UTIL.PI10000 * bldg.xCentre * bldg.yCentre);
    wallColour = new Color (128 + (pix & 127), 128 + (piy & 127), 128 + (pixy & 127), 255);
    pics = FOREST.scene.getImsForInside ();
    int nPics = pics.size ();
    iPic1 = Math.abs (pix) % nPics;
    iPic2 = Math.abs (piy) % nPics;
    iPic3 = Math.abs (pixy) % nPics;
    iPic4 = Math.abs (pix + piy) % nPics;
    im = new BufferedImage (WD, HT, BufferedImage.TYPE_INT_RGB);
    g2 = (Graphics2D) im.createGraphics ();
    g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//		g2.setRenderingHint (RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//		g2.setRenderingHint (RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
  } // Inside
  
  public void draw ()
  {
    long t0 = new Date ().getTime (); // ms
    FOREST.canvas.clearTargets ();
    
    int savedRange = FOREST.scene.range_m;
    FOREST.scene.range_m = 60; // Fastest
    FOREST.scene.draw ();
    g2.drawImage (FOREST.scene.getImage (), 0, 0, WD, HT, null);
    FOREST.scene.range_m = savedRange;

/* This is done by scene.draw()    
    int mex = (int) Math.round (ME.x);
    int mey = (int) Math.round (ME.y);
		FOREST.around.init (mex, mey);
    int xc = bldg.xCentre, yc = bldg.yCentre, bw2 = Building.HALFWIDTH;
    boolean yOdd = false;
    
    for (int y = yc - bw2; y <= yc + bw2; y++, yOdd = !yOdd)
    {
      double dy = y - ME.y, dy2 = dy * dy;
      boolean xOdd = false;
      
      for (int x = xc - bw2; x <= xc + bw2; x++, xOdd = !xOdd)
      {
        double dx = x - ME.x;
        double d = Math.sqrt (dx * dx + dy2);
        double b = Math.atan2 (dx, dy) * UTIL.RAD2DEG;
        double db = b - ME.b;
      
        if (db < -180) db += 360; else if (db > 180) db -= 360;
      
        FOREST.around.aroundSet (d, db, x, y, xOdd && yOdd);
      }
    }
*/    
    Color lineColour = Color.GRAY;
    drawDoorWall (wallColour, lineColour);
    drawOtherWalls (wallColour, lineColour);
    drawFloor ();
//    drawCorner (bldg.xW, bldg.yN);
//    drawCorner (bldg.xW, bldg.yS);
//    drawCorner (bldg.xE, bldg.yN);
//    drawCorner (bldg.xE, bldg.yS);
    
    // more to do
    
    FOREST.canvas.repaint ();
    long dt = new Date ().getTime () - t0; // ms
    System.out.println (ME.toString () + " Interior drawn in " + dt + "ms");
  } // draw
  
  private void drawFloor ()
  {
    int xc = bldg.xCentre, yc = bldg.yCentre, bw2 = Building.HALFWIDTH;

    for (int y = yc - bw2; y < yc + bw2; y++)
    {
      for (int x = xc - bw2; x < xc + bw2; x++)
      {
        Color tileColour = (x + y) % 2 == 0 ? Color.WHITE : Color.BLACK;
        PointInt sxy0 = getScreenXY (x, y, 0);
        PointInt sxy1 = getScreenXY (x + 1, y, 0);
        PointInt sxy2 = getScreenXY (x + 1, y + 1, 0);
        PointInt sxy3 = getScreenXY (x, y + 1, 0);
        TILE.setAndDraw (sxy0, sxy1, sxy2, sxy3, g2, tileColour, tileColour);
      }
    }
  } // drawFloor
  
/*
  private void drawCorner (int x, int y)
  {
    double db = (FOREST.around.aroundGet (x, y)).b;
    
    if (-70 <= db && db <= 70)
    {
      PointInt sxy = this.getScreenXY (x, y, 0);
      g2.setPaint (Color.LIGHT_GRAY);
      g2.drawLine (sxy.x, sxy.y, sxy.x, 0);
    }
  } // drawCorner
*/
  
  public void drawDoorWall (Color fill, Color stroke)
  {
    PointInt wallL = null, doorL = null, doorR = null, wallR = null; // As seen from inside
    int doorWd2 = Building.DOOR_WD / 2;
    
    switch (bldg.doorSide)
    {
      case "N":
        wallL = new PointInt (bldg.xW, bldg.yN);
        doorL = new PointInt (bldg.xCentre - doorWd2, bldg.yN);
        doorR = new PointInt (bldg.xCentre + doorWd2, bldg.yN);
        wallR = new PointInt (bldg.xE, bldg.yN);
        break;
      case "E": 
        wallL = new PointInt (bldg.xE, bldg.yN);
        doorL = new PointInt (bldg.xE, bldg.yCentre + doorWd2);
        doorR = new PointInt (bldg.xE, bldg.yCentre - doorWd2);
        wallR = new PointInt (bldg.xE, bldg.yS);
        break;
      case "S": 
        wallL = new PointInt (bldg.xE, bldg.yS);
        doorL = new PointInt (bldg.xCentre + doorWd2, bldg.yS);
        doorR = new PointInt (bldg.xCentre - doorWd2, bldg.yS);
        wallR = new PointInt (bldg.xW, bldg.yS);
        break;
      case "W": 
        wallL = new PointInt (bldg.xW, bldg.yS);
        doorL = new PointInt (bldg.xW, bldg.yCentre - doorWd2);
        doorR = new PointInt (bldg.xW, bldg.yCentre + doorWd2);
        wallR = new PointInt (bldg.xW, bldg.yN);
        break;
    }
    
    if (null == doorL || null == doorR) return;

    double db = (FOREST.around.aroundGet (doorR.x, doorR.y)).b;
    
    if (-120 <= db && db <= 120)
    {
      int doorHt = (int) Math.round (Building.DOOR_HT * YSCALE);
      PointInt wLB = getScreenXY (wallL.x, wallL.y, 0);
      PointInt wLT = new PointInt (wLB.x, 0);
      PointInt dLB = getScreenXY (doorL.x, doorL.y, 0);
      PointInt dLT = getScreenXY (doorL.x, doorL.y, doorHt);
      PointInt dRB = getScreenXY (doorR.x, doorR.y, 0);
      PointInt dRT = getScreenXY (doorR.x, doorR.y, doorHt);
      PointInt wRB = getScreenXY (wallR.x, wallR.y, 0);
      PointInt wRT = new PointInt (wRB.x, 0);
      TILE.setAndDraw (g2, fill, stroke, wLB, wLT, wRT, wRB, dRB, dRT, dLT, dLB);
    }
  } // drawDoorWall

  private void drawOtherWalls (Color fill, Color stroke)
  {
    PointInt wLB, wLT, wRT, wRB;
    
    if (!"N".equals (bldg.doorSide) && ME.b > -120 && ME.b < 120)
    {
      wLB = getScreenXY (bldg.xW, bldg.yN, 0);
      wLT = new PointInt (wLB.x, 0);
      wRB = getScreenXY (bldg.xE, bldg.yN, 0);
      wRT = new PointInt (wRB.x, 0);
      TILE.setAndDraw (g2, fill, stroke, wLB, wLT, wRT, wRB);
      drawPic ("N", iPic1);
    }       

    if (!"E".equals (bldg.doorSide) && (ME.b > -30 || ME.b < -150))
    {
      wLB = getScreenXY (bldg.xE, bldg.yN, 0);
      wLT = new PointInt (wLB.x, 0);
      wRB = getScreenXY (bldg.xE, bldg.yS, 0);
      wRT = new PointInt (wRB.x, 0);
      TILE.setAndDraw (g2, fill, stroke, wLB, wLT, wRT, wRB);
      drawPic ("E", iPic2);
    }
    
    if (!"S".equals (bldg.doorSide) && (ME.b > 60 || ME.b < -60))
    {
      wLB = getScreenXY (bldg.xE, bldg.yS, 0);
      wLT = new PointInt (wLB.x, 0);
      wRB = getScreenXY (bldg.xW, bldg.yS, 0);
      wRT = new PointInt (wRB.x, 0);
      TILE.setAndDraw (g2, fill, stroke, wLB, wLT, wRT, wRB);
      drawPic ("S", iPic3);
    }
    
    if (!"W".equals (bldg.doorSide) && (ME.b < 30 || ME.b > 150))
    {
      wLB = getScreenXY (bldg.xW, bldg.yS, 0);
      wLT = new PointInt (wLB.x, 0);
      wRB = getScreenXY (bldg.xW, bldg.yN, 0);
      wRT = new PointInt (wRB.x, 0);
      TILE.setAndDraw (g2, fill, stroke, wLB, wLT, wRT, wRB);
      drawPic ("W", iPic4);
    }    
  } // drawOtherWalls
  
  private void drawPic (String compass, int i)
  {
    BufferedImage [] pic = {pics.get (i)};
    
    int x0, y0, z0 = 200; // Under im on wall
    int  xL = 0, yL = 0, xR = 0, yR = 0; // Left/Right on wall
    
    switch (compass)
    { // Under im on wall:
    case "N": x0 = bldg.xCentre; y0 = bldg.yN;
            xL = x0 - 2; xR = x0 + 2; yL = y0; yR = y0; 
            break;
    case "E": x0 = bldg.xE; y0 = bldg.yCentre; 
            xL = x0; xR = x0; yL = y0 + 2; yR = y0 - 2; 
            break;
    case "S": x0 = bldg.xCentre; y0 = bldg.yS; 
            xL = x0 + 2; xR = x0 - 2; yL = y0; yR = y0; 
            break;
    case "W": x0 = bldg.xW; y0 = bldg.yCentre; 
            xL = x0; xR = x0; yL = y0 - 2; yR = y0 + 2; 
            break;
    }
    
    ScenePoint spL = FOREST.around.aroundGet (xL, yL);
    double fscaleL = FSCALE / spL.d;
    ScenePoint spR = FOREST.around.aroundGet (xR, yR);
    double fscaleR = FSCALE / spR.d;
    PointInt sxyL = getScreenXY (xL, yL, 0);
    PointInt sxyR = this.getScreenXY (xR, yR, 0);
    PointInt tL = new PointInt (sxyL.x, sxyL.y - (int) Math.round ((z0 + 250) * fscaleL));
    PointInt bL = new PointInt (sxyL.x, sxyL.y - (int) Math.round ((z0 * fscaleL)));
    PointInt tR = new PointInt (sxyR.x, sxyR.y - (int) Math.round ((z0 + 250) * fscaleR));
    PointInt bR = new PointInt (sxyR.x, sxyR.y - (int) Math.round ((z0 * fscaleR)));
    UTIL.skewHoriz (pic, im, tL, bL,tR, bR, 0, -1, 0);
  } // drawPic
  
  public void enter ()
  {
    ME.x += 4 * ME.sinb;
    ME.y += 4 * ME.cosb;
    
    if (ME.x < bldg.xW + 1) ME.x = bldg.xW + 1;
    else if (ME.x > bldg.xE - 1) ME.x = bldg.xE - 1;
    
    if (ME.y < bldg.yS + 1) ME.y = bldg.yS + 1;
    else if (ME.y > bldg.yN - 1) ME.y = bldg.yN - 1;
    
    ME.sincos ();
    FOREST.view = VIEWS.INTERIOR;
    draw ();
  } // enter

  public void lookUp () 
  {
    if (htBase < HT) 
    {
      htBase += 50; 
      FOREST.scene.lookUp (); 
      draw ();
    }
  } // lookUp
  
  public void lookLevel () 
  {
    htBase = Math.floor (HT * 0.6);
    FOREST.scene.lookLevel ();
    draw ();
  } // lookLevel
  
  public void lookDown ()
  {
    if (htBase > 0)
    {
      htBase -= 50;
      FOREST.scene.lookDown ();
      draw ();
    }
  } // lookDown
  
  public void forward ()
  { 
    boolean leaving = false;
    
    ME.x += 2 * ME.sinb;
    ME.y += 2 * ME.cosb;
    
    switch (bldg.doorSide)
    {
    case "N":
      if (ME.y >= bldg.yN && ME.x >= bldg.xCentre - 5 && ME.x <= bldg.xCentre + 5)
      { ME.y = bldg.yN + 1; leaving = true; }
      break;
    case "S":
      if (ME.y <= bldg.yS && ME.x >= bldg.xCentre - 5 && ME.x <= bldg.xCentre + 5)
      { ME.y = bldg.yS - 1; leaving = true; }
      break;
    case "E":
      if (ME.x >= bldg.xE && ME.y >= bldg.yCentre - 5 && ME.y <= bldg.yCentre  + 5)
      { ME.x = bldg.xE + 1; leaving = true; }
      break;
    case "W":
      if (ME.x <= bldg.xW && ME.y >= bldg.yCentre - 5 && ME.y <= bldg.yCentre + 5)
      { ME.x = bldg.xW - 1; leaving = true; }
      break;
    }
    
    if (leaving)
    { 
      ME.sincos ();
      FOREST.toScene ();
    }
    else
    { 
      if (ME.x < bldg.xW + 0.5) ME.x = bldg.xW + 1;
      else if (ME.x > bldg.xE - 0.5) ME.x = bldg.xE - 1;
      
      if (ME.y < bldg.yS + 0.5) ME.y = bldg.yS + 1;
      else if (ME.y > bldg.yN - 0.5) ME.y = bldg.yN - 1;

      ME.sincos ();
      FOREST.redraw ();
    } 
  } // forward

  private PointInt getScreenXY (int x, int y, int ht)
  {
    ScenePoint sp = FOREST.around.aroundGet (x, y);
    double brad = sp.b * UTIL.DEG2RAD;
    double sinb = Math.sin (brad);
    double cosb = Math.cos (brad);
    double zz = sp.d * cosb;
  if (zz < 1) zz = 1;
    double fRatio = FF / zz;
    int sx = (int) Math.round (fRatio * sp.d * sinb + WD2); // Relative to screen centre, wd2
    int sy = (int) Math.round (htBase - fRatio * (ht - Observer.ME_HT - meHt));
    return new PointInt (sx, sy);
  } // getScreenXY
  
} // Inside
