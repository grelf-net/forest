/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public class Terra 
{
  public double x, y, height, depth; // depth only relevant for lakes
  public String code; // 2-letter O-control code, or ""
  public TERRAINS terrain;
  public FEATURES feature; // FEATURES.NONE if none present
  public Building building = null; // null unless in TOWN

  public Terra (double x, double y, double height, double depth,
                TERRAINS terrain, FEATURES feature, String code)
  {
    this.x = x;
    this.y = y;
    this.height = height;
    this.depth = depth;
    this.terrain = terrain;
    this.feature = feature;
    this.code = code;
    this.building = null;
  }

  public Terra (double x, double y, double height, double depth,
                TERRAINS terrain, Building building)
  {
    this (x, y, height, depth, terrain, FEATURES.NONE, "");
    this.building = building;
  }
  
} // Terra
