/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;

public class Building 
{
  protected static final int WIDTH = 12;
  protected static final int HALFWIDTH = WIDTH / 2;
  private static final Forest FOREST = Forest.getInstance ();
  private static final Scene SCENE = FOREST.scene;
  private static final Observer ME = FOREST.observer;
  private static final Color N_FILL = new Color (153, 153, 153, 255);
  private static final Color S_FILL = new Color (221, 221, 221, 255);
  private static final Color SIDE_FILL = new Color (187, 187, 187, 255);
  private static final int DOOR_HT = 18;
  private static final int DOOR_WD = 2;
  private double pixy;
  protected final int xCentre, yCentre;
  private int ht, baseHt, top, nStoreys;
  private double fogNo;
  private int xW, xE, yN, yS;
  private ScenePoint spNW, spNE, spSE, spSW, spDoorL, spDoorR;
  private String doorSide;
  private Color doorFill;
  private Graphics2D g2;
  
  /* Minimal constructor for terrain scanning (map),
   * add more detail only if we need to draw this (scene). */
  public Building (int x, int y)
  {
    this.xCentre = x; this.yCentre = y;
  }
  
  private void moreDetail ()
  {
    pixy = UTIL.PI10000 * xCentre * yCentre;
    int pixyr = (int) Math.round (pixy);
    int pixy3f = pixyr & 0x3f;
    this.ht = 60 + (int) Math.round (pixy3f * pixy3f / 63.0);
    
    if (this.ht > 90) this.nStoreys = 3;
    else if (this.ht > 70) this.nStoreys = 2;
    else this.nStoreys = 1;
  
    this.xW = xCentre - HALFWIDTH;
    this.xE = xCentre + HALFWIDTH;
    this.yN = yCentre + HALFWIDTH;
    this.yS = yCentre - HALFWIDTH;
    this.spNW = FOREST.around.aroundGet (this.xW, this.yN);
    this.spNE = FOREST.around.aroundGet (this.xE, this.yN);
    this.spSW = FOREST.around.aroundGet (this.xW, this.yS);
    this.spSE = FOREST.around.aroundGet (this.xE, this.yS);
    this.baseHt = (int) Math.round (
       min (this.spNW.getTerra ().height,
            this.spNE.getTerra ().height,
            this.spSW.getTerra ().height,
            this.spSE.getTerra ().height));
    this.baseHt -= 10;// Below ground: no gaps
    this.top = this.baseHt + this.ht;
    this.fogNo = 0.0;
    double dNr = min (this.spNW.d, this.spNE.d, this.spSE.d, this.spSW.d) / FOREST.scene.range_m;
    
    if (dNr > 0.75) this.fogNo = (dNr - 0.75) * 4; // 0..1
    
    switch (pixyr & 0x3)
    {
    case 0:
      this.doorSide = "W";
      this.spDoorL = FOREST.around.aroundGet (this.xW, yCentre + DOOR_WD);
      this.spDoorR = FOREST.around.aroundGet (this.xW, yCentre);
      break;
    case 1:
      this.doorSide = "N";
      this.spDoorL = FOREST.around.aroundGet (xCentre + DOOR_WD, this.yN);
      this.spDoorR = FOREST.around.aroundGet (xCentre, this.yN);
      break;
    case 2:
      this.doorSide = "E";
      this.spDoorL = FOREST.around.aroundGet (this.xE, yCentre - DOOR_WD);
      this.spDoorR = FOREST.around.aroundGet (this.xE, yCentre);
      break;
    case 3:
      this.doorSide = "S";
      this.spDoorL = FOREST.around.aroundGet (xCentre - DOOR_WD, this.yS);
      this.spDoorR = FOREST.around.aroundGet (xCentre, this.yS);
      break;
    }
    
    this.doorFill = new Color (pixyr & 0xff, (pixyr & 0xff00) >> 8,
                               (pixyr & 0xff0000) >> 16, 255);
    
    if (Math.abs (ME.x - this.spDoorL.x) < 7 && Math.abs (ME.y - this.spDoorL.y) < 7)
    {
      ME.building = this;
    }
    else ME.building = null;
  } // moreDetail

  private double min (double x1, double x2, double x3, double x4)
  {
    double m = x1;
    if (x2 < m) m = x2;
    if (x3 < m) m = x3;
    if (x4 < m) m = x4;
    return m;
  } // min
  
  public static boolean inABuilding (double x, double y)
  {
    int xr = (int) Math.round (x);
    int yr = (int) Math.round (y);
    
    for (int ix = xr - HALFWIDTH; ix <= xr + HALFWIDTH; ix++)
    {
      for (int iy = yr - HALFWIDTH; iy <= yr + HALFWIDTH; iy++)
      {
        if (TERRAINS.TOWN == FOREST.around.aroundGet (ix, iy).getTerra().terrain
         && atCentre (ix, iy)) return true;
      }
    }

    return false;
  } // inABuilding
  
  public static boolean atCentre (int x, int y) 
  {
    return 0 == (x & 0xf) && 0 == (y & 0xf)
        && (((int) Math.round (UTIL.PI10000 * x * y)) & 0xf) < 12;
  }

  //  -6           C          +6
  // 9 a b c d e f 0 1 2 3 4 5 6 7 8
  //     b   d   f   1   3   5 
  
  public void markFoundations () 
  {
    moreDetail (); // Going to draw, so complete construction
    
    // Code corners/edges/inside by property 
    // fnd on the ScenePoint at around [oddX][oddY]:
    // 8 1 2
    // 7 0 3
    // 6 5 4

    int x, y;
    ScenePoint sp;
    int xW1 = this.xW + 1, xE1 = this.xE - 1, yS1 = this.yS + 1, yN1 = this.yN - 1;
    
    for (x = xW1 + 2; x < xE1; x += 2) 
    {
      for (y = yS1 + 2 + 1; y < yN1; y++) //????
      //for (y = yS1 + 2; y < yN1; y += 2) //???? 
      {
        sp = FOREST.around.aroundGet (x, y);
        sp.fnd = 0;
      } 
    }
    
    for (x = xW1; x <= xE1; x += 2) 
    {
      for (y = yS1; y <= yN1; y += 2) 
      {
        sp = FOREST.around.aroundGet (x, y);
        sp.getTerra ().building = this;
      }
    }
    
    for (x = xW1 + 2; x < xE1; x += 2) 
    {
      sp = FOREST.around.aroundGet (x, yN1);
      sp.fnd = 1; 
      sp = FOREST.around.aroundGet (x, yS1);
      sp.fnd = 5; 
    }
    
    for (y = yS1 + 2; y < yN1; y += 2) 
    {
      sp = FOREST.around.aroundGet (xW1, y);
      sp.fnd = 7;
      sp = FOREST.around.aroundGet (xE1, y);
      sp.fnd = 3; 
    }
    
    sp = FOREST.around.aroundGet (xW1, yN1); sp.fnd = 8; 
    sp = FOREST.around.aroundGet (xE1, yN1); sp.fnd = 2; 
    sp = FOREST.around.aroundGet (xE1, yS1); sp.fnd = 4; 
    sp = FOREST.around.aroundGet (xW1, yS1); sp.fnd = 6;
  } // markFoundations

  public void drawPart (Graphics2D g2, int xr, int yr, int mex, int mey, int range_m) 
  {
    this.g2 = g2;

    if (xr > mex - range_m && xr < mex + range_m - 1
     && yr > mey - range_m && yr < mey + range_m - 1)
    {
      ScenePoint sp0 = FOREST.around.aroundGet (xr, yr); // x & y odd
      Color fill12, fill23 = SIDE_FILL;
      boolean hasDoor;
      ScenePoint sp1, sp2, sp3 = null;
      
      switch (sp0.fnd)
      { case 1://N 
          fill12 = UTIL.fog (N_FILL, this.fogNo); 
          hasDoor = "N".equals (this.doorSide) && xr - this.xCentre == 1; 
          sp1 = FOREST.around.aroundGet (xr + 1, yr + 1);
          sp2 = FOREST.around.aroundGet (xr - 1, yr + 1);
          break;
        case 2://NE
          fill12 = UTIL.fog (SIDE_FILL, this.fogNo);
          fill23 = UTIL.fog (N_FILL, this.fogNo);
          hasDoor = false;
          sp1 = FOREST.around.aroundGet (xr + 1, yr - 1);
          sp2 = this.spNE;
          sp3 = FOREST.around.aroundGet (xr - 1, yr + 1);
          break;
        case 3://E 
          fill12 = UTIL.fog (SIDE_FILL, this.fogNo);
          hasDoor = "E".equals (this.doorSide) && yr - this.yCentre == -1; 
          sp1 = FOREST.around.aroundGet (xr + 1, yr - 1);
          sp2 = FOREST.around.aroundGet (xr + 1, yr + 1);
          break;
        case 4://SE
          fill12 = UTIL.fog (S_FILL, this.fogNo);
          fill23 = UTIL.fog (SIDE_FILL, this.fogNo);
          hasDoor = false;
          sp1 = FOREST.around.aroundGet (xr - 1, yr - 1);
          sp2 = this.spSE;
          sp3 = FOREST.around.aroundGet (xr + 1, yr + 1);
          break;
        case 5://S
          fill12 = UTIL.fog (S_FILL, this.fogNo); 
          hasDoor = "S".equals (this.doorSide) && xr - this.xCentre == -1; 
          sp1 = FOREST.around.aroundGet (xr - 1, yr - 1);
          sp2 = FOREST.around.aroundGet (xr + 1, yr - 1);
          break;
        case 6://SW
          fill12 = UTIL.fog (SIDE_FILL, this.fogNo);
          fill23 = UTIL.fog (S_FILL, this.fogNo);
          hasDoor = false;
          sp1 = FOREST.around.aroundGet (xr - 1, yr + 1);
          sp2 = this.spSW;
          sp3 = FOREST.around.aroundGet (xr + 1, yr - 1);
          break;
        case 7://W 
          fill12 = UTIL.fog (SIDE_FILL, this.fogNo); 
          hasDoor = "W".equals (this.doorSide) && yr - this.yCentre == 1; 
          sp1 = FOREST.around.aroundGet (xr - 1, yr + 1);
          sp2 = FOREST.around.aroundGet (xr - 1, yr - 1);
          break;
        case 8://NW
          fill12 = UTIL.fog (N_FILL, this.fogNo);
          fill23 = UTIL.fog (SIDE_FILL, this.fogNo);
          hasDoor = false;
          sp1 = FOREST.around.aroundGet (xr + 1, yr + 1);
          sp2 = this.spNW;
          sp3 = FOREST.around.aroundGet (xr - 1, yr - 1);
          break;
        default: return;//Inside
      }
      
      if (null != sp3)
      {
        if (sp1.d > sp3.d)
        { this.drawWall (sp1, sp2, fill12, false, false);
          this.drawWall (sp2, sp3, fill23, false, false);
        }
        else
        { this.drawWall (sp3, sp2, fill23, false, false);
          this.drawWall (sp2, sp1, fill12, false, false);
        } 
      }
      else this.drawWall (sp1, sp2, fill12, hasDoor, true);
      
      // Roof:
      if ((this.top - SCENE.ht0) * SCENE.YSCALE < ME.ht)
      { 
        PointInt xy1 = this.getScreenXY (this.spNE, this.top);
        PointInt xy2 = this.getScreenXY (this.spSE, this.top);
        PointInt xy3 = this.getScreenXY (this.spSW, this.top);
        PointInt xy4 = this.getScreenXY (this.spNW, this.top);
        Color fillR = UTIL.fog (85, 85, 85, this.fogNo);
        TILE.setAndDraw (xy1, xy2, xy3, xy4, g2, fillR, fillR);
      }
    }    
  } // drawPart

  private void drawWall (ScenePoint sp1, ScenePoint sp2, Color fill, boolean door, boolean window)
  {
    PointInt b1 = this.getScreenXY (sp1, this.baseHt);
    PointInt t1 = this.getScreenXY (sp1, this.top);
    PointInt t2 = this.getScreenXY (sp2, this.top);
    PointInt b2 = this.getScreenXY (sp2, this.baseHt);
    TILE.setAndDraw (b1, t1, t2, b2, g2, fill, fill);
    
    if (window)
    {
      Color fillW = UTIL.fog (100, 120, 150, this.fogNo);
      Color strokeW = UTIL.fog (255, 255, 255, this.fogNo);
      int th = this.baseHt + this.ht;
      drawWindow (sp1, sp2, th - 15, th - 5, fillW, strokeW);
      
      if (!door)
      {
        if (this.nStoreys > 1) drawWindow (sp1, sp2, th - 35, th - 25, fillW, strokeW);
        if (this.nStoreys > 2) drawWindow (sp1, sp2, th - 55, th - 45, fillW, strokeW);
      }
    }
    
    if (door)
    {
      Color fillD = UTIL.fog (this.doorFill, this.fogNo);
      Color strokeD = UTIL.fog (63, 63, 63, this.fogNo);
      int base = (int) Math.round (Math.max (sp1.getTerra ().height, sp2.getTerra ().height));
      b1 = this.getScreenXY (this.spDoorL, base);
      t1 = this.getScreenXY (this.spDoorL, base + DOOR_HT);
      t2 = this.getScreenXY (this.spDoorR, base + DOOR_HT);
      b2 = this.getScreenXY (this.spDoorR, base);
      TILE.setAndDraw (b1, t1, t2, b2, g2, fillD, strokeD);
    }
  };

  private void drawWindow (ScenePoint sp1, ScenePoint sp2, int bw, int tw, Color fill, Color stroke)
  {
    PointInt b1 = this.getScreenXY (sp1, bw);
    PointInt t1 = this.getScreenXY (sp1, tw);
    PointInt t2 = this.getScreenXY (sp2, tw);
    PointInt b2 = this.getScreenXY (sp2, bw);
    TILE.setAndDraw (b1, t1, t2, b2, g2, fill, stroke);
  } // drawWindow

  private PointInt getScreenXY (ScenePoint sp, int ht)
  { 
    double brad = sp.b * UTIL.DEG2RAD;
    double sinb = Math.sin (brad);
    double cosb = Math.cos (brad);
    double zz = sp.d * cosb;
  if (zz < 1) zz = 1;
    double fRatio = SCENE.FF / zz;
    double sx = fRatio * sp.d * sinb + SCENE.wd2;
    double sy = SCENE.htBase - fRatio * ((ht - SCENE.ht0) * SCENE.YSCALE - ME.ht);
    return new PointInt ((int) Math.round (sx), (int) Math.round (sy));
  } // getScreenXY

}// Building
