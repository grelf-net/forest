/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

/** Target rectangle for mouse clicks */
public abstract class Target
{
  private final int xL, yT, xR, yB;//Left, Top, Right, Bottom, in screen coordinates
  
  public Target (int xL, int yT, int xR, int yB)
  {
    this.xL = xL; this.yT = yT; this.xR = xR; this.yB = yB;
  } // Target
  
  public boolean isIn (java.awt.Point pt)
  {
    return (pt.x >= xL && pt.x <= xR && pt.y >= yT && pt.y <= yB);
  } // isIn
  
  abstract void response (java.awt.Point pt);
  
} // Target
