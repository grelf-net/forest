/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import javax.swing.Timer;
import net.grelf.Util;

/** Mines are load out as a grid of 16 x 16m cells but the observer
  * can still move by any amount in any direction. */
public class Mine
{
  public static final int GRID = 16; // metres
  public static final int GRID2 = 8; // GRID / 2
  private static final int RANGE_G = 8; // Max no of cells visible in any direction
  private static final int RANGE_M = GRID * RANGE_G; // metres
  private static final Forest FOREST = Forest.getInstance ();
  private static final Scene SCENE = FOREST.scene;
  private static final Observer ME = FOREST.observer;
  private static final double FF = SCENE.FF;
  private static BufferedImage [] imWall = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] gravel = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] light = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] imMeter = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] imChest01 = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] imChest02 = new BufferedImage [G2.N_FOG_LEVELS];
  private static BufferedImage [] ladder = new BufferedImage [G2.N_FOG_LEVELS];
  private int yStep, dyStep, ht, wd, wd2, htBase;
  private double ht11, wallHt;
  private boolean doFog;
  private PointInt ladderPt;
  private ArrayList<Cell> cells;
  private ArrayList<Later> drawLater;
  private BufferedImage imCopy;
          
  private final BufferedImage im;
  public BufferedImage getImage () { return im; }
  private final Graphics2D g2;

  public Mine ()
  { 
    this.yStep = 0; this.dyStep = 10; // For stepDown()
    imWall = SCENE.imWall;
    gravel = SCENE.gravel;
    this.ht11 = imWall [0].getHeight () * 11.0;
    this.wallHt = imWall [0].getHeight () / 64.0;
    ladder [0] = SCENE.loadImage ("ladder.png");
    light [0] = SCENE.loadImage ("light.png");
    imMeter [0] = SCENE.loadImage ("meter01.png");
    imChest01 [0] = SCENE.loadImage ("chest01.png"); // Empty
    imChest02 [0] = SCENE.loadImage ("chest02.png"); // + note
    this.doFog = true;
    this.ht = FOREST.canvas.height;
    this.htBase = (int) Math.floor (this.ht * 0.6);
    this.wd = FOREST.canvas.width;
    this.wd2 = wd / 2;
    this.ladderPt = null;
    this.im = new BufferedImage (wd, ht, BufferedImage.TYPE_INT_RGB);
    this.g2 = this.im.createGraphics ();
		this.g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//		this.g2.setRenderingHint (RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//		this.g2.setRenderingHint (RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
  } // Mine

  /* Return multiples of 16. */
  public static PointInt getGridXY (double x, double y)
  {
    return new PointInt (GRID * (int) Math.round (x / GRID),
                         GRID * (int) Math.round (y / GRID));
  }

  // 1 level so open iff mineshaft on ground
  public boolean isOpenAbove (int xg, int yg)
  {
    for (int ix = xg - GRID2 + 1; ix <= xg + GRID2; ix++)
    { 
      for (int iy = yg - GRID2; iy <= yg + GRID2; iy++)
      { 
        if (FOREST.terrain.terra (ix, iy).feature == FEATURES.MINE) return true;        
      }
    }
    
    return false;
  } // isOpenAbove

  // Mine open here? Must be if mineshaft on the ground
  public boolean isOpen (int xg, int yg)
  {
    if (this.isOpenAbove (xg, yg)) return true;
    
    double u = UTIL.PI10000 * Math.sin (xg) * Math.cos (yg);
    return (u - Math.floor (u)) > 0.42;
  } // isOpen

  protected void lookUp () { if (this.htBase < this.ht) { this.htBase += 50; this.draw (); } }
  protected void lookLevel (){ this.htBase = (int) Math.floor (this.ht * 0.6); this.draw (); }
  protected void lookDown () { if (this.htBase > 0) { this.htBase -= 50; this.draw (); } }

  private void findCellsInRange ()
  {
    int R = RANGE_M, G = GRID;
    PointInt meg = getGridXY (ME.x, ME.y);
    this.cells = new ArrayList<> ();

    for (int yg = meg.y - R; yg <= meg.y + R; yg += G)
    {
      double dy = yg - ME.y, dy2 = dy * dy;

      for (int xg = meg.x - R; xg <= meg.x + R; xg += G)
      { 
        double dx = xg - ME.x, d = Math.sqrt (dx * dx + dy2);

        if (d < R)
        {
          double db = Math.atan2 (dx, dy) * UTIL.RAD2DEG - ME.b;

          if (db < -180) db += 360; else if (db > 180) db -= 360;

          int xNW = xg - GRID2, yNW = yg + GRID2;
          ScreenXYD sxydNW = this.getScreenXYD (xNW, yNW, 0);
          int xNE = xg + GRID2, yNE = yg + GRID2;
          ScreenXYD sxydNE = this.getScreenXYD (xNE, yNE, 0);
          int xSE = xg + GRID2, ySE = yg - GRID2;
          ScreenXYD sxydSE = this.getScreenXYD (xSE, ySE, 0);
          int xSW = xg - GRID2, ySW = yg - GRID2;
          ScreenXYD sxydSW = this.getScreenXYD (xSW, ySW, 0);
 
          if (Math.round (sxydNW.db) <= 45
           || Math.round (sxydNE.db) <= 45
           || Math.round (sxydSW.db) <= 45
           || Math.round (sxydSE.db) <= 45)
          {
            double fogNo = 0, dNr = d / R; 

            if (dNr > 0.5) fogNo = (dNr - 0.5) * 2; // 0..1

            cells.add (new Cell (xg, yg, d, db, !this.isOpen (xg, yg), fogNo,
                                 sxydNW, sxydNE, sxydSE, sxydSW));
          }
        }
      }
    }

    cells.sort (null); // Descending distance
  } // findCellsInRange
  
  private ScreenXYD getScreenXYD (double x, double y, double z)
  {
    double dx = x - ME.x;
    double dy = y - ME.y;
    double d = Math.sqrt (dx * dx + dy * dy);
    double db = Math.atan2 (dx, dy) * UTIL.RAD2DEG - ME.b;
    if (db < -180) db += 360; else if (db > 180) db -= 360;
    double dbRad = db * UTIL.DEG2RAD;
    double sinb = Math.sin (dbRad);
    double cosb = Math.cos (dbRad);
    double zz = d * cosb;
  if (zz < 1) zz = 1;
    double fRatio = FF / zz;
    int sx = (int) Math.round (fRatio * d * sinb + this.wd2); // Relative to screen centre, wd2
    int sy = (int) Math.round (this.htBase + fRatio * (Observer.ME_HT - z));
    return new ScreenXYD (sx, sy, d, db, x, y);
  } // getScreenXYD
  
  public void draw ()
  {
    long t0 = new Date ().getTime (); // ms
    this.ladderPt = null;
    this.drawLater = new ArrayList<> ();
    FOREST.canvas.clearTargets ();
    G2.doFog = this.doFog;    
    G2.sky = Color.BLACK;
    g2.setPaint (Color.BLACK);
    g2.fillRect (0, 0, wd, ht);
    g2.drawImage (gravel [0], 0, this.htBase + 10, wd, ht - this.htBase - 10, null);
    
    this.findCellsInRange ();

    for (int ic = 0; ic < cells.size (); ic++) // Furthest first
    { 
      Cell cell = cells.get (ic);
      
      if (!cell.solid) this.drawFloorAndCeiling (cell);
    }
    
    for (int ic = 0; ic < cells.size (); ic++)
    { 
      Cell cell = cells.get (ic);
      
      if (cell.solid)
      {
        ScreenXYD [] sxyds = new ScreenXYD [4];
        sxyds [0] = cell.sxydNW;
        sxyds [1] = cell.sxydNE;
        sxyds [2] = cell.sxydSE;
        sxyds [3] = cell.sxydSW;
        Arrays.sort (sxyds); // Descending distance. Draw nearest 2 walls:

        if (Math.abs (sxyds [0].d - sxyds [1].d) > 0.001)
        { // Only draw this wall if the 2 furthest corners
          // are not at about the same distance
          this.drawWall (sxyds [1], sxyds [3], cell.fogNo);
        }
        
        this.drawWall (sxyds [2], sxyds [3], cell.fogNo);
      }
      
      if (this.isOpenAbove (cell.xg, cell.yg)) this.drawLadder (cell);
    }
    
    for (int i = 0; i < this.drawLater.size (); i++)
    {
      Later o = this.drawLater.get (i);
      
      if (o.obj instanceof BufferedImage[])
      {
        G2.drawImage (g2, (BufferedImage []) o.obj, o.x, o.y, o.w, o.h, o.fogNo);
      }
      else if (o.obj instanceof RgbMeter)
      {
        G2.drawImage (g2, imMeter, o.x, o.y, o.w, o.h, o.fogNo);
        RgbMeter.RgbTarget target = FOREST.rgbMeter.createTarget (o.x, o.y, o.x + o.w, o.y + o.h);
        FOREST.canvas.addTarget (target);
      }
    }
    
    SCENE.drawCompass (g2);
    FOREST.rgbMeter.draw (g2, 0, 0);
    FOREST.canvas.repaint ();
    long dt = new Date ().getTime () - t0; // ms
    System.out.println (ME.toString () + " Mine drawn in " + dt + "ms");
  } // draw
  
  private void drawWall (ScreenXYD sxyd1, ScreenXYD sxyd2, double fogNo)
  {
    if (Math.abs (sxyd1.db) >= 90 && Math.abs (sxyd2.db) >= 90) return; // All offscreen
    
    ScreenXYD base1 = sxyd1, base2 = sxyd2, base3, top1, top2, top3, tmp;
    PointInt tL, bL, tR, bR;
    
    if (base1.db > base2.db) 
    {
      base1 = sxyd2; base2 = sxyd1; 
    } // base1 smaller db
    
    // Avoid cos(db) close to 0:
    if (Math.abs (base1.db + 90) < 0.1) base1.db = -90.1;
    else if (Math.abs (base1.db - 90) < 0.1) base1.db = 90.1;
    
    if (Math.abs (base2.db + 90) < 0.1) base2.db = -90.1;
    else if (Math.abs (base2.db - 90) < 0.1) base2.db = 90.1;
    
    int state = 0;
    //double d12, d13;
    double angleC = 60;//degrees
    double dx, dy, ix3, iy3, s1, s2, frac;
    
    if (base2.db < 45 && base1.db < base2.db - 180)
    {
      state = 1; tmp = base1; base1 = base2; base2 = tmp;
    } 
    else if (base1.db > -45 && base2.db > base1.db + 180)
    {
      state = 2; tmp = base1; base1 = base2; base2 = tmp; 
    }
    else if (base1.db < 45 && base2.db > 90)
    {
      state = 3;
    }
    else if (base2.db > -45 && base1.db < -90)
    {
      state = 4;
    }

    switch (state)
    {
    case 0: // All on screen
      top1 = this.getScreenXYD (base1.x0, base1.y0, this.wallHt);
      top2 = this.getScreenXYD (base2.x0, base2.y0, this.wallHt);
      tL = new PointInt (top1.x, top1.y);
      bL = new PointInt (base1.x, base1.y);
      tR = new PointInt (top2.x, top2.y);
      bR = new PointInt (base2.x, base2.y);
      UTIL.skewHoriz (imWall, this.im, tL, bL, tR, bR, 0, -1, fogNo);
      this.perhapsHideObj (base1, base2);
      break;
  case 1:// Part offscreen right
  case 3:
      dx = base2.x0 - base1.x0; dy = base2.y0 - base1.y0;
      //d12 = Math.sqrt (dx * dx + dy * dy);
      s1 = Math.sin ((angleC - base1.db) * UTIL.DEG2RAD);
      s2 = Math.sin ((base2.db - angleC) * UTIL.DEG2RAD);
      frac = s1 * base1.d / (s1 * base1.d + s2 * base2.d);  // correct for case 5
      //d13 = frac * d12;
      ix3 = base1.x0 + frac * dx;
      iy3 = base1.y0 + frac * dy;
      base3 = this.getScreenXYD (ix3, iy3, 0);
      top1 = this.getScreenXYD (base1.x0, base1.y0, this.wallHt);
      top3 = this.getScreenXYD (base3.x0, base3.y0, this.wallHt);
      tL = new PointInt (top1.x, top1.y);
      bL = new PointInt (base1.x, base1.y);
      tR = new PointInt (top3.x, top3.y);
      bR = new PointInt (base3.x, base3.y);
      UTIL.skewHoriz (imWall, this.im, tL, bL, tR, bR,
                      0, (int) Math.round (frac * imWall [0].getWidth ()), fogNo);
      this.perhapsHideObj (base1, base3);
      break;
    case 2:  // Part offscreen left
    case 4:
      dx = base2.x0 - base1.x0; dy = base2.y0 - base1.y0;
      //d12 = Math.sqrt (dx * dx + dy * dy);
      s1 = Math.sin ((angleC + base2.db) * UTIL.DEG2RAD);
      s2 = Math.sin ((-base1.db - angleC) * UTIL.DEG2RAD);
      frac = s1 * base2.d / (s2 * base1.d + s1 * base2.d);
      //double d23 = frac * d12;
      ix3 = base2.x0 - frac * dx;
      iy3 = base2.y0 - frac * dy;
      base3 = this.getScreenXYD (ix3, iy3, 0);
      top2 = this.getScreenXYD (base2.x0, base2.y0, this.wallHt);
      top3 = this.getScreenXYD (base3.x0, base3.y0, this.wallHt);
      tL = new PointInt (top3.x, top3.y);
      bL = new PointInt (base3.x, base3.y);
      tR = new PointInt (top2.x, top2.y);
      bR = new PointInt (base2.x, base2.y);
      UTIL.skewHoriz (imWall, im, tL, bL, tR, bR,
                      (int) Math.round ((1.0 - frac) * imWall [0].getWidth ()),
                      imWall [0].getWidth () - 1, fogNo);
      this.perhapsHideObj (base3, base2);
      break;
    }

  } // drawWall

  private void drawFloorAndCeiling (Cell cell)
  {
    Color stroke = Color.BLACK;
    ScreenXYD sxydC = this.getScreenXYD (cell.xg, cell.yg, 0);
    ScreenXYD sxydE = this.getScreenXYD (cell.xg + 8, cell.yg, 0);
    ScreenXYD sxydS = this.getScreenXYD (cell.xg, cell.yg - 8, 0);
    ScreenXYD sxydW = this.getScreenXYD (cell.xg - 8, cell.yg, 0);
    ScreenXYD sxydN = this.getScreenXYD (cell.xg, cell.yg + 8, 0);
    
    TILE.setAndDraw (cell.sxydNE.x, cell.sxydNE.y, sxydE.x, sxydE.y,
            sxydC.x, sxydC.y, sxydN.x, sxydN.y, g2, null, stroke);
    TILE.setAndDraw (cell.sxydSE.x, cell.sxydSE.y, sxydS.x, sxydS.y,
            sxydC.x, sxydC.y, sxydE.x, sxydE.y, g2, null, stroke);
    TILE.setAndDraw (cell.sxydSW.x, cell.sxydSW.y, sxydW.x, sxydW.y,
            sxydC.x, sxydC.y, sxydS.x, sxydS.y, g2, null, stroke);
    TILE.setAndDraw (cell.sxydNW.x, cell.sxydNW.y, sxydN.x, sxydN.y,
            sxydC.x, sxydC.y, sxydW.x, sxydW.y, g2, null, stroke);
    
//    if (/*forest.estate >= 63 &&*/ cell.xg === 20384 && cell.yg === 11808) this.drawChest (g2, cell);
    
    if (Math.abs (cell.db) < 50 && cell.d > 8)
    {
      double scale = 10 / cell.d;
      int w = (int) Math.round (light [0].getWidth () * scale);
      int h = (int) Math.round (light [0].getHeight () * scale);
      ScreenXYD sxyd = this.getScreenXYD (cell.xg, cell.yg, 0);
      G2.drawImage (g2, light, (int) Math.round (sxyd.x - w * 0.5),
              (int) Math.round (sxyd.y - this.ht11 / cell.d), w, h, cell.fogNo);
      int ufe = ((int) Math.round (UTIL.PI10000 * cell.xg * cell.yg)) & 0xfe;
      
      if (ufe == 6)
      { 
        BufferedImage [] cone = SCENE.cone01;
        int cnw = (int) Math.round (cone [0].getWidth () * scale);
        int cnh = (int) Math.round (cone [0].getHeight () * scale);
        int cnx = sxyd.x - cnw / 2;
        int cny = sxyd.y - cnh;
        drawLater.add (new Later (cone, cnx, cny, cnw, cnh, cell.d, cell.fogNo));
      }
      else if (ufe == 12)
      {
        if (!FOREST.rgbMeter.isFound ())
        {
          int rgbw = (int) Math.round (imMeter [0].getWidth () * scale);
          int rgbh = (int) Math.round (imMeter [0].getHeight () * scale);
          int rgbx = sxyd.x - rgbw / 2;
          int rgby = sxyd.y - rgbh;
          drawLater.add (new Later (FOREST.rgbMeter, rgbx, rgby, rgbw, rgbh, cell.d, cell.fogNo));
        }
      }
    }
  } // drawFloorAndCeiling
  
  private void drawLadder (Cell cell)
  {
    this.ladderPt = new PointInt (cell.xg - 6, cell.yg - 6); // SW corner
    ScreenXYD lSxyd = this.getScreenXYD (this.ladderPt.x, this.ladderPt.y, 0);
    double scale = 10 / lSxyd.d;
    int w2 = (int)Math.round (ladder [0].getWidth () * scale * 0.5);
    int h = (int)Math.round (ladder [0].getHeight () * scale);
    this.drawLater.add (new Later (ladder, lSxyd.x - w2, lSxyd.y - h,
                        w2 * 2, h, cell.d, cell.fogNo));
  } // drawLadder

  private void perhapsHideObj (ScreenXYD baseL, ScreenXYD baseR)
  { 
    for (int i = 0; i < drawLater.size (); i++)
    { 
      Later o = drawLater.get (i); // Hidden by wall?
      
      if ((baseL.d < o.d || baseR.d < o.d) && baseL.x < (o.x + o.w) && baseR.x > o.x) 
      {
        drawLater.remove (i);
      }
    }
  } // perhapsHideObj

  protected void forward ()
  {
    int st = ME.stride;
    double testX = ME.x + st * ME.sinb;
    double testY = ME.y + st * ME.cosb;
    
    if (!this.rockWithinR ((int) Math.round (testX), (int) Math.round (testY), 1)) // reduces artefacts
    {
      ME.x = testX; ME.y = testY;
      
      if (null != this.ladderPt 
       && new Point (ladderPt).distance (new Point (ME.x, ME.y)) < 4)
      {
        imCopy = new BufferedImage (wd, ht, im.getType ());
        WritableRaster wr = imCopy.getRaster ();
        im.copyData (wr); // Then imCopy is a copy of the current mine view
        this.yStep = 0; 
        stepUp ();
      }
      else
      {
        this.draw ();
      }
    }
    else Util.message ("SORRY", "You cannot go through solid rock!");
  } // forward

  private boolean rockWithinR (int x, int y, int r)
  {
    for (int ix = x - r; ix <= x + r; ix++)
    {
      for (int iy = y - r; iy <= y + r; iy++)
      {
        PointInt meg = getGridXY (ix, iy);
        
        if (!this.isOpen (meg.x, meg.y)) return true;
      }
    }
    
    return false;
  } // rockWithinR

  public void enterMine ()
  { 
    PointInt meg = getGridXY (ME.x, ME.y);
    
    // Make sure we are exactly in the mineshaft
    if (!isOpen (meg.x, meg.y)) { meg.x += 16; }
    if (!isOpen (meg.x, meg.y)) { meg.y += 16; } 
    if (!isOpen (meg.x, meg.y)) { meg.x -= 32; }
    if (!isOpen (meg.x, meg.y)) { meg.y -= 32; }
if (!isOpen (meg.x, meg.y)) { System.out.println ("Problem positioning for mine at " + meg); }

    ME.x = meg.x; ME.y = meg.y;
    
    if (ME.b < 0) ME.b += 360;
    
    FOREST.view = VIEWS.MINE;
    FOREST.uiLocked = true;
    yStep = 0; dyStep = 10;
    stepDown ();
  } // enterMine

  private final ActionListener stepDownAction = new ActionListener () 
  {
    @Override
    public void actionPerformed (ActionEvent evt) 
    {
      FOREST.mine.stepDown ();
    }
  };
      
  private void stepDown ()
  { 
    if (yStep < ht)
    {
      BufferedImage sceneIm = SCENE.getImage ();
      g2.drawImage (sceneIm, 0, -yStep, null);
      g2.drawImage (imWall [0], 0, ht - yStep, null);
      FOREST.canvas.repaint ();
      yStep += dyStep;
      Timer timer = new Timer (40, stepDownAction);
      timer.setRepeats (false);
      timer.start ();
    }
//    else if (flooded)
//    { message ("SPLOSH  GLUG  GLUG")
//      setTimeout (init, 5000); // restart
//    }
    else
    {
      FOREST.uiLocked = false;
      draw ();
    }
  } // stepDown

  private final ActionListener stepUpAction = new ActionListener () 
  {
    @Override
    public void actionPerformed (ActionEvent evt) 
    {
      FOREST.mine.stepUp ();
    }
  };
      
  private void stepUp ()
  {
    if (yStep < ht)
    {
      g2.drawImage (this.imCopy, 0, yStep, null);
      g2.drawImage (imWall [0], 0, yStep - 600, null);
      FOREST.canvas.repaint ();
      yStep += dyStep;
      Timer timer = new Timer (40, stepUpAction);
      timer.setRepeats (false);
      timer.start ();
    }
    else
    {
      ME.x += 5 * ME.sinb; // Move away from mineshaft
      ME.y += 5 * ME.cosb; //
      FOREST.uiLocked = false;
      FOREST.toScene (); 
    }
  } // stepUp

  private class Cell implements Comparable<Cell>
  {
    public int xg, yg;
    public double d, db, fogNo;
    public boolean solid;
    public ScreenXYD sxydNW, sxydNE, sxydSW, sxydSE;
    
    public Cell (int xg, int yg, double d, double db, boolean solid, double fogNo,
                 ScreenXYD sxydNW, ScreenXYD sxydNE, ScreenXYD sxydSE, ScreenXYD sxydSW)
    {
      this.xg = xg; this.yg = yg; this.d = d; this.db = db;
      this.fogNo = fogNo;
      this.solid = solid;
      this.sxydNW = sxydNW;
      this.sxydNE = sxydNE;
      this.sxydSE = sxydSE;
      this.sxydSW = sxydSW;
    } // Cell

    @Override
    public int compareTo (Cell other) 
    {
      if (this.d < other.d) return 1;
      if (this.d > other.d) return -1;
      return 0;
    } // compareTo
            
    @Override
    public String toString ()
    {
      return "Cell: xg:" + xg + ", yg:" + yg + ", d:" + UTIL.DF2.format (d) + 
             ", db:" + UTIL.DF2.format (db) + ", solid:" + solid + 
             ", fogNo:" + UTIL.DF2.format (fogNo) +
             "\nNW:" + sxydNW +
             "\nNE:" + sxydNE +
             "\nSE:" + sxydSE +
             "\nSW:" + sxydSW;
    } // toString

  } // Cell
  
  /** Just a record */
  private class ScreenXYD implements Comparable<ScreenXYD>
  {
    public int x, y;
    public double d, db, x0, y0;
    
    // (sx, sy) is screen position, (x0, y0) is original ground position
    public ScreenXYD (int sx, int sy, double d, double db, double x0, double y0)
    {
      this.x = sx; this.y = sy;
      this.x0 = x0; this.y0 = y0;
      this.d = d; this.db = db;
    } // ScreenXYD
    
    @Override
    public int compareTo (ScreenXYD other) 
    { 
      if (this.d < other.d) return 1;
      if (this.d > other.d) return -1;
      return 0;
    } // compareTo
    
    @Override
    public String toString ()
    {
      return "ScreenXYD: x:" + x + ", y:" + y + ", d:" + UTIL.DF2.format (d) +
             ", db:" + UTIL.DF2.format (db) + 
             ", x0:" + UTIL.DF2.format (x0) + ", y0:" + UTIL.DF2.format (y0);
    } // toString

  } // ScreenXYD
  
  private class Later
  {
//    public BufferedImage [] im;
    public Object obj; // May be BufferedImage[] or RgbMeter
    public int x, y, w, h;
    public double d, fogNo;

//    public Later (BufferedImage [] im, int x, int y, int w, int h, double d, double fogNo)
    public Later (Object obj, int x, int y, int w, int h, double d, double fogNo)
    {
//      this.im = im;
      this.obj = obj;
      this.x = x; this.y = y;
      this.w = w; this.h = h;
      this.d = d;
      this.fogNo = fogNo;
    } // Later
    
  } // Later
  
} // Mine
