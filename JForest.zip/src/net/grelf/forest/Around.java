/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import static java.util.Arrays.sort;

/* One object of this type is constructed at the start to avoid reallocating
 * big arrays every time a scene is drawn */
public class Around
{
  public static final int MAX_RANGE = 400;
  private static final double RAD2DEG = 180.0 / Math.PI;
  private final ScenePoint around [][];
  private final ScenePointBase sorted [];
  private int xOffset, yOffset;
  public static int xyd60, xyd120, xyd200, xyd300, xyd400;

  public Around ()
  { 
    int wd = 2 * MAX_RANGE + 1;
    this.around = new ScenePoint [wd][wd];
    this.sorted = new ScenePointBase [wd * wd];
    boolean odd = false;
    int i = 0; 
    
    for (int ix = 0, x = -MAX_RANGE; ix < wd; ix++, x++) 
    {
      int x2 = x * x;
    
      for (int iy = 0, y = -MAX_RANGE; iy < wd; iy++, y++)
      {
        int y2 = y * y;
        double d = Math.sqrt (x2 + y2);
        double b = Math.atan2 (x, y) * RAD2DEG;
        this.around [ix][iy] = new ScenePoint (d, b, x, y, odd);
        this.sorted [i] = new ScenePointBase (d, b, x, y); // NOT the same objects
        odd = !odd;
        i++;
      }
      
      odd = !odd;
    }
    
    sort (sorted);// Nearest first - see comparator in ScenePoint
/* Check:
System.out.print (sorted [0].d + ",");//0
System.out.print (sorted [100].d + ",");//5.7
System.out.print (sorted [1000].d + ",");//17.9
System.out.print (sorted [10000].d + ",");//56.4
*/
    int j = 0;
    while (sorted [j].d <= 60) j++; xyd60 = j - 1;
    while (sorted [j].d <= 120) j++; xyd120 = j - 1;
    while (sorted [j].d <= 200) j++; xyd200 = j - 1;
    while (sorted [j].d <= 300) j++; xyd300 = j - 1;
    xyd400 = sorted.length - 1;
/* Check:
System.out.println (xyd60 + ", " + xyd120 + ", " + xyd200 + ", " + xyd300 + ", " + xyd400);
*/
}

  public ScenePointBase lookupXYD (int i) 
  {
    return this.sorted [i];
  }

  /* Use at the start of drawing a new scene
   * NB: mex, mey are rounded observer coordinates
   * MAX_RANGE indexes the middle of the array */
  public void init (int mex, int mey)
  {
    this.xOffset = MAX_RANGE - mex;
    this.yOffset = MAX_RANGE - mey;
//System.out.println ("Offsets: " + xOffset + ", " + yOffset);
  };

  /* Get a reference to the ScenePoint object at (x, y) */
  public ScenePoint aroundGet (int x, int y)
  {
    return this.around [x + this.xOffset][y + this.yOffset];
  }

  /* Set fields of the ScenePoint at (x, y) and return it */
  public ScenePoint aroundSet (double distance, double bearing, int x, int y, boolean odd)
  {
    ScenePoint sp = this.around [x + this.xOffset][y + this.yOffset];
    sp.x = x;
    sp.y = y;
    sp.d = distance;
    sp.b = bearing;
    sp.o = odd;
    sp.fogNo = 0;
    sp.tr = null;
    sp.drawn = false;
    sp.clear = false;
    sp.ahead = false;
    sp.fnd = -1;
    return sp;
  } // aroundSet

} // Around