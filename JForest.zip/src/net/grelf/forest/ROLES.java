/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public enum ROLES { EXPLORER, ORIENTEER, PLANNER, ENGINEER }
