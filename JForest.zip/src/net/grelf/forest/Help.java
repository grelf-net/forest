/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/** Temporary quick start text */
public class Help 
{
  private static final Forest FOREST = Forest.getInstance ();
  
  public Help ()
  {
    JFrame frame = new JFrame ();
    frame.setTitle (" The Forest - QUICK START ");
    frame.setIconImage (FOREST.getIconImage ());
    JComponent panel = new JPanel (new BorderLayout ());
    JTextArea textArea = new JTextArea ();
    panel.add (textArea, BorderLayout.NORTH);
    panel.add (new Legend (), BorderLayout.SOUTH);
    JScrollPane scrollPane = new JScrollPane (panel);
    textArea.setEditable (false);
    textArea.setFont (new Font ("SansSerif", Font.PLAIN, 14));
    
    textArea.append (" Go between MAP or SCENE using key G.\n");
    textArea.append (" Move around using arrow keys (or W, A, S, D).\n");
    textArea.append (" Keys may be upper or lower case.\n\n");
    textArea.append (" In the MAP:\n");
    textArea.append (" Key J jumps observer to map centre\n");
    textArea.append (" Key C centres the map on the observer\n");
    textArea.append (" The map is to orienteering standards (legend below)\n");
    textArea.append (" Scale: the magnetic north lines are 300m apart.\n\n");
    textArea.append (" In the SCENE:\n");
    textArea.append (" Note that the down arrow (or S) turns 180 degrees\n");
    textArea.append (" Keys +/=, 0, -   look up, level, down\n");
    textArea.append (" Stride takes account of terrain & steepness.\n");
    textArea.append (" If within 7m of a helicopter, key Enter\n");
    textArea.append (" then you can use PgUp, PgDn (and Esc after landing).\n\n");
    textArea.append (" Fall down mineshafts to explore underground (with\n");
    textArea.append (" map). Ladders enable you to get back above ground.\n\n");
    textArea.append (" This version does not yet allow entering buildings\n");
    textArea.append (" and no orienteering courses yet (work in progress)\n");

    JScrollBar vert = scrollPane.getVerticalScrollBar ();
    vert.setValue (vert.getMinimum ()); // Does not seem to work
    frame.setContentPane (scrollPane);
    frame.setPreferredSize (new Dimension (400, 520));
    frame.pack (); 
    frame.setLocation (FOREST.canvas.width + 1, 120);
    frame.setVisible (true);
  }// Help

  private class Legend extends JComponent
  {
    private BufferedImage legend;
    private int width, height;

    public Legend ()
    {
      legend = FOREST.map.getLegend ();
      width = legend.getWidth ();
      height = legend.getHeight ();
      setPreferredSize (new Dimension (width, height));
    } // Legend
      
    @Override
    public void paint (Graphics g)
    { 
      Graphics2D g2 = (Graphics2D) g;
      g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g2.drawImage (legend, 0, 0, width, height, null);
    } //paint

  } // Legend
    
} // Help
