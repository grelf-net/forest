/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import static java.awt.image.BufferedImage.TYPE_BYTE_INDEXED;
import java.awt.image.ColorModel;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;

public class G2 //extends Graphics2D // not possible with sun.java2d.SunGraphics2D (NetBeans)
{
  public static final int N_FOG_LEVELS = 8; 
  public static boolean doFog = false;   // Set these before use
  public static Color sky = COLOURS.SKY; //
  
  private G2 () {} // Static only
  
  public static void drawImage (Graphics2D g2, BufferedImage [] ims,
                                int x, int y, int wd, int ht, double fogNo)
  {
    if (0.0 == fogNo || !doFog) g2.drawImage (ims [0], x, y, wd, ht, null); // unfogged
    else
    {
      BufferedImage fogged;
      int iFogNo = (int) Math.round (fogNo * (N_FOG_LEVELS - 1));
      
      if (null == ims [iFogNo]) // Fogged version not yet created, create it now:
      { 
        ims [iFogNo] = createFoggedIm (ims [0], fogNo);
      }

      fogged = ims [iFogNo];
      g2.drawImage (fogged, x, y, wd, ht,  null);
    }
  } // drawImage (with fog)
    
  public static BufferedImage createFoggedIm (BufferedImage im0, double fogNo)
  {
    BufferedImage fogged, argb;
    int skyR = sky.getRed ();
    int skyG = sky.getGreen ();
    int skyB = sky.getBlue ();
    int wdim0 = im0.getWidth ();
    int htim0 = im0.getHeight ();
    Raster wrSrc = im0.getRaster ();
    fogged = new BufferedImage (wdim0, htim0, BufferedImage.TYPE_INT_ARGB);
    WritableRaster wrDst = fogged.getRaster ();
    int [] px = new int [4];

    for (int iy = 0; iy < htim0; iy++)
    {
      for (int ix = 0; ix < wdim0; ix++)
      {
        wrSrc.getPixel (ix, iy, px);

        px [0] += (int) Math.round ((skyR - px [0]) * fogNo);
        px [1] += (int) Math.round ((skyG - px [1]) * fogNo);
        px [2] += (int) Math.round ((skyB - px [2]) * fogNo);
        // Don't change alpha

        wrDst.setPixel (ix, iy, px);
      }
    }

    return fogged;
  } // createFoggedIm
  
} // G2
