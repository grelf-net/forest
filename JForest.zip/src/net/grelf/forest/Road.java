/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import net.grelf.Util;

public class Road 
{
  private static ArrayList<Road> roads;
  private static final Forest FOREST = Forest.getInstance ();
  private final ArrayList <PointInt> path;
  private static final float [] DASH = {12F, 4F};
  protected static final BasicStroke STROKE_DASH = 
          new BasicStroke (2.0F, BasicStroke.CAP_BUTT, BasicStroke.JOIN_ROUND, 1, DASH, 0);
  
  public Road ()
  {
    this.path = new ArrayList<> (); 
  } // Road

  private void addPoint (int x, int y) 
  {
    this.path.add (new PointInt (x, y));
  } // addPoint

  public void draw (Graphics2D g2)
  {
    if (this.path.size () < 2) return;
    
    Map map = FOREST.map;
    boolean onMap = false;
    Canvas cnv = FOREST.canvas;
    int wd = cnv.width;
    int ht = cnv.height;
    int nPts = this.path.size ();
    int [] xs = new int [nPts]; 
    int [] ys = new int [nPts];
    PointInt pt = map.mapPt (this.path.get (0));
    xs [0] = pt.x;
    ys [0] = pt.y;
    onMap = pt.x >= 0 && pt.x <= wd && pt.y >= 0 && pt.y <= ht;

    for (int i = 1; i < this.path.size (); i++)
    {
      pt = map.mapPt (this.path.get (i));
      xs [i] = pt.x;
      ys [i] = pt.y;
      onMap = onMap || (pt.x >= 0 && pt.x <= wd && pt.y >= 0 && pt.y <= ht);
    }
      
    if (onMap)
    {
      g2.setPaint (Color.BLACK);
      g2.setStroke (STROKE_DASH);
      g2.drawPolyline (xs, ys, nPts);// Not closed polygon!
      g2.setStroke (UTIL.STROKE1);
    }
  } // draw

  /* Place a road in the terrain */
  public static Road buildRoad (int [] xy)// array of alternate x,y integers
  {
    if (0 != xy.length % 2) 
    {
      Util.message ("ERROR", "Road xy not in pairs");
      return null;
    }
    
    Road rd = new Road ();
    int x = xy [0], y = xy [1], prevX, prevY;
    rd.addPoint (x, y);
    
    for (int i = 2; i < xy.length - 1; i += 2)
    {
      prevX = x; prevY = y;
      x = xy [i]; y = xy [i + 1];
      rd.addPoint (x, y);
      paveLine (prevX, prevY, x, y);
    }
    
    return rd;
  } // buildRoad

  private static void paveLine (int x0, int y0, int x1, int y1)
  {
    double dx = x1 - x0, dy = y1 - y0;
    double d = Math.sqrt (dx * dx + dy * dy);
    dx = dx / d; dy = dy / d;
    double x = x0, y = y0;
    
    for (int i = 0; i <= d; i++)
    {
      pave ((int) Math.round (x), (int) Math.round (y), 2);
      x += dx; y += dy;
    }
  } // paveLine

  private static void pave (int x, int y, int halfWd)
  { 
    Terrain ft = FOREST.terrain;
    
    for (int iy = y - halfWd; iy <= y + halfWd; iy++)
    {
      for (int ix = x - halfWd; ix <= x + halfWd; ix++)
      {
        ft.place (ix, iy, TERRAINS.ROAD);
      }
    }
  } // pave

  public static void drawRoads (Graphics2D g2)
  {
    for (Road road : roads)
    {
      road.draw (g2);
    }
  } // drawRoads
  
  public static void loadFixedRoads ()
  {
    roads = new ArrayList<> ();
    
    for (int [] fixedRoad : fixedRoads) 
    {
      roads.add (buildRoad (fixedRoad));
    }
  } // loadFixedRoads

  public static void clearRoads ()
  {
    FOREST.terrain.removeAll (TERRAINS.ROAD);
  } // clearRoads
  
  private static final int [][] fixedRoads = 
  {
{15214,6242, 15271,6201, 15328,6153, 15373,6106},

{15220,5814, 15184,5863, 15145,5913, 15103,5965, 15060,6002, 15015,6033, 14994,6051,
 14983,6089, 14987,6108, 15003,6127, 15031,6147, 15035,6174, 15027,6208, 15030,6220,
 15078,6243, 15120,6264, 15152,6263, 15181,6244, 15214,6242, 15225,6254, 15227,6299,
 15226,6343, 15227,6398, 15219,6420, 15203,6437, 15172,6471, 15143,6505, 15128,6528,
 15131,6569, 15123,6621, 15122,6648, 15125,6670, 15141,6698, 15143,6714, 15132,6737,
 15110,6762, 15083,6793, 15063,6817, 15058,6834, 15031,6878, 15010,6928, 14983,6960,
 14955,6995, 14930,7032, 14905,7079},

{15376,6039, 15392,6001, 15410,5982, 15438,5968, 15465,5957, 15495,5947, 15545,5948,
 15583,5961, 15627,5966, 15669,5961, 15719,5951, 15759,5943, 15791,5942, 15816,5962,
 15844,5983, 15894,5998, 15922,5998, 15945,6013}
  };

} // Road
