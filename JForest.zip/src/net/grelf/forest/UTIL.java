/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.text.DecimalFormat;
import net.grelf.Util;

/** Some useful static constants and functions */
public class UTIL
{
  public static final double DEG2RAD = Math.PI / 180.0;
  public static final double RAD2DEG = 180.0 / Math.PI;
  public static final double PI10000 = Math.PI * 1.E4;
  public static final BasicStroke STROKE1 = new BasicStroke (1F);
  public static final BasicStroke STROKE2 = new BasicStroke (2F);
  public static final BasicStroke STROKE3 = new BasicStroke (3F);
  public static final BasicStroke STROKE4 = new BasicStroke (4F);
  public static final BasicStroke STROKE5 = new BasicStroke (5F);
  public static final DecimalFormat DF2 = new DecimalFormat ("0.00");

  public static Color fog (Color unfogged, double fogNo)// fogNo, 0..1
	{
    if (fogNo == 0.0) return unfogged;
    
		int r = unfogged.getRed ();
		int g = unfogged.getGreen ();
		int b = unfogged.getBlue ();
		r += (int) Math.floor ((G2.sky.getRed () - r) * fogNo);
		g += (int) Math.floor ((G2.sky.getGreen () - g) * fogNo);
		b += (int) Math.floor ((G2.sky.getBlue () - b) * fogNo);
		return new Color (r, g, b, unfogged.getAlpha ());
	} // fog
  
  public static Color fog (int r, int g, int b, double fogNo)// fogNo, 0..1
  {
    if (fogNo == 0.0) return new Color (r, g, b, 255);
  
    int fr = r + (int) Math.floor ((G2.sky.getRed () - r) * fogNo);
    int fg = g + (int) Math.floor ((G2.sky.getGreen () - g) * fogNo);
    int fb = b + (int) Math.floor ((G2.sky.getBlue () - b) * fogNo);
    return new Color (fr, fg, fb, 255);
  } // fog

  /* Map part of image into perspective shape defined by points
  * topleft, bottomleft, topright & bottom right (.x and .y).
  * Bottom must have higher y than top (screen coordinates).
  * Left & right edges remain vertical (tL.x == bL.x and tR.x == bR.x).
  * If srcMinX or srcMaxX is negative the whole width of source image is used.*/
  public static void skewHoriz (BufferedImage [] srcIm, BufferedImage dstIm,
          final PointInt tL, final PointInt bL, 
          final PointInt tR, final PointInt bR,
          int srcMinX, int srcMaxX, double fogNo)
  {
    if (tL.x != bL.x || tR.x != bR.x) 
    {
      Util.message ("ERROR", "Non-vertical edges for skewHoriz");
      return;
    }
    
    if (bL.y < tL.y || bR.y < tR.y) 
    {
      Util.message ("ERROR", "y coords reversed for skewHoriz");
      return;
    }
    
    int iFogNo = 0;

    if (fogNo > 0)
    {
      iFogNo = (int) Math.round (fogNo * (G2.N_FOG_LEVELS - 1));  
    }

    BufferedImage fogged = srcIm [iFogNo];
    
    if (null == fogged)
    { 
      srcIm [iFogNo] = G2.createFoggedIm (srcIm [0], fogNo);
      fogged = srcIm [iFogNo];
    }
    
    if (srcMinX < 0 || srcMaxX < 0)
    {
      srcMinX = 0; 
      srcMaxX = fogged.getWidth () - 1;
    }
    
    int srcHt = fogged.getHeight ();
    int dstImWd = dstIm.getWidth ();
    int dstImHt = dstIm.getHeight ();
    double dstWd = tR.x - tL.x;
    
    if (dstWd == 0)
    {
      System.out.println ("dstWd == 0 in UTIL.skewHoriz(): tR = " + tR + ", tL = " + tL);
      return;
    }

    Raster src = fogged.getRaster ();
    WritableRaster dst = dstIm.getRaster ();
    int [] px = new int [4];
    
    double dyT = (tR.y - tL.y) / dstWd;
    double dyB = (bR.y - bL.y) / dstWd;
    double dSrcX = (srcMaxX - srcMinX) / dstWd;

    if (tL.x < tR.x)
    {
      // Vertical strips, varying length, left to right:
      for (double dstX = tL.x, srcX = srcMinX, dstYT = tL.y, dstYB = bL.y;
           (dstX <= tR.x) && (srcX <= srcMaxX); dstX++)
      {
        if (dstX >= 0 && dstX < dstImWd)
        {
          double dSrcY = srcHt / (double) (dstYB - dstYT);

          for (double dstY = dstYT, srcY = 0; (dstY <= dstYB) && (srcY < srcHt); dstY++)
          {
            if (dstY >= 0 && dstY < dstImHt)
            {
              src.getPixel ((int)srcX, (int)srcY, px);
              dst.setPixel ((int)dstX, (int)dstY, px);
            }
            
            srcY += dSrcY;
          } 
        }

        srcX += dSrcX;
        dstYT += dyT;
        dstYB += dyB;
      } 
    }
    else
    { // Right to left:
      for (double dstX = tL.x, srcX = srcMaxX, dstYT = tL.y, dstYB = bL.y;
           (dstX >= tR.x) && (srcX >= srcMinX); dstX--)
      {
        if (dstX >= 0 && dstX < dstImWd)
        {
          double dSrcY = srcHt / (double) (dstYB - dstYT);

          for (double dstY = dstYT, srcY = 0; (dstY <= dstYB) && (srcY < srcHt); dstY++)
          {
            if (dstY >= 0 && dstY < dstImHt)
            {
              src.getPixel ((int)Math.floor (srcX), (int)Math.floor (srcY), px);
              dst.setPixel ((int)Math.floor (dstX), (int)Math.floor (dstY), px);
            }
            
            srcY += dSrcY;
          } 
        }

        srcX += dSrcX; // Should be < 0 in this case
        dstYT += dyT;
        dstYB += dyB;
      }
    }
  } // skewHoriz

  /* Plot the symbol - may be on legend or map */
  public static void plotObserver (Graphics2D g2, int x, int y, int b)
  {
    int b0 = b - 90;
    g2.setPaint (Color.RED);
    g2.setStroke (STROKE2);
    g2.drawArc(x - 10, y - 10, 20, 20, 45 - b0, 270);
    double b0rad = b0 * DEG2RAD;
    double bp45rad = (b0 + 45) * DEG2RAD;
    double bm45rad = (b0 - 45) * DEG2RAD;
    int xPeak = (int) Math.round (x + 20 * Math.cos(b0rad));
    int yPeak = (int) Math.round (y + 20 * Math.sin(b0rad));
    g2.drawLine(xPeak, yPeak, (int) Math.round (x + 11 * Math.cos (bp45rad)),
                (int) Math.round (y + 11 * Math.sin (bp45rad)));
    g2.drawLine(xPeak, yPeak, (int) Math.round (x + 11 * Math.cos(bm45rad)),
                (int) Math.round (y + 11 * Math.sin (bm45rad)));
  } // plotObserver
  
} // UTIL
