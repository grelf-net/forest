/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Iterator;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.FileImageInputStream;

public class ImageLoader
{
public static BufferedImage loadImage (String filename)
{
  return ImageLoader.load ("im" + File.separator + filename);
}

	/* Get the format name as used by ImageIO readers, from the file extension. */
	private static String getFormat (String filename)
	{
    int dot = filename.lastIndexOf (".");
    String ext = filename.substring (dot).toLowerCase ();    
    
    if (ext.equals (".jpg")) return "jpeg";
    else if (ext.equals (".png")) return "png";
    
    return "";
	}

	/* Load the first image in the file or null if failed. */
	public static BufferedImage load (String imFilePath)
	{
    java.io.File file = new java.io.File (imFilePath);
	
    if (!file.exists ())
    {
      net.grelf.Util.warning ("Error",
              "File " + file.getPath () + "\ndoes not exist");
      return null;
    }

    BufferedImage bim = null;
    
    try
    {
      String formatName = getFormat (file.getName ());

      if (null != formatName)
      {
        Iterator <ImageReader> it =
          ImageIO.getImageReadersByFormatName (formatName);
        // Similar ImageIO.getImageReadersBySuffix () doesn't seem to work

        IIOImage iioi = null;
        ImageReader reader = null;

        while (it.hasNext () && null == iioi)
        {
          reader = (ImageReader) it.next ();
          reader.setInput (new FileImageInputStream (file));
          int nIms = reader.getNumImages (true);

          if (nIms > 0)
          {
            iioi = reader.readAll (0, null); // First image in file only
          }
        }

        if (null == iioi)
        {
          String s = "No reader available for " + file.getName ();
          net.grelf.Util.warning ("Error", s);
        }
        else
        {
          if (null == iioi.getRenderedImage ())
          {
            if (null != reader) reader.dispose ();
           
            String s = "No image loaded from " + file.getName ();
            net.grelf.Util.warning ("Error", s);
          }
          else
          {
            bim = (BufferedImage) iioi.getRenderedImage ();
            //String readerName = reader.getClass ().getName ();
            //net.grelf.Util.logInfo ("Reader class: {0}", readerName);
            if (null != reader) reader.dispose ();
          }
        }
      }
    }
    catch (java.io.IOException ex)
    {
      net.grelf.Util.logWarning (ex.toString ());
      net.grelf.Util.warning ("Error", "Could not load image " +
              ((null != file) ? file.getPath () : ""));
    }

		return bim;
	} // load

} // ImageLoader
