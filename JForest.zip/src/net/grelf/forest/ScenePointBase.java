/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

/* For holding data about an (x, y) point in the terrain -
 * smaller objects for the sorted list in Around */
public class ScenePointBase implements Comparable<ScenePointBase>
{
  public double d = 0;// = distance from observer
	public double b = 0;// = bearing from observer (degrees clockwise from north)
	public double x = 0;
	public double y = 0;

	public ScenePointBase (double distance, double bearing, double x, double y)
	{
		this.d = distance;
		this.b = bearing;
		this.x = x;
		this.y = y;
	}

  @Override
	public String toString ()
	{
		String s = "x = " + x + ", y = " + y + ", d = " + d + ", b = " + b;
		return s;
	}

  @Override
  public int compareTo (ScenePointBase other) 
  { 
    if (this.d < other.d) return -1;
    if (this.d > other.d) return 1;
    return 0;
  }
  
} // ScenePointBase