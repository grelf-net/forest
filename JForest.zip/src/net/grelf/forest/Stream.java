/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.HashMap;

public class Stream
{
  private static final int RANGE = 5;
  private static final int MIN_STREAM_LENGTH = 10;
  private static final Forest FOREST = Forest.getInstance ();
  private static final HashMap <String, Object> MARSHES = new HashMap<> ();
  
  private static void putMarsh (int x, int y) 
  {
    MARSHES.put (x + "," + y, new Object ());
  }
  
  public static boolean isMarsh (int x, int y)
  {
    return MARSHES.containsKey (x + "," + y);
  }

  protected ArrayList<PointInt> route;
  private boolean marshEnd;
  
  public Stream (int fromX, int fromY)
  {
    PointInt pt = new PointInt (fromX, fromY);
    this.route = new ArrayList<> ();
    this.route.add (pt);
    double ht0 = FOREST.terrain.terra (pt.x, pt.y).height;
    boolean flowing = true;
    
    while (flowing)
    { double htMin = ht0;
      int xMin = pt.x, yMin = pt.y;
      
      for (int ix = pt.x - RANGE; ix <= pt.x + RANGE; ix++)
      {
        for (int iy = pt.y - RANGE; iy <= pt.y + RANGE; iy++)
        {
          if (ix != pt.x && iy != pt.y)
          {
            double ht = FOREST.terrain.terra (ix, iy).height;
            
            if (ht < htMin)
            {
              htMin = ht;
              xMin = ix;
              yMin = iy;
            }
          }
        }
      }
      
      if (htMin < ht0) 
      { //if (tr.atPlace (xMin, yMin) === TERRAINS.STREAM) { flowing = false; this.lakeEnd = false; } // join
        pt = new PointInt (xMin, yMin);
        this.route.add (pt); 
        
        if (htMin <= FOREST.terrain.lakeHt)
        {
          flowing = false;
          this.marshEnd = false;
        }
        else ht0 = htMin;
      }
      else 
      {
        flowing = false;
        
        if (this.route.size () > MIN_STREAM_LENGTH)
        {
          TERRAINS tt = FOREST.terrain.terra (pt.x, pt.y).terrain;
          
          if (tt == TERRAINS.TOWN || tt == TERRAINS.ROAD) return;
          
          this.marshEnd = true;
          
          for (int ix = pt.x - 4; ix <= pt.x + 4; ix++)
          {
            for (int iy = pt.y - 4; iy <= pt.y + 4; iy++)
            {
              putMarsh (ix, iy);
            }
          }
        } 
      }
    }
  } // Stream

  public void drawOnMap (Graphics2D g2)
  { 
    if (this.route.size () > MIN_STREAM_LENGTH)
    {
      g2.setPaint (COLOURS.BLUE);
      PointInt pt = this.route.get (1), prevPt = pt;
      PointInt mapPt = FOREST.map.mapPt (pt);
      PointInt prevMapPt = FOREST.map.mapPt (prevPt);
      
      for (int i = 2; i < this.route.size (); i++)
      { pt = this.route.get (i);
        mapPt = FOREST.map.mapPt (pt); 
        g2.drawLine (prevMapPt.x, prevMapPt.y, mapPt.x, mapPt.y);
        soakLine (prevPt.x, prevPt.y, pt.x, pt.y);
        prevPt = pt;
        prevMapPt = mapPt;
      }

      if (this.marshEnd) FOREST.map.plotMarsh (mapPt.x, mapPt.y);
    } 
  }

  private void soakLine (int x0, int y0, int x1, int y1)
  {
    double dx = x1 - x0, dy = y1 - y0;
    double d = Math.sqrt (dx * dx + dy * dy);
    dx = dx / d; dy = dy / d;
    double x = x0, y = y0;
    
    for (int i = 0; i <= d; i++)
    { 
      soak ((int) Math.round (x), (int) Math.round (y), 1);
      x += dx; y += dy;
    } 
  }

  private void soak (int x, int y, int halfWd)
  {
    for (int iy = y - halfWd; iy <= y + halfWd; iy++)
    {
      for (int ix = x - halfWd; ix <= x + halfWd; ix++)
      {
        if (FOREST.terrain.terra (ix, iy).terrain != TERRAINS.TOWN)
        {
          Object pd = FOREST.terrain.atPlace (ix, iy);
          
          if (pd != TERRAINS.ROAD) FOREST.terrain.place (ix, iy, TERRAINS.STREAM);
        } 
      }
    }
  }

} // Stream
