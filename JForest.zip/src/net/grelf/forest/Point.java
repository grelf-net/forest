/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public class Point 
{
  public double x, y;

  public Point (double x, double y)
  {
    this.x = x;
    this.y = y;
  }
  
  public Point (PointInt pt)
  {
    this.x = pt.x;
    this.y = pt.y;
  }

  @Override
  public String toString ()
  {
    return "(" + this.x + ", " + this.y + ")";
  }

  public double distance (Point otherPt)
  {
    double dx = this.x - otherPt.x;
    double dy = this.y - otherPt.y;
    return Math.sqrt (dx * dx + dy * dy);
  }

  /* Zoom from canvas centre */
  public Point zoom (Canvas canvas, double scale)
  { double wd2 = canvas.width / 2;
    double ht2 = canvas.height / 2;
    return new Point ((this.x - wd2) * scale + wd2, (this.y - ht2) * scale + ht2);
  }

} // Point
