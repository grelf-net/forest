package net.grelf;

// This Java source file is part of the application GRIP, for processing and
// measuring digital photographs.
// GRIP is available free from www.grelf.net - please always quote this URL in
// connection with GRIP.
//
// Copyright (c) Graham T Relf, UK, 2006
//

/** Miscellaneous useful static methods. This class cannot be instantiated. */
public class Util
{
	public static final boolean DEBUG = false;

	private Util () {} // Cannot instantiate.

	private static java.awt.Component owningApp = null;
	private static javax.swing.ImageIcon ownerIcon = null;
	public static void setOwningApp (
          java.awt.Component parent, javax.swing.ImageIcon icon)
	{
		owningApp = parent;
		ownerIcon = icon;
	}

	/** Ask the user for a double value.
    * Returns Double.NaN if user cancelled input. */
	public static double askDouble (String prompt, double initialValue,
                                  double min, double max)
	{
    return askDouble (owningApp, prompt, initialValue, min, max);
  } // askDouble

	/** Ask the user for a double value.
    * Returns Double.NaN if user cancelled input. */
	public static double askDouble (
          java.awt.Component parentComponent, String prompt,
          double initialValue, double min, double max)
	{
		while (true)
		{
			try
			{
				String s = javax.swing.JOptionPane.showInputDialog (
                parentComponent, prompt, "" + initialValue);

				if (null == s || 0 == s.length ()) // Cancelled by user or nothing entered
				{
					return Double.NaN;
				}
				else
				{
					double d = Double.parseDouble (s);

					if (d >= min && d <= max)
					{
						return d;
					}
				}
			}
			catch (NumberFormatException ex) {} // Just to keep looping
		}
	} // askDouble

	/** Ask the user for an int value.
    * Returns Integer.MIN_VALUE if user cancelled input. */
	public static int askInteger (String prompt, int initialValue,
                                int min, int max)
	{
    return askInteger (owningApp, prompt, initialValue, min, max);
  } // askInteger

	/** Ask the user for an int value.
    * Returns Integer.MIN_VALUE if user cancelled input. */
	public static int askInteger (
          java.awt.Component parentComponent, String prompt,
          int initialValue, int min, int max)
	{
		while (true)
		{
			try
			{
				String s = javax.swing.JOptionPane.showInputDialog (
                parentComponent, prompt, "" + initialValue);

				if (null == s || 0 == s.length ()) // Cancelled by user or nothing entered
				{
					return Integer.MIN_VALUE;
				}
				else
				{
					int i = Integer.parseInt (s);

					if (i >= min && i <= max)
					{
						return i;
					}
				}
			}
			catch (NumberFormatException ex) {} // Just to keep looping
		}
	} // askInt

	/** Ask the user for a String of free text.
    * Returns null if user cancelled input. */
	public static String askString (String prompt, String initialValue)
	{
		return askString (owningApp, prompt, initialValue);
	} // askString

	/** Ask the user for a String of free text.
    * Returns null if user cancelled input. */
	public static String askString (
          java.awt.Component parentComponent, String prompt, String initialValue)
	{
		return javax.swing.JOptionPane.showInputDialog (parentComponent, prompt, initialValue);
	} // askString

	/** Convenience method for displaying a yes/no confirmation dialogue. */
	public static boolean confirm (String title, Object question)
	{
		return confirm (owningApp, title, question);
	} // confirm

	/** Convenience method for displaying a yes/no confirmation dialogue. */
	public static boolean confirm (
          java.awt.Component parent, String title, Object question)
	{
		return (javax.swing.JOptionPane.YES_OPTION ==
                      javax.swing.JOptionPane.showConfirmDialog (
              parent, question, title, javax.swing.JOptionPane.YES_NO_OPTION,
              javax.swing.JOptionPane.QUESTION_MESSAGE, ownerIcon));
	} // confirm

  private static final java.text.SimpleDateFormat SDF_yyyyMMddTHHmmss =
                       new java.text.SimpleDateFormat ("yyyy-MM-dd'T'HH:mm:ss");

  public static String format_yyyyMMddTHHmmss (java.util.Date when)
  {
    return SDF_yyyyMMddTHHmmss.format (when);
  } // format_yyyyMMddTHHmmss

	/** Format a measurement of type double for display (not using HTML). */
	public static String format (double d)
	{
		if (d == 0.0)
		{
			return "0";
		}
		else
		{
			java.text.DecimalFormat dc;

			if ((d < 1000.0) && (d >= 1.0))
			{
				dc = new java.text.DecimalFormat ("##0.####");
			}
			else
			if ((d < 1.0) && (d >= 0.01))
			{
				dc = new java.text.DecimalFormat ("'0'.0000");
			}
			else
			{
				dc = new java.text.DecimalFormat ("0.0000E0");
			}

			return dc.format (d);
		}
	} // format

	/** Format a measurement of type double for display. Uses HTML so powers of
    * ten are displayed in mathematical style using superscripts rather than
    * computerese E-notation. */
	public static String formatHTML (double d)
	{
		String s = format (d);

		int idx = s.indexOf ("E");

		if ((-1 != idx) && (idx < s.length () - 1))
		{
			String exp = s.substring (idx + 1);
			s = s.substring (0, idx);

			if (!exp.equals ("0"))
			{
				s += " x 10<sup>" + exp + "</sup>";
			}
		}

		return s;
	} // formatHTML

	/** Convert a date-time string in format 2006:11:16 21:05:10 into
    * milliseconds since 1970.0. Returns 0 if the date cannot be parsed. */
	public static long getMilliseconds (String dateTime)
	{
		try
		{
			java.text.SimpleDateFormat format =
              new java.text.SimpleDateFormat ("yyyy:MM:dd HH:mm:ss");
			java.util.Date date = format.parse (dateTime);
			return date.getTime ();
		}
		catch (java.text.ParseException ex)
		{
//			warning ("Error", "Cannot parse date/time: " + dateTime);
      logWarning ("Cannot parse date/time: {0}", dateTime);
			return 0;
		}
	} // getMilliseconds

	/** Check whether there is enough disc space for the estimated size of
    * temporary image files, prompting the user to do something about it if
    * there is not. The path parameter can refer to any object in the
    * disc partition to be checked. Requires Java 6 or later. */
	public static boolean isRoomForTemporaryImages (java.io.File path, int nFiles,
          long imWidth, long imHeight, int imBands, int imBits)
	{
		long estimatedBytesNeeded = nFiles *
        (10000000L + imWidth * imHeight * (long) imBands * (long) (imBits / 8));
		java.io.File absPath = path.getAbsoluteFile ();

		while (null != absPath.getParent ())
		{
			absPath = absPath.getParentFile (); // Eventually gets us the partition.
		}

		do
		{
			long usableBytes = absPath.getUsableSpace ();

			if (estimatedBytesNeeded < usableBytes)
			{
				return true;
			}

			if (!Util.confirm (null, "Disc space requirements",
			  "Approx " + estimatedBytesNeeded +
        " bytes will be needed for temporary files\n" +
        "but there are only about " + usableBytes +
        " bytes available.\n" +
				"Try to free some space. Click \"Yes\" when enough has been cleared.\n" +
			  "Otherwise click \"No\" to abort processing."))
			{
				return false;
			}
		}
		while (true);
	} // isRoomForTemporaryImages

  public static void logInfo (String msg, Object... params)
  {
    java.util.logging.Logger.getLogger ("net.grelf").
            log (java.util.logging.Level.INFO, msg, params);
  } // logInfo

  public static void logInfo (String msg)
  {
    java.util.logging.Logger.getLogger ("net.grelf").
            log (java.util.logging.Level.INFO, msg);
  } // logInfo

  public static void logWarning (String msg, Object... params)
  {
    java.util.logging.Logger.getLogger ("net.grelf").
            log (java.util.logging.Level.WARNING, msg, params);
  } // logWarning

  public static void logWarning (String msg)
  {
    java.util.logging.Logger.getLogger ("net.grelf").
            log (java.util.logging.Level.WARNING, msg);
  } // logWarning

	/** Convenience method for creating a menu item. This is the usual version
    * to call, which adds Ctrl+ to the accelerator key. */
	public static javax.swing.JMenuItem menuItem (
          java.awt.event.ActionListener listener,
	        String label, String command, int mnemonic, int acceleratorKey)
	{
		return menuItem (listener, label, command, mnemonic, acceleratorKey, true);
	} // menuItem

	/** Convenience method for creating a menu item. Call this version if you
    * don't want Ctrl+ added to the accelerator key, using withCtrl = false. */
	public static javax.swing.JMenuItem menuItem (
          java.awt.event.ActionListener listener,
          String label, String command, int mnemonic, int acceleratorKey,
          boolean withCtrl)
	{
		javax.swing.JMenuItem item = new javax.swing.JMenuItem (label);
		item.addActionListener (listener);
		item.setActionCommand (command);

		if (mnemonic != 0)
		{
			item.setMnemonic ((char) mnemonic);
		}

		if (acceleratorKey != 0)
		{
			if (withCtrl)
			{
				item.setAccelerator (javax.swing.KeyStroke.getKeyStroke (
                acceleratorKey, java.awt.Event.CTRL_MASK));
			}
			else
			{
				item.setAccelerator (javax.swing.KeyStroke.getKeyStroke (
                acceleratorKey, 0));
			}
		}

		return item;
	} // menuItem

	/** Convenience method for displaying a message dialogue. */
	public static void message (String title, Object text)
	{
		message (owningApp, title, text);
	} // message

	/** Convenience method for displaying a message dialogue. */
	public static void message (
          java.awt.Component parent, String title, Object text)
	{
			javax.swing.JOptionPane.showMessageDialog (
              parent, text, title, javax.swing.JOptionPane.PLAIN_MESSAGE,
							ownerIcon);
	} // message

	/** Find the number of occurences of a character in a String. */
	public static int nOccurs (String s, char ch)
	{
		int n = 0;

		for (int i = 0; i < s.length (); i++)
		{
			if (s.charAt (i) == ch)
			{
				n++;
			}
		}

		return n;
	} // nOccurs

	/** Display a message dialogue apologising that an operation is not yet
    * available. */
	public static void notYet ()
	{
		notYet (owningApp);
	} // notYet

	/** Display a message dialogue apologising that an operation is not yet
    * available. */
	public static void notYet (java.awt.Component parent)
	{
		message (parent, "Sorry", "This option is not yet available");
	} // notYet

	/** If a String comprises numbers separated by a '/' do the implied division
    * and return the result as a new String.
		* Otherwise return the original String. */
	public static String rational (String s)
	{
		int i = s.indexOf ('/');

		if (-1 == i)
		{
			return s;
		}
		else
		{
			String numerator = s.substring (0, i);
			String denominator = s.substring (i + 1);

			if (!Character.isDigit (denominator.charAt (0)))
			{
				return s;
			}

			for (int j = 1; j < denominator.length (); j++)
			{
				if (!Character.isDigit (denominator.charAt (j)))
				{
					denominator = denominator.substring (0, j);
					break;
				}
			}

			try
			{
				return Float.toString (Float.parseFloat (numerator) /
                               Float.parseFloat (denominator));
			}
			catch (NumberFormatException ex)
			{
				return s;
			}
		}
	} // rational

	/** If a String comprises numbers separated by a '/' do the implied division
    * and return the result as a new float.
		* Otherwise return the original String parsed as a float.
    * Return -1.0F if parsing fails. */
	public static float rationalFloat (String s)
	{
		try
		{
			int i = s.indexOf ('/');

			if (-1 == i)
			{
				return Float.parseFloat (s);
			}
			else
			{
				String numerator = s.substring (0, i);
				String denominator = s.substring (i + 1);

				if (!Character.isDigit (denominator.charAt (0)))
				{
					Util.warning ("Error",
                        "Could not parse the metadata as a rational float.");
					return -1.0F;
				}

				for (int j = 1; j < denominator.length (); j++)
				{
					if (!Character.isDigit (denominator.charAt (j)))
					{
						denominator = denominator.substring (0, j);
						break;
					}
				}

				return Float.parseFloat (numerator) / Float.parseFloat (denominator);
			}
		}
		catch (NumberFormatException ex)
		{
			Util.warning ("Error",
                    "Could not parse the metadata as a rational float.");
			return -1.0F;
		}
	} // rationalFloat

	/** If subString occurs in String s remove it, otherwise return unmodified s.
    * Only checks for a single occurrence of the sub-string. */
	public static String removeSubString (String s, String subString)
	{
		int idx = s.indexOf (subString);

		if (-1 == idx) { return s; }

		StringBuilder sb = new StringBuilder (s);
		sb.delete (idx, idx + subString.length ());
		return sb.toString ();
	} // removeSubString

	public static double rootSumOfSquares (double [] x)
	{
		double sumSq = 0;

		for (int i = 0; i < x.length; i++)
		{
			sumSq += x [i] * x [i];
		}

		return Math.sqrt (sumSq);
	} // rootSumOfSquares

	public static long rootSumOfSquares (long [] x)
	{
		long sumSq = 0;

		for (int i = 0; i < x.length; i++)
		{
			sumSq += x [i] * x [i];
		}

		return (long) Math.sqrt (sumSq);
	} // rootSumOfSquares

	/** Removes any HTML (swing formatting) elements embedded in cells.
    * The array columnHeadings may be null,
		* in which case there is simply no headings row in the output.<br>
		* 10.4.29: Added pathToFile parameter, to remove dependency on
    * net.grelf.grip.FileIO	*/
	public static void saveJTableAsCSV (String [] columnHeadings,
          javax.swing.JTable table, String pathToFile)
	{
		try
		{
      try (java.io.PrintWriter out = new java.io.PrintWriter (pathToFile))
      {
        if (null != columnHeadings)
        {
          for (String columnHeading : columnHeadings)
          {
            out.print (columnHeading + ",");
          }
          
          out.println ();
        }
        
        for (int row = 0; row < table.getModel ().getRowCount (); row++)
        {
          for (int col = 0; col < table.getModel ().getColumnCount (); col++)
          {
            StringBuilder cell =
                new StringBuilder ((String) table.getModel ().getValueAt (row, col));
            int idx1, idx2;
            
            // Delete any embedded HTML (swing formatting) elements:
            do
            {
              idx1 = cell.indexOf ("<");
              
              if (idx1 != -1)
              {
                idx2 = cell.indexOf (">", idx1);
                
                if (idx2 != -1);
                {
                  cell.delete (idx1, idx2 + 1);
                }
              }
            }
            while (idx1 != -1);
            
            if (-1 != cell.indexOf (","))
            {
              out.print ("\"" + cell.toString () + "\",");
            }
            else
            {
              out.print (cell.toString () + ",");
            }
          }
          
          out.println ();
        }
      }
		}
		catch (java.io.IOException ex)
		{
      logWarning (ex.toString ());
			Util.warning ("Sorry", "Could not open\n{0}", pathToFile);
		}
	} // saveJTableAsCSV

	/** Show some JVM memory information in the console window. */
	public static void showMemory (String message)
	{
		System.out.println (message);
		long Mb = 1024 * 1024;
		Runtime rt = Runtime.getRuntime ();
		System.out.println (
            "JVM memory=" + rt.totalMemory () / Mb + "Mb" +
						"; free=" + rt.freeMemory () / Mb + "Mb" +
						"; used=" + (rt.totalMemory () - rt.freeMemory ()) / Mb + "Mb" +
						"; max=" + rt.maxMemory () / Mb + "Mb");
	} // showMemory

	/** Split a path (may be using forward slashes or backslashes). */
	public static String [] splitPath (String path)
	{
		String regexp;

		if (-1 != path.indexOf ("\\"))
		{
			regexp = "\\\\";
		}
		else
		{
			regexp = "/";
		}

		return path.split (regexp);
	} // splitPath

	/** Convenience method for displaying a message dialogue with a warning
    * icon and also logging the warning. */
	public static void warning (String title, Object text)
	{
		warning (owningApp, title, text);
	} // warning

	/** Convenience method for displaying a message dialogue with a warning
    * icon and also logging the warning. */
	public static void warning (
          java.awt.Component parent, String title, Object text)
	{
    if (showErrors)
    {
      javax.swing.JOptionPane.showMessageDialog (parent, text, title,
							javax.swing.JOptionPane.WARNING_MESSAGE, ownerIcon);
    }

    if (text instanceof String)
    {
      logWarning ((String) text);
    }
	} // warning

	/** Convenience method for displaying a message dialogue with a warning
    * icon and also logging the warning. */
	public static void warning (String title, String text, Object... params)
	{
		warning (owningApp, title, text, params);
	} // warning

	/** Convenience method for displaying a message dialogue with a warning
    * icon and also logging the warning. */
	public static void warning (
       java.awt.Component parent, String title, String text, Object... params)
	{
    if (showErrors)
    {
  		javax.swing.JOptionPane.showMessageDialog (parent, text, title,
							javax.swing.JOptionPane.WARNING_MESSAGE, ownerIcon);
    }

    logWarning (text, params);
	} // warning

  private static boolean showErrors = true;

  /** Set false if you want Util.warning () only to write to the log, not
    * to show a message to the user. */
  public static void setShowErrors (boolean show)
  {
    showErrors = show;
  } // setShowErrors

} // Util