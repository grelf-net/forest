/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2024
 */

package net.grelf.forest;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import net.grelf.Util;

/** WORK IN PROGRESS - DECIDING HOW TO PLACE BUTTONS WITHOUT THEM BEING A NUISANCE */
public class MapButtons extends Buttons implements ActionListener
{
  private static final Forest FOREST = Forest.getInstance ();
  private static final int WIDTH = 100, HEIGHT = 300;

  public MapButtons ()
  {
    JFrame frame = new JFrame ("");
    frame.setIconImage (FOREST.getIconImage ());
    frame.setDefaultCloseOperation (JFrame.DO_NOTHING_ON_CLOSE);
    frame.setContentPane (setMapPanel ());
    frame.setPreferredSize (new Dimension (WIDTH, HEIGHT));
    frame.pack (); 
    frame.setLocation (FOREST.canvas.width - WIDTH, FOREST.canvas.height - HEIGHT);
    frame.setVisible (true);
  } // MapButtons
  
  private JButton makeButton (String label, String actionCommand)
  {
    JButton b = new JButton (label);
    b.setHorizontalTextPosition (SwingConstants.CENTER);
    b.setActionCommand (actionCommand);
    b.addActionListener (this);
    return b;
  } // makeButton
  
  private JPanel setMapPanel ()
  {
    JPanel panel = new JPanel (new GridLayout (6, 2));
    panel.add (makeButton ("Go to SCENE", "go"));
    panel.add (makeButton ("North", "N"));
    panel.add (makeButton ("East", "E"));
    panel.add (makeButton ("West", "W"));
    panel.add (makeButton ("South", "S"));
    panel.add (makeButton ("Centre on me", "C"));
    return panel;
  } // setMapPanel

  private JPanel setScenePanel ()
  {
    JPanel panel = new JPanel (new GridLayout (6, 2));

// TO DO

    return panel;
  } // setScenePanel
  
  @Override
  public void actionPerformed (ActionEvent e) 
  { 
    Util.message ("ACTION", e.getActionCommand());

    switch (e.getActionCommand ())
    {
// TO DO      
    }
  } // actionPerformed
  
} // MapButtons
