/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */
package net.grelf.forest;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import net.grelf.Util;

public class RgbMeter 
{
  private static final Forest FOREST = Forest.getInstance ();
  private int r = 0, g = 0, b = 0;
  private boolean found = false, measured = false;
  private final int WD = 200, HT = 65, CR = 10;// CR is corner radius
  private RgbTarget target;
  
  public RgbMeter () {}
  
  public boolean isFound () { return found; }
  public void setFound () { found = true; }
  public int getWidth () { return WD; }
  public int getHeight () { return HT; }

  public void set (int r, int g, int b)
  {
    if (!found) return;
    
    this.r = r; this.g = g; this.b = b;
    this.measured = true;
  } // set

  public void draw (Graphics2D g2, int xL, int yT)
  {
    if (!found) return;
    
    g2.setPaint (COLOURS.GREY);
    g2.fillRoundRect (xL, yT, WD, HT, CR, CR);
    g2.setPaint (Color.BLACK);
    g2.drawRoundRect (xL, yT, WD, HT, CR, CR);
    g2.setFont (new Font ("SansSerif", Font.BOLD, 12));
    g2.setPaint (Color.WHITE);
    g2.drawString ("R", xL + 60, yT + 15);
    g2.drawString ("G", xL + 110, yT + 15);
    g2.drawString ("B", xL + 160, yT + 15);
    g2.drawString ("Dec", xL + 10, yT + 33);
    g2.fillRect (xL + 50, yT + 20, 40, 16);
    g2.fillRect (xL + 100, yT + 20, 40, 16);
    g2.fillRect (xL + 150, yT + 20, 40, 16);
    
    if (this.measured)
    {
      g2.drawString ("Hex", xL + 10, yT + 53);
      g2.fillRect (xL + 50, yT + 40, 40, 16);
      g2.fillRect (xL + 100, yT + 40, 40, 16);
      g2.fillRect (xL + 150, yT + 40, 40, 16);
      g2.setPaint (Color.BLACK);
      g2.drawString ("" + r, xL + 54, yT + 32);
      g2.drawString ("" + g, xL + 104, yT + 32);
      g2.drawString ("" + b, xL + 154, yT + 32);
      g2.drawString (Integer.toHexString (r), xL + 54, yT + 52);
      g2.drawString (Integer.toHexString (g), xL + 104, yT + 52);
      g2.drawString (Integer.toHexString (b), xL + 154, yT + 52);
    }
    else g2.drawString ("Click on something", xL + 10, yT + 53);
  } // draw
  
  public RgbTarget createTarget (int xL, int yT, int xR, int yB)
  {
    return new RgbTarget (xL, yT, xR, yB);
  }

  public class RgbTarget extends Target
  {
    public RgbTarget (int xL, int yT, int xR, int yB) 
    {
      super (xL, yT, xR, yB);
    }

    @Override
    void response (java.awt.Point pt)
    {
      FOREST.rgbMeter.setFound ();
      FOREST.canvas.clearTargets ();
      Util.message ("", 
      "You have found a very\n" + 
      "useful measuring device.\n" +
      "Now you can really\n" +
      "get into things.");
    } // response
    
  } // RgbTarget

} // RgbMeter
