/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2023
 */

package net.grelf.forest;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.grelf.Util;

public class Settings
{
  private static Forest FOREST;
  private final JComboBox<String> rangeList, strideList, mapStepList;
  private final JCheckBox checkFog, checkStreams;
  
  public Settings ()
  {
    FOREST = Forest.getInstance ();
    JFrame frame = new JFrame ();
    frame.setTitle (" The Forest - SETTINGS ");
    frame.setIconImage (FOREST.getIconImage ());
    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // TO BE CHANGED
    frame.addWindowListener
		(
			new java.awt.event.WindowAdapter ()
			{
				@Override
				public void windowClosing (java.awt.event.WindowEvent ev)
				{
					FOREST.exit ();
				}
			}
		);

    JComponent panel = new JPanel (new GridLayout (5, 2));//rows, cols

    JLabel roleLabel = new JLabel ("  ROLE ");
    JLabel roleList = new JLabel ("EXPLORER (for now)");
    panel.add (roleLabel);
    panel.add (roleList);

    JLabel rangeLabel = new JLabel ("  Visible range ");
    String [] ranges = {"60m", "120m", "200m", "300m", "400m"};
    rangeList = new JComboBox<> (ranges);
    int i = 0;
    
    switch (FOREST.scene.getRange ())
    {
      case 60: i = 0; break;
      case 120: i = 1; break;
      case 200: i = 2; break;
      case 300: i = 3; break;
      case 400: i = 4; break;
      default: Util.warning ("ERROR", "Invalid range in scene");
    }
    
    rangeList.setSelectedIndex (i);
    panel.add (rangeLabel);
    panel.add (rangeList);
    rangeList.addActionListener (new RangeAction ());

    JLabel strideLabel = new JLabel ("  Stride on level grass ");
    String [] strides = {"1m", "2m", "3m", "4m", "5m"};
    strideList = new JComboBox<> (strides);
    i = 0;
    
    switch (FOREST.observer.stride)
    {
      case 1: i = 0; break;
      case 2: i = 1; break;
      case 3: i = 2; break;
      case 4: i = 3; break;
      case 5: i = 4; break;
      default: Util.warning ("ERROR", "Invalid stride in scene");
    }
    
    strideList.setSelectedIndex (i);
    panel.add (strideLabel);
    panel.add (strideList);
    rangeList.addActionListener (new StrideAction ());

    JLabel mapStepLabel = new JLabel ("  Map step size ");
    String [] mapSteps = {"25m", "50m", "100m", "200m", "400m"};
    mapStepList = new JComboBox<> (mapSteps);
    i = 0;
    
    switch (FOREST.map.getStep ())
    {
      case 25: i = 0; break;
      case 50: i = 1; break;
      case 100: i = 2; break;
      case 200: i = 3; break;
      case 400: i = 3; break;
      default: Util.warning ("ERROR", "Invalid step size in map");
    }
    
    mapStepList.setSelectedIndex (i);
    panel.add (mapStepLabel);
    panel.add (mapStepList);
    mapStepList.addActionListener (new MapStepAction ());
    
    checkFog = new JCheckBox ("  Fog ", FOREST.scene.doFog);
    panel.add (checkFog);
    checkFog.addItemListener (new FogListener ());

    checkStreams = new JCheckBox ("  Streams ", FOREST.terrain.withStreams);
    panel.add (checkStreams);
    checkStreams.addItemListener (new StreamListener ());

    panel.setOpaque (true); //content panes must be opaque
    frame.setContentPane (panel);
    frame.setPreferredSize (new Dimension (400, 120));
    frame.pack ();
    frame.setLocation (FOREST.canvas.width + 1, 0);
    frame.setVisible (true);
  }

  private class FogListener implements ItemListener
  {
    @Override
    public void itemStateChanged (ItemEvent e) 
    {
      JCheckBox cb = (JCheckBox) e.getSource ();
      FOREST.scene.doFog = cb.isSelected ();
      FOREST.redraw ();
    }
  } // FogListener
  
  private class StreamListener implements ItemListener
  {
    @Override
    public void itemStateChanged (ItemEvent e) 
    {
      JCheckBox cb = (JCheckBox) e.getSource ();
      FOREST.terrain.withStreams = cb.isSelected ();
      FOREST.toMap (); // Map drawing sets stream positions
    }
  } // StreamListener
  
  private class RangeAction implements ActionListener
  {
    @Override
    public void actionPerformed (ActionEvent e) 
    {
      JComboBox cb = (JComboBox) e.getSource();

      switch ((String) cb.getSelectedItem())
      {
        case "60m": FOREST.scene.setRange (60); break;
        case "120m": FOREST.scene.setRange (120); break;
        case "200m": FOREST.scene.setRange (200); break;
        case "300m": FOREST.scene.setRange (300); break;
        case "400m": FOREST.scene.setRange (400); break;
      }

      FOREST.redraw ();
    }
  } // RangeAction

  private class StrideAction implements ActionListener
  {
    @Override
    public void actionPerformed (ActionEvent e) 
    {
      JComboBox cb = (JComboBox) e.getSource();

      switch ((String) cb.getSelectedItem())
      {
        case "1m": FOREST.observer.stride = 1; break;
        case "2m": FOREST.observer.stride = 2; break;
        case "3m": FOREST.observer.stride = 3; break;
        case "4m": FOREST.observer.stride = 4; break;
        case "5m": FOREST.observer.stride = 5; break;
      }

      FOREST.redraw ();
    }
  } // StrideAction

  private class MapStepAction implements ActionListener
  {
    @Override
    public void actionPerformed (ActionEvent e)
    {
      JComboBox cb = (JComboBox) e.getSource();
    
      switch ((String) cb.getSelectedItem())
      {
        case "25m": FOREST.map.setStep (25); break;
        case "50m": FOREST.map.setStep (50); break;
        case "100m": FOREST.map.setStep (100); break;
        case "200m": FOREST.map.setStep (200); break;
        case "400m": FOREST.map.setStep (400); break;
      }
    
      FOREST.redraw ();
    }
  } // StepAction
  
} // Settings
