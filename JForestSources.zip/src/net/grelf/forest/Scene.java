/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import net.grelf.Util;
import static net.grelf.forest.FEATURES.BOULDER;
import static net.grelf.forest.FEATURES.CONE;
import static net.grelf.forest.FEATURES.KNOLL;
import static net.grelf.forest.FEATURES.MINE;
import static net.grelf.forest.FEATURES.ROOT;
import static net.grelf.forest.FEATURES.WATERHOLE;
import static net.grelf.forest.FEATURES.X;
import static net.grelf.forest.TERRAINS.GRASS;
import static net.grelf.forest.TERRAINS.MOOR;
import static net.grelf.forest.TERRAINS.PATH;
import static net.grelf.forest.TERRAINS.ROAD;
import static net.grelf.forest.TERRAINS.THICKET;

/** The scene above ground */
public class Scene 
{
  private final Forest FOREST = Forest.getInstance ();
  private final Observer ME = FOREST.observer;
  //protected static final int SCENE_WIDTH = 800, SCENE_WD2 = 400, SCENE_HEIGHT = 600;
  protected final double FF = Math.round (400 * Math.sqrt (2)); // For perspective
	protected final double YSCALE = 0.15; // Ground height scale
	protected final double FSCALE = 7.0; // Feature height scale
  private final int wd, ht;
  protected final int wd2;
	protected double htBase;
	protected double ht0;// At ME
	protected int range_m = 60;
	protected boolean doFog = true;
	private static final int COMPASS_RADIUS_PX = 40;
  private double sxydD; // For returning d from getOffsetScreenXY() !
	
  private final BufferedImage im;
  public BufferedImage getImage () { return im; }
  private final Graphics2D g2;
  
  private final int MAX_AHEAD = 600 * 400;
	private final ScenePoint [] ahead = new ScenePoint [MAX_AHEAD];
  private final BufferedImage [] woodpatch = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] grasspatch = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] moorpatch = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] marshpatch = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood03 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood04 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] boulder01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] boulder02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] boulder03 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] boulder04 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] woodpattern = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] grasspattern = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] moorpattern = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] x02 = new BufferedImage [G2.N_FOG_LEVELS];
  protected final BufferedImage [] cone01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] thick01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] thick02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood05 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood06 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood07 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] wood08 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] knoll01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] knoll02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] mine02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] pond02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] root01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] root02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] door01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] startpole = new BufferedImage [G2.N_FOG_LEVELS];  
  private final BufferedImage [] finishpole = new BufferedImage [G2.N_FOG_LEVELS];  
  private final BufferedImage [] x01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] x03 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] x04 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] titl = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] titr = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] tibl = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] tibr = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] hint01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] hint02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] hint03 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] hint04 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] heli01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] door02 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] mimas01 = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] rocket = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] rocket2 = new BufferedImage [G2.N_FOG_LEVELS];
  protected final BufferedImage [] imWall = new BufferedImage [G2.N_FOG_LEVELS];
  protected final BufferedImage [] gravel = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] monolith = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] cosmic = new BufferedImage [G2.N_FOG_LEVELS];
  private final BufferedImage [] cosmicOver = new BufferedImage [G2.N_FOG_LEVELS];
  
	public Scene ()
	{
    wd = FOREST.canvas.width;
    wd2 = wd / 2;
    ht = FOREST.canvas.height;
    htBase = ht * 0.6;
  	ht0 = 0;
		sxydD = 0.0;
    im = new BufferedImage (wd, ht, BufferedImage.TYPE_INT_RGB);
    g2 = (Graphics2D) im.createGraphics ();
    g2.setRenderingHint (RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//		g2.setRenderingHint (RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
//		g2.setRenderingHint (RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
    createHeliButtons ();
    loadImages ();
  } // Scene
  
  /** Load from the subdirectory called im. */
  public BufferedImage loadImage (String filename)
  {
    return ImageLoader.load ("im" + File.separator + filename);
  }

  private void loadImages ()
  {
    woodpatch [0] = loadImage ("woodpatch.png");
    grasspatch [0] = loadImage ("grasspatch1.png");
    moorpatch [0] = loadImage ("moorpatch1.png");
    marshpatch [0] = loadImage ("marshpatch.png");
    wood01 [0] = loadImage ("wood09.png");
    wood02 [0] = loadImage ("wood02a.png");
    wood03 [0] = loadImage ("wood03.png");
    wood04 [0] = loadImage ("wood04.png");
    boulder01 [0] = loadImage ("boulder01a.png");
    boulder02 [0] = loadImage ("boulder02a.png");
    boulder03 [0] = loadImage ("boulder03a.png");
    boulder04 [0] = loadImage ("boulder04a.png");
    woodpattern [0] = loadImage ("woodpatch2.png");
    grasspattern [0] = loadImage ("grasspatch3.png");
    moorpattern [0] = loadImage ("moorpatch3.png");
    x02 [0] = loadImage ("x02.png");
    cone01 [0] = loadImage ("cone01a.png");
    thick01 [0] = loadImage ("thick01.png");
    thick02 [0] = loadImage ("thick02.png");
    wood05 [0] = loadImage ("wood05a.png");
    wood06 [0] = loadImage ("wood06.png");
    wood07 [0] = loadImage ("wood07.png");
    wood08 [0] = loadImage ("wood08.png");
    knoll01 [0] = loadImage ("knoll01.png");
    knoll02 [0] = loadImage ("knoll03.png");
    mine02 [0] = loadImage ("mine02.png");
    pond02 [0] = loadImage ("pond02.png");
    root01 [0] = loadImage ("root01.png");
    root02 [0] = loadImage ("root02.png");
    door01 [0] = loadImage ("door01.png");
    startpole [0] = loadImage ("startpole_16x400.png");  
    finishpole [0] = loadImage ("finishpole_16x400.png");  
    x01 [0] = loadImage ("x01.png");
    x02 [0] = loadImage ("x05.png");
    x03 [0] = loadImage ("x03a.png");
    x04 [0] = loadImage ("x04.png");
    titl [0] = loadImage ("titl.png");
    titr [0] = loadImage ("titr.png");
    tibl [0] = loadImage ("tibl.png");
    tibr [0] = loadImage ("tibr.png");
    hint01 [0] = loadImage ("hint01.png");
    hint02 [0] = loadImage ("hint02.png");
    hint03 [0] = loadImage ("hint03.png");
    hint04 [0] = loadImage ("hint04.png");
    heli01 [0] = loadImage ("heli02.png");
    door02 [0] = loadImage ("door02.png");
    mimas01 [0] = loadImage ("mimas01.png");
    rocket [0] = loadImage ("rocket02.png");
    rocket2 [0] = loadImage ("rocket02G.png");
    imWall [0] = loadImage ("wall00.jpg");
    gravel [0] = loadImage ("gravel.png");
    monolith [0] = loadImage ("monolith00.jpg");
    cosmic [0] = loadImage ("cosmic_600x425.png");
    cosmicOver [0] = loadImage ("cosmicOver_600x425.png");
  } // loadImages
  
  protected ArrayList<BufferedImage> getImsForInside ()
  {
    ArrayList<BufferedImage> ims = new ArrayList<> ();
    ims.add (cosmic [0]);
    ims.add (wood07 [0]);
    ims.add (loadImage ("lake_144.png"));
    ims.add (loadImage ("q1.png"));
    ims.add (loadImage ("qd01.png"));
    ims.add (loadImage ("rosette.jpg"));
    ims.add (loadImage ("seaton_600x453.png"));
    return ims;
  } // getImsForInside

	public void setRange (int r)
	{
		range_m = r;
	}

  public int getRange ()
	{
		return range_m;
	}

	public void lookUp () { if (htBase < ht) { htBase += 50; draw ();} }
	public void lookLevel () { htBase = ht * 0.6; draw (); }
	public void lookDown () { if (htBase > 0) { htBase -= 50; draw (); } }

  /** Given ground coordinates */
	PointInt getScreenXY (int x, int y)
	{
		ScenePoint sp = FOREST.around.aroundGet (x, y);
		double spht = sp.getTerra ().height;
		double brad = sp.b * UTIL.DEG2RAD;
		double sinb = Math.sin (brad);
		double cosb = Math.cos (brad);
		double zz = sp.d * cosb;
		if (zz < 1) zz = 1;
		double fRatio = FF / zz;
		int sx = (int) Math.round (fRatio * sp.d * sinb + wd2); // Relative to screen centre, wd2
		int sy = (int) Math.round (htBase - fRatio * ((spht - ht0) * YSCALE - ME.ht));
		return new PointInt (sx, sy);
	} // getScreenXY

	/** Version to avoid straight rows of trees */
	PointInt getOffsetScreenXY (int x, int y)
	{ // Repeatably random offset for trees:
		double pixy = UTIL.PI10000 * x * y;
		double off = (pixy - Math.floor (pixy)) * 2 - 1;
		double xOff = x + off, yOff = y + off;
		double dx = xOff - ME.x, dy = yOff - ME.y;
		double b = Math.atan2 (dx, dy) * UTIL.RAD2DEG;
		double db = b - ME.b;
		if (db < -180) db += 360; else if (db > 180) db -= 360;
		if (db < -70 || db > 70) return new PointInt (-1, -1);
		double d = Math.sqrt (dx * dx + dy * dy);
		if (d < 1) return new PointInt (-1, -1);
		double spht = FOREST.terrain.terra (xOff, yOff).height;
		double brad = db * UTIL.DEG2RAD;
		double sinb = Math.sin (brad);
		double cosb = Math.cos (brad);
		double zz = d * cosb;
		if (zz < 1) zz = 1;
		double fRatio = FF / zz;
		int sx = (int) Math.round (fRatio * d * sinb + wd2); // Relative to screen centre, wd2
		int sy = (int) Math.round (htBase - fRatio * ((spht - ht0) * YSCALE - ME.ht));
		if (sy <= 0) return new PointInt (-1, -1);
		sxydD = d; // Yes, a fudge!
		return new PointInt (sx, sy);
	} // getOffsetScreenXY
				
	private PointInt maxmin (int a1, int a2, int a3, int a4)
	{
		int max = a1, min = a1;
		if (a2 > max) max = a2; else min = a2;
		if (a3 > max) max = a3; else if (a3 < min) min = a3;
		if (a4 > max) max = a4; else if (a4 < min) min = a4;
		return new PointInt (max, min); // Cheat, to return 2 ints, .x = max, .y = min
	} // maxmin

	/* Draw all ground patches in a clearing before the feature */
	private void completeClearing (double x, double y, Terra tr, double fscale)
	{ 
    BufferedImage [] gim = null;
    int xr = (int) Math.round (x);
		int yr = (int) Math.round (y);
		double d0 = FOREST.around.aroundGet (xr, yr).d; // Centre = feature

		for (int ix = xr - 3; ix <= xr + 3; ix++)
		{
			for (int iy = yr - 3; iy <= yr + 3; iy++)
			{
				ScenePoint sp = FOREST.around.aroundGet (ix, iy);

				if (sp.o && sp.d <= d0)
				{ // Draw tile & mark done
					int xm1 = ix - 1, xp1 = ix + 1, ym1 = iy - 1, yp1 = iy + 1;
					PointInt sxy00 = getScreenXY (xm1, ym1);
					PointInt sxy01 = getScreenXY (xm1, yp1);
					PointInt sxy11 = getScreenXY (xp1, yp1);
					PointInt sxy10 = getScreenXY (xp1, ym1);
					
					// Find rect containing tile
					PointInt sxMaxMin = maxmin (sxy00.x, sxy01.x, sxy11.x, sxy10.x);
					PointInt syMaxMin = maxmin (sxy00.y, sxy01.y, sxy11.y, sxy10.y);
					int sxMin = sxMaxMin.y;
					int sxMax = sxMaxMin.x;
					int syMin = syMaxMin.y;
					int syMax = syMaxMin.x;

					if (sxMin != -1.0 || syMin != -1.0)
					{
						switch (tr.terrain)
						{
						case GRASS:	gim = grasspatch;	 g2.setPaint (COLOURS.GRASS); break;
						case MOOR: gim = moorpatch;	g2.setPaint (COLOURS.MOOR); break;
						case WOOD:
						case THICKET: gim = woodpatch; g2.setPaint (COLOURS.WOOD); break;
						}

						if (null != gim) 
						{
              TILE.set (sxy00, sxy01, sxy11, sxy10);
              g2.fillPolygon (TILE.xs, TILE.ys, 4);
							// also need?? g2.drawPolygon (TILE.xs, TILE.ys, 4);
              int xx = (int) Math.round (sxMin - 8 * fscale);
							int wwd = (int) Math.round (sxMax - sxMin + 16 * fscale);
							int hht = (int) Math.round (syMax - syMin + 8 * fscale);
              g2.drawImage (gim [0], xx, syMin, wwd, hht, null);//Too near to need fog
						}
						
						ScenePoint sps = FOREST.around.aroundGet (ix, iy);
						sps.drawn = true;
					}
				}
			}
		}
	} // completeClearing

  /** Draw the scene above ground */
	public void draw ()
	{
    FOREST.drawing = true;
    long t0 = new Date ().getTime (); // ms
    FOREST.canvas.clearTargets ();
    G2.doFog = this.doFog;
    G2.sky = COLOURS.SKY;
		g2.setPaint (COLOURS.SKY);
		g2.fillRect (0, 0, wd, ht);
    int mex = (int) Math.round (ME.x);
    int mey = (int) Math.round (ME.y);
		FOREST.around.init (mex, mey);
    ME.nearHeli = false; // Until scene drawing proves otherwise
		Terra tr0 = FOREST.terrain.terra (ME.x, ME.y);
		ht0 = tr0.height; // At observer
    int rmBwd = range_m - Building.WIDTH;
    ArrayList<Building> buildingsBehind = new ArrayList<> ();
		int furthestI;

		switch (range_m)
		{
		case 60: furthestI = Around.xyd60; break;
		case 120: furthestI = Around.xyd120; break;
		case 200: furthestI = Around.xyd200; break;
		case 300: furthestI = Around.xyd300; break;
		default: furthestI = Around.xyd400;
		}

		int nAhead = 0;

		for (int ii = furthestI; ii >= 0; ii--)// Furthest first
		{
			ScenePointBase xyd = FOREST.around.lookupXYD (ii);
			int xScan = (int) Math.round (xyd.x + mex);
			boolean xOdd = ((xScan & 1) == 1);
			int yScan = (int) Math.round (xyd.y + mey);
			boolean yOdd = ((yScan & 1) == 1);
			double dScan = xyd.d, bScan = xyd.b;

			if (dScan < 30)// More accurate (observer generally not on integer position):
			{
				double dx = xScan - ME.x, dy = yScan - ME.y;
				dScan = Math.sqrt (dx * dx + dy * dy);
				bScan = Math.atan2 (dx, dy) * UTIL.RAD2DEG;
			}

			double db = bScan - ME.b;
			if (db < -180) db += 360;
			else if (db > 180) db -= 360;

			ScenePoint sp = FOREST.around.aroundSet (dScan, db, xScan, yScan, xOdd && yOdd);
                        // tr deliberately undefined
			
			if (range_m - 3 > dScan)
			{
				if ((dScan > 30 && -50 <= db && db <= 50)
					|| (-70 <= db && db <= 70))
				{
					if (nAhead >= MAX_AHEAD)
					{
						Util.warning ("ERROR", "TOO MANY AHEAD - Scene.draw()");
					}
					else
					{
						double dNr = dScan / range_m;

						if (dNr > 0.75) sp.fogNo = (dNr - 0.75) * 4.0; // 0..1

						ahead [nAhead] = sp; // NB: tr deliberately undefined at this stage
						nAhead++;
					}
				}
        else if (dScan < 20) // but not ahead!
        {
          Terra tr = sp.getTerra ();
     
          if (null != tr.building)
          {
            buildingsBehind.add (tr.building);
          }
        }
			}
		}
/* Check:
System.out.println (ahead [0]);
System.out.println (ahead [100]);
System.out.println (ahead [200]);
System.out.println (ahead [300]);
*/
    for (int i = 0; i < buildingsBehind.size (); i++)
    { 
      Building bld = buildingsBehind.get (i);
      bld.markFoundations ();
    }

    // Pass 1: buildings and clearings ahead
    for (int ii = 0; ii < nAhead; ii++)
    {
      ScenePoint sp = this.ahead [ii];
      Terra tr = sp.getTerra ();
      
      if (null != tr.building && sp.d < rmBwd)
      { 
        tr.building.markFoundations ();// Also completes construction of object
      }

      if (sp.d < 20) // Need clearing? (not boulders, roots, cones)
      { 
        FEATURES feat = sp.tr.feature;
        
        if (feat == FEATURES.KNOLL || feat == FEATURES.MINE
         || feat == FEATURES.WATERHOLE || feat == FEATURES.X)
        { 
          int x = (int) Math.round (sp.x);
          int y = (int) Math.round (sp.y);
          
          for (int jx = x - 4; jx <= x + 4; jx++)
          {
            for (int jy = y - 4; jy <= y + 4; jy++)
            { 
              ScenePoint spj = FOREST.around.aroundGet (jx, jy);
              spj.clear = true;
            }
          }
        } 
      } 
    }

		// Pass 2: tiles, ground, tree & feature images
		for (int ii = 0; ii < nAhead; ii++)
		{
			ScenePoint sp = ahead [ii];
      double x = sp.x, y = sp.y;
      int xr = (int) Math.round (x), yr = (int) Math.round (y);
      double fscale = this.FSCALE / sp.d;
      int fx, fy, fwd, fht;
      BufferedImage [] fim = null, gim = null, tim = null; // Feature, ground, tree images
      PointInt sxy = this.getScreenXY (xr, yr);
      int rand = (int) Math.round (UTIL.PI10000 * x * y); // used later too
      int v8 = 0x7 & rand; // 3 bits
      int v4 = 0x3 & v8; // 2 bits
      Terra tr = sp.getTerra ();
      
      if (sp.o) // x, y both odd
      {
        if (null != tr.building)
        {
          if (FOREST.view == VIEWS.INTERIOR)
          { // Observer is inside a building so we don't want to draw its
            // exterior walls which would block the view through the open door.
            Inside fi = FOREST.inside;

            if (null != fi)// Just checking
            {
              // Only draw other buildings, not this one
              if (Math.abs (xr - fi.bldg.xCentre) > 6
               || Math.abs (yr - fi.bldg.yCentre) > 6)
              { tr.building.drawPart (g2, xr, yr, mex, mey, range_m);
                sp.drawn = true;
              }
            }
            else// Maybe not inside after all
            {
              tr.building.drawPart (g2, xr, yr, mex, mey, range_m);
              sp.drawn = true;
            }
          } // Yes, repetitive but to make the meaning clear
          else
          {
            tr.building.drawPart (g2, xr, yr, mex, mey, range_m);
            sp.drawn = true;
          }
        }
        else if (!sp.drawn
                  && xr > mex - this.range_m && xr < mex + this.range_m - 1
                  && yr > mey - this.range_m && yr < mey + this.range_m - 1)
        {
          int xm1 = xr - 1, xp1 = xr + 1, ym1 = yr - 1, yp1 = yr + 1;
          PointInt sxy00 = getScreenXY (xm1, ym1);
          PointInt sxy01 = getScreenXY (xm1, yp1);
          PointInt sxy11 = getScreenXY (xp1, yp1);
          PointInt sxy10 = getScreenXY (xp1, ym1);
          
          // Find rect containing tile:
          PointInt sxMaxMin = maxmin (sxy00.x, sxy01.x, sxy11.x, sxy10.x);
          PointInt syMaxMin = maxmin (sxy00.y, sxy01.y, sxy11.y, sxy10.y);
          int sxMin = sxMaxMin.y;
          int sxMax = sxMaxMin.x;
          int syMin = syMaxMin.y;
          int syMax = syMaxMin.x;
          Color fill = null, stroke = null;
          boolean marshy = Stream.isMarsh (xr, yr);

          switch (tr.terrain)
          {
          case LAKE:
          case STREAM:
            fill = UTIL.fog (COLOURS.LAKE, sp.fogNo);
            stroke = fill;
            break;

          case TOWN:
          case MUD:
          case Z:
            fill = UTIL.fog (COLOURS.GREY, sp.fogNo);
            stroke = UTIL.fog (COLOURS.PAVE_LINE, sp.fogNo);
            break;

          case ROAD:
          case PATH:
            fill = UTIL.fog (COLOURS.GREY, sp.fogNo);
            stroke = UTIL.fog (COLOURS.GREY, sp.fogNo);
            break;

          case GRASS:
            fill = UTIL.fog (COLOURS.GRASS, sp.fogNo);
            gim = marshy ? marshpatch : grasspatch;
            break;

          case MARSH:
          case MOOR:
            fill = UTIL.fog (COLOURS.MOOR, sp.fogNo);
            stroke = fill;
            gim = marshy ? marshpatch : moorpatch;
            break;

          case WOOD:
            if (sp.d < 30)
            {
              fill = UTIL.fog (COLOURS.WOOD, sp.fogNo);
              stroke = fill;
            }
            
            if (marshy)
            {
              gim = marshpatch;
            }
            else
            {
              gim = woodpatch;

              if (tr.feature == FEATURES.NONE && !sp.clear)
              {
                switch (v8)
                {
                case 7: tim = wood08; break;
                case 6: tim = wood07; break;
                case 5: tim = wood06; break;
                case 4: tim = wood05; break;
                case 3: tim = wood04; break;
                case 2: tim = wood03; break;
                case 1: tim = wood02; break;
                case 0: tim = wood01; break;
                }
              }
            }
            break;
            
          case THICKET:
            if (sp.d < 30)
            {
              fill = UTIL.fog (COLOURS.WOOD, sp.fogNo);
              stroke = fill;
            }
            
            if (marshy)
            {
              gim = marshpatch;
            }
            else
            {
              gim = woodpatch;
            }
            
            if (tr.feature == FEATURES.NONE && !sp.clear)
            {
              switch (v4)
              {
              case 0:
              case 1: tim = thick02; break;
              case 2:
              case 3: tim = thick01; break;
              }
            }
            break;
          }
          
          TILE.setAndDraw (sxy00, sxy01, sxy11, sxy10, g2, fill, stroke);
          
          if (null != gim)
          {
            fx = (int) Math.round (sxMin - 8 * fscale);
            fwd = (int) Math.round (sxMax - sxMin + 16 * fscale);
            fht = (int) Math.round (syMax - syMin + 8 * fscale);
            G2.drawImage (g2, gim, fx, syMin, fwd, fht, sp.fogNo);
          }

          //Smooth lake, stream and road edges:
          // sxy01 - sxy11
          //   |       |
          // sxy00 - sxy10
          if (sp.d < 60)
          {
            TERRAINS tt = tr.terrain;

            if (tt == TERRAINS.LAKE || tt == TERRAINS.ROAD
             || tt == TERRAINS.PATH || tt == TERRAINS.STREAM)
            {
              int xp2 = xr + 2, xm2 = xr - 2, yp2 = yr + 2, ym2 = yr - 2;
              ScenePoint aN = FOREST.around.aroundGet (xr, yp2);
              ScenePoint aNE = FOREST.around.aroundGet (xp2, yp2);
              ScenePoint aE = FOREST.around.aroundGet (xp2, yr);
              ScenePoint aSE = FOREST.around.aroundGet (xp2, ym2);
              ScenePoint aS = FOREST.around.aroundGet (xr, ym2);
              ScenePoint aSW = FOREST.around.aroundGet (xm2, ym2);
              ScenePoint aW = FOREST.around.aroundGet (xm2, yr);
              ScenePoint aNW = FOREST.around.aroundGet (xm2, yp2);

              if (this.neighb3 (aN, aNE, aE, tt))
                TILE.fillTriangle (g2, sxy01, sxy11, sxy10);

              if (this.neighb3 (aE, aSE, aS, tt))
                TILE.fillTriangle (g2, sxy11, sxy10, sxy00);

              if (this.neighb3 (aS, aSW, aW, tt))
                TILE.fillTriangle (g2, sxy10, sxy00, sxy01);

              if (this.neighb3 (aW, aNW, aN, tt))
                TILE.fillTriangle (g2, sxy00, sxy01, sxy11);
            }
          }

          if (null != tim)
          {
            PointInt sxyOff = getOffsetScreenXY (xr, yr); // Don't change sxy!

            if (sxyOff.x != -1 || sxyOff.y != -1)
            {
              double fscaleOff = (sxydD > 0) ? FSCALE / sxydD : 0;
              fwd = (int) Math.round (tim [0].getWidth () * fscaleOff);
              fx = (int) Math.round (sxyOff.x - fwd * 0.5);
              fht = (int) Math.round (tim [0].getHeight () * fscaleOff);
              fy = sxyOff.y - fht;
              G2.drawImage (g2, tim, fx, fy, fwd, fht, sp.fogNo);
            }
          }
        }
      }
      
      switch (tr.feature)
      {
      case KNOLL:
        switch (v4)
        {
        case 0:
        case 1: fim = knoll01; break;
        case 2:
        case 3: fim = knoll02; break;
        }
        break;
      case MINE:
        if (sp.d < 3 && ME.role == ROLES.EXPLORER && !ME.inHeli)
        {
          FOREST.mine.enterMine ();
          break;
        }
        
        if (sp.d < 20) completeClearing (x, y, tr, fscale);
        
        fim = mine02;
        sxy.y += (int) Math.round (fim [0].getHeight () * fscale * 0.5);
        break;

      case WATERHOLE:
        if (sp.d < 20) completeClearing (x, y, tr, fscale);
        
        fim = pond02;
        sxy.y += (int) Math.round (fim [0].getHeight () * fscale * 0.5);
        break;
      case ROOT:
        switch (v4)
        {
        case 0:
        case 1: fim = root01; break;
        case 2:
        case 3: fim = root02; break;
        }
        break;
      case BOULDER:
        switch (v4)
        {
        case 0: fim = boulder01; break;
        case 1: fim = boulder02; break;
        case 2: fim = boulder03; break;
        case 3: fim = boulder04; break;
        }
        //if (x === 2198 && y === 28956) this.static1 = { im: fim };
        break;
      case X:
        switch (v4)
        {
        case 0: fim = x01; break;
        case 1: fim = x02; break;
        case 2: /*if (me.role == = ROLES.EXPLORER)
            {
              if (this.doorOpen)
              {
                if (this.door02.loaded)
                {
                  fim = this.door02;
                  if (sp.d <= 2) forest.terrain.bleak = true;
                }
              }
              else
              {
                if (this.door01.loaded)
                {
                  fim = this.door01;
                  if (sp.d <= 7) me.nearDoor = true;
                }
              }
            }
            else*/ fim = x03;
            break;
        case 3: fim = x04; break;
        }
        break;//case X
      case CONE:
        fim = cone01;

        if (ME.role == ROLES.EXPLORER)
        {
          if (TERRAINS.GRASS == tr.terrain || TERRAINS.MOOR == tr.terrain)
          {
            if (!ME.inHeli)
            {
              fim = heli01;

              if (sp.d <= 7) ME.nearHeli = true;
            }
          }
          else
          {
            fscale *= 0.25;
            switch (v4)
            {
            case 0: fim = this.hint01; break;
            case 1: fim = this.hint02; break;
            case 2: fim = this.hint03; break;
            case 3: fim = this.hint04; break;
            }
          }
        } 
        break;
      case ROCKET:
        fim = rocket;
        break;
      }

      if (fim != null)
      {
        fwd = (int) Math.round (fim [0].getWidth () * fscale);
        fx = (int) Math.round (sxy.x - fwd * 0.5);
        fht = (int) Math.round (fim [0].getHeight () * fscale);
        fy = sxy.y - fht;
        G2.drawImage (g2, fim, fx, fy, fwd, fht, sp.fogNo);
      }
		}
	  
    if (FOREST.view == VIEWS.SCENE)
    {
      if (ME.inHeli) this.drawHeliControls ();
      
      drawCompass (g2);
      FOREST.rgbMeter.draw (g2, 0, 0);
      FOREST.canvas.repaint ();
    } // else we might want to just see part of this image, eg through doorway from interior
    
    long dt = new Date ().getTime () - t0; // ms
    System.out.println (ME.toString () + " Scene drawn in " + dt + "ms");
  } // draw
  
  /* Pass context in so others can use */
  public void drawCompass (Graphics2D g2d)
  { 
    int diam = 2 * COMPASS_RADIUS_PX;
    int xCentre = wd2, xLeft = xCentre - COMPASS_RADIUS_PX;
    int yCentre = ht - COMPASS_RADIUS_PX - 5, yTop = yCentre - COMPASS_RADIUS_PX;
    g2d.setPaint (Color.GRAY);
    g2d.fillArc (xLeft, yTop, diam, diam, 0, 360);
    g2d.setPaint (Color.RED);
    g2d.setStroke (UTIL.STROKE2);
    g2d.drawArc (xLeft, yTop, diam, diam, 0, 360);
    g2d.setStroke (UTIL.STROKE5);
    int r7 = COMPASS_RADIUS_PX - 7;
    int dx = (int) Math.round (-r7 * Math.sin (ME.b * UTIL.DEG2RAD));
    int dy = (int) Math.round (-r7 * Math.cos (ME.b * UTIL.DEG2RAD));
    g2d.setPaint (Color.WHITE);
    g2d.drawLine (xCentre, yCentre, xCentre - dx, yCentre - dy);
    g2d.setPaint (Color.RED);
    g2d.drawLine (xCentre, yCentre, xCentre + dx, yCentre + dy);
    g2d.setStroke (UTIL.STROKE1); // Restore previous
  } // drawCompass

  private boolean neighb3 (ScenePoint a1, ScenePoint a2, ScenePoint a3, TERRAINS tt)
  {
    Color n1 = this.neighb (a1, tt);
    
    if (null != n1)
    {
      Color n2 = this.neighb (a2, tt);
      
      if (null != n2)
      {
        Color n3 = this.neighb (a3, tt);
        
        if (null != n3)
        {
          g2.setPaint ((n1 == n2 && n2 == n3) ? n1 : COLOURS.GREY);
          return true;
        }
      }
    }
    
    return false;  
  } // neighb3

  private Color neighb (ScenePoint a, TERRAINS tt)
  {
    Terra tr = a.getTerra ();
    
    if (tr.terrain != tt)
    {
      switch (tr.terrain)
      {
  case THICKET:
  case WOOD: return COLOURS.WOOD;
  case GRASS: return COLOURS.GRASS;
  case MOOR: return COLOURS.MOOR;
  case TOWN: return COLOURS.GREY;
      }
      
      return COLOURS.GREY;
    }
    
    return null;
  } // neighb
  
  private class HeliButton
  {
    private int xL, yT, xR, yB, wd, ht;
    private String text, key;
    private Font font12 = new Font ("SansSerif", Font.PLAIN, 12);
    private Font font32 = new Font ("SansSerif", Font.PLAIN, 32);
    
    public HeliButton (int xL, int yT, int xR, int yB, String text, String keyText)
    {
      this.xL = xL; this.yT = yT; // Left Top
      this.xR = xR; this.yB = yB; // Right Bottom
      this.wd = xR - xL; this.ht = yB - yT;
      this.text = text;
      this.key = keyText;
    } // HeliButton

    public void draw (Graphics2D g2)
    {
      g2.setFont (font32);
      g2.setPaint (Color.RED);
      g2.setStroke (UTIL.STROKE3);
      g2.drawRect (this.xL, this.yT, this.wd, this.ht);
      g2.setStroke (UTIL.STROKE3);
      
      if (this.text.length () > 0) g2.drawString (this.text, this.xL + 7, this.yT + 35);
      
      if (this.key.length () > 0)
      {
        g2.setFont (font12);
        g2.setPaint (new Color (68, 68, 68, 255));
        g2.drawString (this.key, this.xL + 12, this.yB - 12);
        g2.setFont (font32);
      } 
    } // draw

    public boolean isIn (int x, int y)
    {
      return (x > this.xL && x < this.xR && y > this.yT && y < this.yB);
    }
    
  } // HeliButton
  
  private HeliButton [] heliButtons;
  
  private void createHeliButtons ()
  {
    int compHt = COMPASS_RADIUS_PX * 2;
    int yT = (int) Math.round (ht - compHt * 0.9);
    int yB = (int) Math.round (ht - compHt * 0.1);
    
    this.heliButtons = new HeliButton [4];
    heliButtons [0] = new HeliButton ((int) Math.round (wd * 0.1), yT,
                      (int) Math.round (wd * 0.18), yB, "UP", "PgUp");
    heliButtons [1] = new HeliButton ((int) Math.round (wd * 0.35), yT,
                      (int) Math.round (wd * 0.43), yB, "DN", "PgDn");
    heliButtons [2] = new HeliButton ((int) Math.round (wd * 0.6), yT,
                      (int) Math.round (wd * 0.9), yB, "   Disembark", "        Esc");
    heliButtons [3] = new HeliButton ((int) Math.round (wd * 0.6), yT,
                      (int) Math.round (wd * 0.9), yB, "", "");
  } // createHeliButtons

  private void drawHeliControls ()
  {
    int compHt = COMPASS_RADIUS_PX * 2;
    Color fill = new Color (153, 153, 153, 153);//RGBA
    TILE.setAndDraw (new PointInt (0, ht), 
                     new PointInt (compHt, ht - compHt),
                     new PointInt (wd - compHt, ht - compHt),
                     new PointInt (wd, ht),
                     g2, fill, fill);
    g2.setPaint (Color.WHITE);
    g2.setFont (new Font ("SansSerif", Font.PLAIN, 32));
    g2.drawString ("Altitude", (int) Math.round (wd * 0.2), ht - compHt + 30);
    int alti = (ME.ht > Observer.ME_HT) ? (int) ME.ht : 0;
    g2.drawString (alti + "m", (int) Math.round (wd * 0.22), ht - 15);
    this.heliButtons [0].draw (g2);
    this.heliButtons [1].draw (g2);
    
    if (alti > 0) this.heliButtons [3].draw (g2);
    else this.heliButtons [2].draw (g2);
  } // drawHeliControls

} // Scene