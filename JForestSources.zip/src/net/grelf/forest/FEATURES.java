/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public enum FEATURES
{
  NONE, MINE, BOULDER, ROOT, WATERHOLE, KNOLL, X, CONE, ROCKET, BUILDING, T,
  /*START_POLE_LEFT, START_POLE_RIGHT, FINISH_POLE_LEFT, FINISH_POLE_RIGHT,*/
  Q000, Q00F, Q0F0, Q0FF, QF00, QF0F, QFF0, QFFF;
  
  public String getDescription ()
  { 
    switch (this)
    {
    case MINE: return "mineshaft";
    case BOULDER: return "boulder";
    case KNOLL: return "knoll";
    case ROOT: return "rootstock";
    case WATERHOLE: return "water hole";
    case X: return "man-made";
    }

    return "unknown";
  } // getDescription

  public java.awt.Color getColour ()
  {
    switch (this)
    {
case MINE:
case BOULDER:
case BUILDING:
case X: return COLOURS.BLACK;
case ROOT: return COLOURS.GREEN;
case WATERHOLE: return COLOURS.BLUE;
case KNOLL: return COLOURS.BROWN;
default: return COLOURS.WHITE;
    }
  } // getColour
  
  public int [] getPxColour ()
  {
    switch (this)
    {
case MINE:
case BOULDER:
case X: return COLOURS.pxBLACK;
case ROOT: return COLOURS.pxGREEN;
case WATERHOLE: return COLOURS.pxBLUE;
case KNOLL: return COLOURS.pxBROWN;
default: return COLOURS.pxWHITE;
    }
  } // getPxColour
  
} // FEATURES
