/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

public enum TERRAINS
{
  LAKE, TOWN, GRASS, MOOR, WOOD, THICKET, Z, ROAD, MUD, PATH, STREAM, MARSH;

  public java.awt.Color getColour ()
  {
    switch (this)
    {
case LAKE:
case STREAM:
case MARSH: return COLOURS.BLUE;
case TOWN:
case MUD:
case PATH: return COLOURS.GREY;
case GRASS: return COLOURS.YELLOW;
case MOOR: return COLOURS.OCHRE;
case WOOD:
case Z:
case ROAD: return COLOURS.WHITE;
case THICKET: return COLOURS.GREEN;
default: return COLOURS.BLACK;
    }    
  } // getColour

  public int [] getPxColour ()
  {
    switch (this)
    {
case LAKE:
case STREAM:
case MARSH: return COLOURS.pxBLUE;
case TOWN:
case MUD:
case PATH: return COLOURS.pxGREY;
case GRASS: return COLOURS.pxYELLOW;
case MOOR: return COLOURS.pxOCHRE;
case WOOD:
case Z:
case ROAD: return COLOURS.pxWHITE;
case THICKET: return COLOURS.pxGREEN;
default: return COLOURS.pxBLACK;
    }    
  } // getPxColour

}
