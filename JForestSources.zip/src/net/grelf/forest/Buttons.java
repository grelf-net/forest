/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2024
 */

package net.grelf.forest;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import net.grelf.Util;

public class Buttons implements ActionListener
{
  private static final Forest FOREST = Forest.getInstance ();

  public Buttons ()
  {
    JFrame frame = new JFrame ();
    frame.setTitle ("BUTTONS");
    frame.setIconImage (FOREST.getIconImage ());
    frame.setContentPane (setMapPanel ());
    frame.setPreferredSize (new Dimension (240, 500));
    frame.pack (); 
    frame.setLocation (FOREST.canvas.width + 160, 200);
    frame.setVisible (true);
  } // Buttons
  
  private JButton makeButton (String label, String actionCommand)
  {
    JButton b = new JButton (label);
    b.setHorizontalTextPosition (SwingConstants.CENTER);
    b.setActionCommand (actionCommand);
    b.addActionListener (this);
    return b;
  } // makeButton
  
  private JPanel setMapPanel ()
  {
    JPanel panel = new JPanel (new GridLayout (6, 2));
    panel.add (makeButton ("Go to SCENE", "go"));
    panel.add (makeButton ("North", "N"));
    panel.add (makeButton ("East", "E"));
    panel.add (makeButton ("West", "W"));
    panel.add (makeButton ("South", "S"));
    panel.add (makeButton ("Centre on me", "C"));
    return panel;
  } // setMapPanel

  private JPanel setScenePanel ()
  {
    JPanel panel = new JPanel (new GridLayout (6, 2));

// TO DO

    return panel;
  } // setScenePanel
  
  @Override
  public void actionPerformed (ActionEvent e) 
  { 
    Util.message ("ACTION", e.getActionCommand());

    switch (e.getActionCommand ())
    {
      
    }
  } // actionPerformed
  
} // Buttons
