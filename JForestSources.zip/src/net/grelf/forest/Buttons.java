/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2025
 */

package net.grelf.forest;

public abstract class Buttons 
{
  private boolean HIDDEN = false;
  
  public boolean isHidden () { return HIDDEN; }
  public void hide () { HIDDEN = true; }
  public void show () { HIDDEN = false; }
}
