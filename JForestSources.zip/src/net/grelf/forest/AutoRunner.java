/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2025
 */

package net.grelf.forest;

import java.util.Timer;
import java.util.TimerTask;

/** Makes observer run forward repeatedly */
public class AutoRunner 
{
  private final long INTERVAL;
  private boolean running = false;
  private Timer timer; 
  private TimerTask task;
  
  public AutoRunner (long interval)
  {
    this.INTERVAL = interval;
  }
  
  public void start ()
  {
    timer = new Timer ();
    task = new TimerTask ()
    {
      @Override
      public void run ()
      {
        Forest.getInstance ().observer.forward ();
      }
    };
    timer.scheduleAtFixedRate (task, INTERVAL, INTERVAL);
    running = true;
  } // start
  
  public void stop ()
  {
    if (running)
    {
      task.cancel ();
      timer.cancel ();
    }
    
    running = false;
  } // stop
  
  public void toggle ()
  {
    if (running) stop ();
    else start ();
  } // toggle
  
} // AutoRunner
