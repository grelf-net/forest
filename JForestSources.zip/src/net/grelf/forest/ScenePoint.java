/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

/* For holding data about an (x, y) point in the terrain */
public class ScenePoint extends ScenePointBase
{
	public boolean o = true;// odd x and y, to be centre of 2x2 tile
	public Terra tr = null;// undefined to begin
	public double fogNo = 0;
	public boolean clear = false; // Part of a clearing around a feature
	public boolean drawn = false; // Already drawn first before the feature
  public boolean ahead = false;
  public int fnd = -1; // For building foundations, -1 = not set

	public ScenePoint (double distance, double bearing, double x, double y, boolean odd)
	{
    super (distance, bearing, x, y);
		this.o = odd;
		this.fogNo = 0;
		this.tr = null;// tr undefined at first
		this.clear = false;
		this.drawn = false;
    this.ahead = false;
    this.fnd = -1;
	}

	public ScenePoint ()
	{
    super (0, 0, 0, 0);
    o = false;
		fogNo = 0;
		tr = null;// tr undefined at first
		clear = false;
		drawn = false;
	}

	/* If tr has already been calculated for this point don't do it again, just return it */
	public Terra getTerra ()
	{
		if (null == tr) tr = Forest.getInstance ().terrain.terra (x, y);
		return tr;
	}

  @Override
	public String toString ()
	{
		String s = "x = " + x + ", y = " + y + ", d = " + d + ", b = " + b + ", ";
		s += o ? "odd" : "even";
		return s;
	}

} // ScenePoint