/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import net.grelf.Util;

public class Observer
{
  protected ROLES role;
  protected static final int ME_HT = 2; // Observer height, m
  protected static final int DB = 15;
  private static Forest FOREST;
  private static final int HELI_STEP = 10;
  private static final int HELI_DALT = 10;
  private static final int SAFE_HELI_HT = 30;
          
  protected double x, y, ht; // x east, y north from map origin
  protected int b;// bearing, degrees clockwise from N (y-axis)
  protected double cosb, sinb, dht;
  protected Terra terrain;
  protected int stride;// metres
  protected boolean novice, drift, nearDoor, nearHeli, inHeli;
  protected Building building; // for when near
    
  public Observer (Point position, int bearingDegs)
  {
    FOREST = Forest.getInstance ();
    this.role = ROLES.EXPLORER;
    this.x = position.x;
    this.y = position.y;
    this.b = bearingDegs;
    sincos ();
    this.ht = ME_HT;
    this.drift = true;
    this.stride = 3;//m
    this.novice = false;
    this.nearHeli = false;
    this.inHeli = false;
    this.building = null;
  } // Observer

  protected final void sincos ()
  {
    if (b > 180) b -= 360;
    else if (b < -180) b += 360;

    double brad = this.b * UTIL.DEG2RAD;
    this.sinb = Math.sin (brad);
    this.cosb = Math.cos (brad);
    this.terrain = FOREST.terrain.terra (x, y);
    this.dht = getHt10mAhead () - this.terrain.height;
  } // sincos
  
  private double getHt10mAhead ()
  {
    double xx = this.x + 10 * this.sinb;
    double yy = this.y + 10 * this.cosb;
    return FOREST.terrain.terra (xx, yy).height;
  }
  
  @Override
  public String toString ()
  { 
    String s = "x = " + UTIL.DF2.format (this.x) + 
            ", y = " + UTIL.DF2.format (this.y) +
            ", bearing " + this.b + "\u00b0";
    
    if (FOREST.view == VIEWS.SCENE && this.role != ROLES.ORIENTEER && !this.inHeli) 
    {
      s += ", steepness = " + (int) Math.round (this.dht);
    }
    
    return s;
  } // toString


  public void turnLeft ()
  {
    TERRAINS tt = this.terrain.terrain;
    
    if (tt == TERRAINS.TOWN 
     || tt == TERRAINS.ROAD 
     || tt == TERRAINS.PATH) this.b -= DB * 0.5;
    else this.b -= DB;

    this.sincos ();
    FOREST.redraw ();
  } // turnLeft

  public void turnRight ()
  {
    TERRAINS tt = this.terrain.terrain;
    
    if (tt == TERRAINS.TOWN 
     || tt == TERRAINS.ROAD 
     || tt == TERRAINS.PATH) this.b += DB * 0.5;
    else this.b += DB;

    this.sincos ();
    FOREST.redraw ();
  } // turnRight

  public void turnRound ()
  {
    this.b += 180; 
    sincos ();
    this.sincos ();
    FOREST.redraw ();
  } // turnRound

  public void forward ()
  {
    double step;
    
    if (this.inHeli)
    {
      if (this.ht <= ME_HT) return; // no forward if on ground
      step = HELI_STEP;
    }
    else
    {
      TERRAINS tt = this.terrain.terrain;
      
      if (this.drift && tt != TERRAINS.TOWN && tt != TERRAINS.ROAD) 
      {
        this.b += Math.round (10 * Math.random ()) - 5; // Drift +- 5 degrees
        this.sincos ();
      }
      
      step = this.stride;
      
      switch (tt)
      {
      case THICKET:
      case MARSH:
      case LAKE: step /= 4; break;
      case MOOR:
      case MUD:
      case STREAM:
      case TOWN: step /= 2; break;
      }
      
      double steepnessFactor = 1;
      
      if (this.dht > 30) steepnessFactor = 0.1;
      else if (this.dht > 20) steepnessFactor = 0.2;
      else if (this.dht > 10) steepnessFactor = 0.5;
      else if (this.dht < -30) steepnessFactor = 0.2;
      else if (this.dht < -20) steepnessFactor = 0.5;
      else if (this.dht < -10) steepnessFactor = 1.2;
      
      step *= steepnessFactor;
    }
    
    double xNew = this.x + step * this.sinb;
    double yNew = this.y + step * this.cosb;
    
    if (this.inHeli)
    {
      if (this.ht - ME_HT < SAFE_HELI_HT 
       && FOREST.terrain.terra (xNew, yNew).terrain == TERRAINS.TOWN)
      {
        heliSafer ();
        return; // Cannot go forward until safe
      }
    }
    else if (Building.inABuilding (xNew, yNew)) 
    {
      Util.message ("WARNING", 
        "You cannot walk through buildings!\nBut perhaps you can Enter the door.");
      return;
    }
    
    this.x = xNew;
    this.y = yNew;
    
/*
    this.dist_m += step;
    if (this.role == ROLES.ORIENTEER) this.route.push ({ x:this.x, y:this.y, controlNo:-1 });
    else
    { if (nearMonolith (xNew, yNew)) return;
      if (FOREST.scene.atHole //EZ: { forest.scene.enterHole (); return; }
       || (FOREST.estate > 256 && FOREST.scene.static1))
      {	getRocket (2242, 28971).move (); }//:EZ
    }
    if (null === this.inside)
    { forest.scene.draw ();
  var el = document.getElementById ("test"); if (null !== el) el.innerHTML = forest.estate;
      if (10 > Math.abs (this.x - 20382) && (10 > Math.abs (this.y - 11791)))
      { if (forest.estate >= 31)
        { forest.estate |= 32; message ("Well done! You have reached the spot.", "", 
  "Treasure is not left lying on the ground", "of course, so how will you get to it?",
  "", "If you have no ideas, try reading the", "User Guide.");
        }
        else if (forest.estate > 1 && forest.estate < 31) message (
  "You need to have seen all 4 map pieces", "before anything will happen.");
    } }
    else this.inside.checkAndDraw ();
*/
    FOREST.scene.draw ();
  } // forward

  public void jump ()
  {
    double xx = FOREST.map.centre.x;
    double yy = FOREST.map.centre.y;
    TERRAINS tr = FOREST.terrain.terra (xx, yy).terrain;
    
    if (tr == TERRAINS.LAKE || tr == TERRAINS.TOWN)
    {
      Util.message ("SORRY", "You cannot jump onto lakes or towns");
    }
    else
    {
      this.x = xx;
      this.y = yy;
      FOREST.map.draw (FOREST.map.centre);
    }
  } // jump

  private void heliSafer () // Get above buildings
  { 
    this.ht += 5;
    FOREST.redraw ();

    if (this.ht - ME_HT < SAFE_HELI_HT)
    {
      ActionListener heliSafeAction = new ActionListener () 
      {
        @Override
        public void actionPerformed (ActionEvent evt) 
        {
          FOREST.observer.heliSafer ();
        }
      };
      
      Timer timer = new Timer (100, heliSafeAction);
      timer.setRepeats (false);
      timer.start ();
    }
  } // heliSafer

  protected void enter () 
  {
    if (nearDoor) this.building.enter ();
    else 
    if (nearHeli)
    {
      int xr = (int) Math.round (this.x);
      int yr = (int) Math.round (this.y);
      
      for (int iy = yr - 8; iy <= yr + 8; iy++)
      {
        for (int ix = xr - 8; ix <= xr + 8; ix++)
        {
          // Cones on open ground are seen by explorers as helicopters
          if (FOREST.terrain.terra (ix, iy).feature == FEATURES.CONE)
          {
            FOREST.terrain.place (ix, iy, FEATURES.NONE); // Departed
          }
        } 
      }
    
      this.inHeli = true;
      this.heliUp ();
      this.ht = 10;
    }
  } // enter
  
  /* Note: Helicopters do not really exist as Java objects.
     Cones generated on open ground are seen by explorers as helicopters.
     If an explorer is within 7m of one it can be entered but this is really
     just enabling the observer to fly. The PLACED hashmap in Terrain is used
     to remove helicopters (cones) from where they took off and place them 
     where they land, so they appear to move. When in a helicopter, scene
     drawing displays controls.
  */
  
  private void heliUp ()
  { 
    this.ht += HELI_DALT;
    FOREST.redraw ();
  };

  private void heliDown ()
  { 
    TERRAINS tt = FOREST.terrain.terra (this.x, this.y).terrain;
    
    if (tt == TERRAINS.TOWN && this.ht - ME_HT <= SAFE_HELI_HT)
    { 
      Util.message ("SORRY", "It\'s not safe to go\nlower over buildings");
      return;
    }
    
    if (this.ht - HELI_DALT <= ME_HT)
    {
      if (tt != TERRAINS.GRASS && tt != TERRAINS.MOOR)
      { 
        Util.message ("SORRY", "You cannot land here, only\non open land (grass or moor)");
        return;
      }
    }
    
    this.ht -= HELI_DALT;
    
    if (this.ht <= ME_HT) 
    {
      this.ht = ME_HT;
    }

    FOREST.redraw ();
  } // heliDown

  private void heliExit ()//EX - user now has to disembark
  { 
    if (this.ht <= ME_HT) 
    {
      this.ht = ME_HT;
      this.inHeli = false;
      int st = this.stride;
      this.stride = 10;// Move clear of heli
      this.forward ();
      this.stride = st;
      FOREST.terrain.place ((int) Math.round (this.x), (int) Math.round (this.y), FEATURES.CONE);
    }

    FOREST.redraw ();
  } // heliExit

  void exit ()
  {
    if (this.inHeli) heliExit ();
  } // exit

  void down ()
  {
    if (this.inHeli) heliDown ();
  }

  void up () 
  {
    if (this.inHeli) heliUp ();
  }

} // Observer
