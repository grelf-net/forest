/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.util.HashMap;

/** The Relf Terrain Generator.
  *
  * This algorithm was first developed in 1983 in Z80 assembly code
  * for the Sinclair ZX Spectrum (48kB RAM).
  * It was converted to Javascript in 2014.
  * C++ and Java versions were made for comparison in 2021.
  * This Java version is the clearest of course.
  * Experiments in 2023 to implement this as non-graphical WebGL
  * did not improve speed for a map 800 x 600. WebGPU may be better.
  */
public class Terrain 
{
  private static final double PI1000 = Math.PI * 1000;
  private static final double PI10000 = Math.PI * 10000; 
  public static final int LAKE_HT0 = 204;
  private static final double RECIP128 = 1.0 / 128.0;
  private final HashMap <String, Object> PLACED;

  /** Reference to the main program (needed in just 1 place, legacy from JS). */
  public Forest FOREST;
  
  /** Current height of lake edges. */
  public int lakeHt;
  
  /** User can potentially alter these booleans. */
  public boolean bleak, woodOnly, withPaths, withStreams, mapMode;

  // NB: The length of this array MUST be a power of 2.
  // It could be much longer without affecting performance.
  // This is the original profile used in 1983 for The Forest in ZX Spectrum.
  private static final int [] PROFILE = {
 77, 80, 84, 88, 92, 96,101,104,108,112,115,118,120,123,126,129,131,133,134,134,
133,133,131,130,129,126,123,122,122,122,123,125,126,130,134,137,137,138,138,137,
135,133,129,123,118,111,105,101, 97, 93, 90, 86, 82, 78, 74, 71, 69, 67, 67, 67,
 66, 67, 69, 71, 73, 74, 73, 73, 71, 69, 66, 62, 58, 54, 52, 52, 54, 55, 58, 59,
 62, 63, 63, 65, 65, 65, 66, 66, 67, 69, 70, 73, 77, 80, 82, 85, 88, 90, 93, 95,
 96, 96, 96, 96, 93, 92, 90, 85, 80, 75, 71, 67, 63, 60, 58, 55, 52, 50, 47, 44,
 43, 41, 40, 39, 36, 35, 33, 32, 30, 28, 24, 20, 15, 11,  7,  3,  2,  2,  2,  2,
  2,  2,  3,  6,  7, 10, 11, 15, 18, 22, 24, 25, 25, 26, 26, 25, 25, 25, 25, 25,
 26, 28, 29, 30, 33, 36, 37, 39, 39, 40, 40, 40, 39, 39, 39, 37, 37, 37, 36, 36,
 36, 35, 35, 33, 33, 32, 30, 28, 25, 20, 15, 11, 10,  9,  9,  9,  9, 11, 14, 15,
 17, 17, 18, 18, 18, 18, 18, 18, 17, 17, 17, 15, 14, 13, 11, 11, 10, 10, 10, 11,
 13, 14, 17, 20, 22, 25, 28, 30, 35, 39, 41, 45, 50, 58, 63, 69, 73, 77, 80, 82,
 84, 84, 85, 85, 84, 84, 82, 81, 80, 75, 73, 71, 71, 73, 74, 75 };
  private static final int BIT_MASK = PROFILE.length - 1;// All bits must be 1
  
  //These arrays must be of length to match the for loops in calcProf() and calcHeight()
  private static final int [] AH = {0, 13, 21, 22, 29};
  private static final int [] BH = {27, 26, 21, 11, 1};
  private static final int [] A1 = {-43, -43, -56, 31, 4};
  private static final int [] B1 = {-3, -12, 22, 2, 32};
  private static final int [] A2 = {-24, -25, 60, 10, - 30};
  private static final int [] B2 = {15, -54, -34, -51, -43};
  private static final int [] A3 = {-51, -62, -58, -64, 33};
  private static final int [] B3 = {-44, 20, 27, -64, -44};
  private static final int PARAM_LENGTH = AH.length;

  /** Likely to be a singleton in many programs. */
  public Terrain ()
  { 
    this.FOREST = Forest.getInstance (); // Main program
    this.lakeHt = LAKE_HT0;
    this.bleak = false;
    this.woodOnly = false;
    this.withPaths = false;
    this.withStreams = true;
    this.mapMode = true;
    this.PLACED = new HashMap <> ();// Allows objects to move
  } // Terrain

  /** Position an object on the ground. */
  public void place (int x, int y, Object n) 
  {
    PLACED.put (x + "," + y, n);
  }
  
  /** Get any object at this position, null if there is none. */
  public Object atPlace (int x, int y)
  {
    return PLACED.get (x + "," + y);
  }

  /** Remove any object from this position. */
  public void remove (int x, int y)
  {
    PLACED.remove (x + "," + y); 
  }
  
  /** Remove all objects of the given kind, from the whole terrain. */
  public void removeAll (TERRAINS kind)
  {
    for (String key : PLACED.keySet ())
    {
      if (PLACED.get (key) == kind)
      {
        PLACED.remove (key);
      }
    }
  } // removeAll
  
  /** Clear all streams from the terrain. */
  public void clearStreams ()
  { 
    removeAll (TERRAINS.STREAM);
  }  

  /** Get all the terrain details for the given ground position. */
  public Terra terra (double x, double y)
  {
    int a, b;
    FEATURES feature = FEATURES.NONE;
    String code = "";
    double ht = calcHeight (x, y);
    
    if (this.bleak)
    {
      return new Terra (x, y, ht, 0, TERRAINS.Z, FEATURES.NONE, "");
    }
    
    if (withPaths)
    {
      if (ht > lakeHt && Math.abs (ht - calcHeight (x + 4000, y + 2000)) < 2)
      {
        return new Terra (x, y, ht, 0, TERRAINS.PATH, FEATURES.NONE, "");
      }
    }
    
    int xr = (int) Math.round (x);
    int yr = (int) Math.round (y);
    long xryr = xr * yr;

    Object pd = PLACED.get (xr + "," + yr);
    
    if (null != pd)
    {
      if (pd instanceof TERRAINS)
      {
        if (pd == TERRAINS.STREAM && FOREST.view == VIEWS.SCENE)
          return new Terra (xr, yr, ht, 0, TERRAINS.STREAM, FEATURES.NONE, "");
        
        if (pd == TERRAINS.ROAD)
          return new Terra (xr, yr, Math.max (ht, lakeHt), 0, 
                            TERRAINS.ROAD, FEATURES.NONE, "");
      }
      else if (pd instanceof FEATURES)
      {
        if (pd == FEATURES.CONE // Helicopter landed?
         || pd == FEATURES.ROCKET
         || pd == FEATURES.T) feature = (FEATURES) pd;
        else 
        if (pd == FEATURES.NONE) // Helicopter departed?
          return new Terra (xr, yr, ht, 0, TERRAINS.GRASS, FEATURES.NONE, "");
      }
    }

    if (lakeHt > ht)
      return new Terra (xr, yr, lakeHt, lakeHt - ht, TERRAINS.LAKE, feature, "");

    if (LAKE_HT0 > ht)
      return new Terra (xr, yr, ht, 0, TERRAINS.MUD, feature, "");

    if (FEATURES.NONE == feature)
    {
      a = calcProf (B2, x, A3, y); // NB: Swapped a/b tables
      long f = Math.round (a * xryr * RECIP128) & 0xfff;

      if (4 == f) 
      { long xyff = xryr & 0xff;
        if (xyff < 32) feature = FEATURES.MINE;
        else if (xyff < 128) feature = FEATURES.BOULDER;
        else if (xyff < 160) feature = FEATURES.WATERHOLE; // NB: Consistent with method isWaterhole
        else if (xyff < 200) feature = FEATURES.KNOLL;
        else feature = FEATURES.ROOT;
        code = getCode (xr, yr);
      }
      else if (8 == f && (Math.round (PI1000 * xryr) & 0xff) < 4) 
      {
        feature = FEATURES.X; code = this.getCode (xr, yr);
      }
      else if (16 == f && (Math.round (PI10000 * xryr) & 0xff) < 8) feature = FEATURES.CONE;
    }
    if (!woodOnly)
    {
      a = calcProf (A1, x, B1, y);
      
      if (120 > a)
      {
        if (Building.atCentre (xr, yr))
        {
          return new Terra (xr, yr, ht, 0, TERRAINS.TOWN, new Building (xr, yr));
        }
        else
        {
          return new Terra (xr, yr, ht, 0, TERRAINS.TOWN, FEATURES.NONE, "");
        }
      }

      a = calcProf (A2, x, B2, y);
      b = calcProf (A3, x, B3, y);

      if (255 > a)
      {
        if (255 > b)
          return new Terra (xr, yr, ht, 0, TERRAINS.GRASS, feature, code);

        return new Terra (xr, yr, ht, 0, TERRAINS.MOOR, feature, code);
      }

      if (200 > b)
        return new Terra (xr, yr, ht, 0, TERRAINS.THICKET, feature, code);
    }

    return new Terra (xr, yr, ht, 0, TERRAINS.WOOD, feature, code); // runnable
  } // terra

  private int calcProf (int [] a, double x, int [] b, double y)
  {
    int p = 0;
    
    for (int i = 0; i < PARAM_LENGTH; i++)
    {
      p += PROFILE [(int) (((long) Math.floor (a [i] * x + b [i] * y)) >> 7) & BIT_MASK];
    }
    
    return p;
  } // calcProf

  /** Get the ground height at the given position.
    * Interpolates between integer coordinates for smooth slopes. */
  protected double calcHeight (double x, double y)
  {
    double ht = 0;

    for (int i = 0; i < PARAM_LENGTH; i++)
    {
      double j = (AH [i] * x + BH [i] * y) * RECIP128;
      int jint = (int) Math.floor (j);
      double jfrac = j - jint;
      int prof0 = PROFILE [jint & BIT_MASK];
      int prof1 = PROFILE [(jint + 1) & BIT_MASK];
      ht += prof0 + jfrac * (prof1 - prof0); // interpolate
    }

    return ht;
  } // calcHeight

  /** Fast, not checking anything else.
    * Use in the margin outside the map to check for streams.
    * Must be consistent with this.terra() */
  public boolean isWaterhole (double x, double y) 
  {
    int xr = (int) Math.round (x);
    int yr = (int) Math.round (y);
    long xryr = xr * yr;
    int a = calcProf (B2, x, A3, y); // NB: Swapped a/b tables

    int axryr = (int) Math.round (a * xryr * RECIP128);

    if (4 == (axryr & 0xfff)) 
    { int xyff = (int) xryr & 0xff;
      return (xyff >= 128 && xyff < 160);
    }

    return false;
  } // isWaterhole

  /** Find the nearest point feature to the given ground position.
    * For orienteering course planners. */
  public Terra findNearestFeature (double x, double y)
  { 
    int xr = (int) Math.round (x);
    int yr = (int) Math.round (y);
    int xmin = xr, xmax = xr;
    int ymin = yr, ymax = yr;
    int dx = 1, dy = 0; // direction

    for (int n = 0; n < 100000; n++) // safety
    {
      Terra t = terra (xr, yr);
      if (t.feature != FEATURES.NONE) return t;
      xr += dx; yr += dy; // Spiral out:
      if (xr > xmax) { xmax++; dx = 0; dy = 1; }
      else if (yr > ymax) { ymax++; dx = -1; dy = 0; }
      else if (xr < xmin) { xmin--; dx = 0; dy = -1; }
      else if (yr < ymin) { ymin--; dx = 1; dy = 0; }
    }

    return null;
  } // findNearestFeature

  /** For orienteering control points: */
  private static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

  /** Get the orienteering control code for the given ground position, 2 capital letters. */
  public String getCode (int x, int y)
  {
    int x26 = Math.abs (x) % 26;
    int y26 = Math.abs (y) % 26;
    return ALPHABET.substring (x26, x26 + 1) + ALPHABET.substring (y26, y26 + 1);
  } // getCode

} // Terrain
