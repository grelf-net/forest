/* The Forest (1980 - )
 * Conversion from HTML5/JavaScript
 * Copyright (c) Graham Relf, UK, 2021
 */

package net.grelf.forest;

import java.awt.Color;

public class COLOURS
{
  // For map:
  public static final Color WHITE = new Color (255, 255, 255, 255);
  public static final int [] pxWHITE = { 255, 255, 255, 255 };
  public static final Color BROWN = new Color (184, 78, 27, 255);//PMS471 = #b84e1b)
  public static final int [] pxBROWN = { 184, 78, 27, 255 };
  public static final Color BLACK = new Color (0, 0, 0, 255);
  public static final int [] pxBLACK = { 0, 0, 0, 255 };
  public static final Color BLUE = new Color (0, 170, 231, 255);//PMS299 = #00aae7
  public static final int [] pxBLUE = { 0, 170, 231, 255 };
  public static final Color YELLOW = new Color (253, 183, 59, 255);//PMS136 = #fdb73b
  public static final int [] pxYELLOW = { 253, 183, 59, 255 };
  public static final Color OCHRE = new Color (192, 192, 127, 255);// #cc7
  public static final int [] pxOCHRE = { 192, 192, 127, 255 };
  public static final Color GREEN = new Color (0, 128, 0, 255);
  public static final int [] pxGREEN = { 0, 128, 0, 255 };
  public static final Color GREY = new Color (153, 153, 153, 255);
  public static final int [] pxGREY = { 153, 153, 153, 255 };
  public static final Color PURPLE = new Color (156, 63, 152, 255);// PMS purple = #9c3f98
  public static final int [] pxPURPLE = { 156, 63, 152, 255 };

  // For scene tiles:
  public static final Color SKY = new Color (170, 221, 255, 255);
  public static final Color LAKE = new Color (68, 119, 153, 255);
  public static final Color GRASS = new Color (112, 145, 88, 255);
  public static final Color MOOR = new Color (142, 105, 83, 255);
	public static final Color WOOD = new Color (178, 151, 100, 255);
	public static final Color PAVE_LINE = new Color (130, 130, 130, 255);

} // COLOURS
